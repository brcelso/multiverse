# API Automatos

## Instalação das dependências

Acesse a pasta dos scripts no cmd/terminal e digite **pip install -r requirements.txt** para instalar as dependências do projeto

## API de distribuição

A API de distribuição pode ser utilizada para envio de distribuição automatizada de softwares

[Documentação da API](https://docs.almaden.app/pt-br/docs/smartcenter/integrations-52/distribution-api-2116/)

### Como utilizar o script de distribuição

Crie um arquivo chamado .env na mesma pasta do script **enviar_distribuicao.py** e informe as seguintes linhas

USER=""<br />
PASSWORD=""<br />
<br />
AUTOMATOS_ID=""<br />
AUTOMATOS_KEY=""<br />

Informe entre as aspas seu usuário e senha de administrador<br />
A Automatos ID e Key são fornecidos no portal Automatos quando se utiliza o uauário principal da conta, na página da API pública

- Instalar o python na versão mais recente (Versão 3)
- Abra o script com um visualizador de texto ou editor de código, recomendo o Visual Studio Code<br />
- Altere a linha package com o software que precisa ser instalado<br />
- Altere o hostname da máquina, o hostname é onde será instalado o software<br />
- Digite na linha de comando **python enviar_distribuicao.py** ou aperte o símbolo de play na barra superior superior do Visual Studio Code

## API pública

A API publica pode ser utilizada para consulta de informações de hardware e software dos servidores, desktops e notebooks

[Documentação da API](https://lad1-smartcenter.almaden.app/api/public/almaden-docs/)

### Scripts

- getAllHardware.py Busca informações sobre o hardware da máquina definida na váriavel **hostname**<br />
- getAllSoftware.py Busca informações sobre o software na máquina definida na váriavel **hostname**<br />
- getAllSoftwareFilter.py Busca informações sobre o software da máquina definida na váriavel **hostname** com base no filtro definido na váriavel **filtro**<br />

### Como utilizar os scripts

Crie um arquivo chamado .env na mesma pasta dos scripts e informe as seguintes linhas

AUTOMATOS_ID=""<br />
AUTOMATOS_KEY=""<br />

A Automatos ID e Key são fornecidos no portal Automatos quando se utiliza o uauário principal da conta, na página da API pública

- Instalar o python na versão mais recente (Versão 3)
- Abra o script com um visualizador de texto ou editor de código, recomendo o Visual Studio Code<br />
- Altere a linha hostname com o máquina que precisa ser buscado entre as aspas<br />
- Digite na linha de comando o nome do script e aperte enter ou aperte o símbolo de play na barra superior superior do Visual Studio Code
- Os relatórios serão salvos na pasta relatorios

Qualquer dúvida entrar em contato: wellington.rocha@luizalabs.com
