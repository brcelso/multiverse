import csv
import requests
from datetime import datetime
import time
import urllib3
from dotenv import load_dotenv
import os

# Carrega as variáveis do arquivo .env
load_dotenv()

#Para acesso a autenticação e API pública
automatos_id = os.getenv('AUTOMATOS_ID')
automatos_key = os.getenv('AUTOMATOS_KEY')

# Suprimir o aviso InsecureRequestWarning
urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)

#Atribui o diretório do script ao que está em uso
script_dir = os.path.dirname(os.path.abspath(__file__))
os.chdir(script_dir)

homeV1 = "https://lad1-smartcenter.almaden.app/api/public/api"

#Data para geração dos logs
data_atual = datetime.now()
data_formatada = data_atual.strftime('%Y-%m-%d')
data_formatada_com_hora = data_atual.strftime('%Y-%m-%d %Hh%Mm')

#Hostname da máquina a ser encontrada e ano para filtrar o software (EX: Excel 2016)
hostname = "WNEC-PE06ZH28"
filtro = "2016"

#Local onde os logs serão salvos
csv_file = f"./Listagem-{hostname}-{data_formatada_com_hora}.csv"
# csv_file = f'\\\\fs\\iso$\\1_log\\{data_formatada_com_hora}-{hostname}.csv'

endpoint = f"{homeV1}/getAllSoftware/nextpage/desktops?AutomatosId={automatos_id}&Securitykey={automatos_key}&hostname={hostname}"

def obter_dados_filtrados():
    response = requests.get(endpoint, verify=False)
    
    if response.status_code == 200:

        data = response.json().get('data', [])
        
        filtered_data = [
            {
                'instalation_date': software['instalation_date'],
                'computer_name': software['computer_name'],
                'software_name': software['software_name'],
                'normalized_software_name': software['normalized_software_name'],
                'machine_type': software['machine_type']
            }
            for software in data if filtro in software['normalized_software_name'] and data_formatada == software['instalation_date'].split(" ")[0]
        ]
        
        return filtered_data
    else:
        print(f"Erro na requisição: {response.status_code}")
        return []

while True:
    filtered_data = obter_dados_filtrados()
    headers = ['instalation_date', 'computer_name', 'software_name', 'normalized_software_name', 'machine_type']
    
    if filtered_data:
        with open(csv_file, mode='w', newline='', encoding='utf-8') as file:
            writer = csv.DictWriter(file, fieldnames=headers, delimiter=';')
            writer.writeheader()
            writer.writerows(filtered_data)
        
        print(f"Dados exportados com sucesso para {csv_file}")
        break
    else:
         for remaining in range(5, 0, -1):
            print(f"Nenhum dado encontrado no filtro utilizado com a data atual. Tentando novamente em {remaining} minuto(s)...", end='\r')
            time.sleep(60)