import csv
import json
import requests
from datetime import datetime
import os
import urllib3
from dotenv import load_dotenv
import os

# Suprimir o aviso InsecureRequestWarning
urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)

# Carrega as variáveis do arquivo .env
load_dotenv()

#Para acesso a autenticação e API pública
automatos_id = os.getenv('AUTOMATOS_ID')
automatos_key = os.getenv('AUTOMATOS_KEY')

#Atribui o diretório do script ao que está em uso
script_dir = os.path.dirname(os.path.abspath(__file__))
os.chdir(script_dir)

# Variáveis de entrada
homeV1 = "https://lad1-smartcenter.almaden.app/api/public/api"
data_atual = datetime.now()
data_formatada = data_atual.strftime("%Y-%m-%d %Hh%Mm")

headers = [
    "computer_name",
    "department_name",
    "department_hierarchy",
    "so_string",
    "system_manufacturer",
    "computer_type",
    "machine_net_ipaddress",
    "bios_release_date",
    "machine_ipdomain",
    "is_virtual_machine",
    "system_product_name",
    "system_serial_number",
    "machine_id",
    "os_bits",
    "login_name",
    "cpu_identity",
    "cpu_generation",
    "cpu_type",
    "cpu_clock",
    "cpu_clock_in_MHz",
    "cpu_clock_in_GHz",
    "core_num",
    "physical_cpu_amount",
    "logical_cpu",
    "memory_range",
    "installed_mem",
    "disk_total",
    "disk_used",
    "top_user",
    "percent_top_user",
    "dns_servers",
    "machine_gateway",
    "collect_date",
    "update_date",
    "last_login",
    "installed_mem_in_GB",
    "disk_total_in_GB",
    "disk_used_in_GB",
    "installed_mem_in_MB",
    "disk_total_in_MB",
    "disk_used_in_MB",
]

hostname = "WNLX6051003"

csv_file = f"./Listagem-{hostname}-{data_formatada}.csv"

url = f"{homeV1}/getAllHardware/desktops?AutomatosId={automatos_id}&Securitykey={automatos_key}&hostname={hostname}"

response = requests.get(url, verify=False)

if response.status_code == 200:
    data = response.json()

    with open(csv_file, mode="w", newline="", encoding="utf-8") as file:
        writer = csv.DictWriter(file, fieldnames=headers, delimiter=";")
        writer.writeheader()
        writer.writerows(data)

    print(f"Dados exportados com sucesso para {csv_file}")

else:
    print(f"Erro na requisição: {response.status_code}")
