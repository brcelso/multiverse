import pandas as pd
from collections import Counter

# Path to the CSV file
file_path = 'data/10-02-2025.csv'

# Read the CSV file into a DataFrame
df = pd.read_csv(file_path)

# Total number of rows
total_rows = len(df)

# Count occurrences of each COMPUTER_NAME
computer_name_counts = Counter(df['COMPUTER_NAME'])

# Create a list of duplicated computer names and their counts
duplicated_computer_names = [(name, count) for name, count in computer_name_counts.items() if count > 1]

# Calculate only the rows that exceed one occurrence for each duplicated COMPUTER_NAME
total_duplicated_rows = sum(count - 1 for _, count in duplicated_computer_names)

# Define the years and keywords to check
years_of_interest = ['2007', '2010', '2013', '2016', '2019', '2021']
keywords = ['excel', 'standard', 'plus']

# Initialize a dictionary to hold the count for each year and keyword combination
year_keyword_counts = {}

# Count rows where COLLECTED_SW_NAME contains both the year and each keyword
for year in years_of_interest:
    for keyword in keywords:
        key = f'{year} and {keyword}'
        
        # Make the search case-insensitive and strip any leading/trailing spaces
        filtered_rows = df[
            df['COLLECTED_SW_NAME'].str.contains(year, case=False, na=False) &
            df['COLLECTED_SW_NAME'].str.contains(keyword, case=False, na=False)
        ]
        
        # Remove duplicates, keeping only the first occurrence
        filtered_rows_unique = filtered_rows.drop_duplicates(subset=['COMPUTER_NAME'], keep='first')
        
        # Store the count of unique rows
        year_keyword_counts[key] = filtered_rows_unique.shape[0]

# Add the "LTSC" condition but not containing any year
ltsa_condition = 'LTSC but not year'
ltsa_filtered_rows = df[
    df['COLLECTED_SW_NAME'].str.contains('LTSC', case=False, na=False) & 
    ~df['COLLECTED_SW_NAME'].str.contains('|'.join(years_of_interest), case=False, na=False)
]

# Remove duplicates for LTSC condition, keeping only the first occurrence
ltsa_filtered_rows_unique = ltsa_filtered_rows.drop_duplicates(subset=['COMPUTER_NAME'], keep='first')
ltsa_count = ltsa_filtered_rows_unique.shape[0]

# Function to consider only non-duplicate rows based on COMPUTER_NAME and condition rules
def get_non_duplicated_rows(df):
    # Create an empty list to hold the rows that will be considered as non-duplicate
    non_duplicated_rows = []
    
    # Group by COMPUTER_NAME to process duplicates
    grouped = df.groupby('COMPUTER_NAME')

    for name, group in grouped:
        # Check if there are duplicates
        if len(group) > 1:
            # Handle duplicates based on the "OFFICE" condition
            office_row = group[group['COLLECTED_SW_NAME'].str.contains('OFFICE', case=False, na=False)]
            if len(office_row) > 0:
                non_duplicated_rows.append(office_row.iloc[0])  # Only keep the first "OFFICE" row
            else:
                # If no "OFFICE" row, add the first occurrence of the other rows (EXCEL/PLUS)
                non_duplicated_rows.append(group.iloc[0])  # Keep the first row of the duplicated set
        else:
            # If the row is not duplicated, add it directly
            non_duplicated_rows.append(group.iloc[0])
    
    # Convert list back to DataFrame
    return pd.DataFrame(non_duplicated_rows)

# Apply the function to get the non-duplicated rows
non_duplicated_df = get_non_duplicated_rows(df)

# Calculate the total non-duplicate rows
total_non_duplicated_rows = len(non_duplicated_df)

# Count rows where COLLECTED_SW_NAME contains both the year and each keyword in non-duplicated rows
non_duplicated_year_keyword_counts = {}

for year in years_of_interest:
    for keyword in keywords:
        key = f'{year} and {keyword}'
        
        # Filter rows in non-duplicated DataFrame
        filtered_rows = non_duplicated_df[
            non_duplicated_df['COLLECTED_SW_NAME'].str.contains(year, case=False, na=False) &
            non_duplicated_df['COLLECTED_SW_NAME'].str.contains(keyword, case=False, na=False)
        ]
        
        # Store the count of non-duplicated rows
        non_duplicated_year_keyword_counts[key] = filtered_rows.shape[0]

# Add the "LTSC" condition but not containing any year for non-duplicated rows
non_duplicated_ltsa_filtered_rows = non_duplicated_df[
    non_duplicated_df['COLLECTED_SW_NAME'].str.contains('LTSC', case=False, na=False) & 
    ~non_duplicated_df['COLLECTED_SW_NAME'].str.contains('|'.join(years_of_interest), case=False, na=False)
]
non_duplicated_ltsa_count = non_duplicated_ltsa_filtered_rows.shape[0]

# Create a dictionary for the CSV content
csv_data = {
    "Metric": [
        "Total Rows", "Total Duplicated Rows", "Total Non-Duplicate Rows",
        *non_duplicated_year_keyword_counts.keys(), "LTSC"
    ],
    "Count": [
        total_rows, total_duplicated_rows, total_non_duplicated_rows,
        *non_duplicated_year_keyword_counts.values(), non_duplicated_ltsa_count
    ]
}

# Convert the dictionary to a DataFrame
results_df = pd.DataFrame(csv_data)

# Write the DataFrame to a new CSV file
output_file_path = 'data/final_results_05-02-2025.csv'
results_df.to_csv(output_file_path, index=False)

print(f"CSV file with results has been saved to {output_file_path}")