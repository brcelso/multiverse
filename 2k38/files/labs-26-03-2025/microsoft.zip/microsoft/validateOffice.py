import pandas as pd
from collections import Counter

# Path to the CSV file
file_path = 'data/21-02-2025.csv'

# Read the CSV file into a DataFrame
df = pd.read_csv(file_path)

# Total number of rows
total_rows = len(df)

# Count occurrences of each COMPUTER_NAME
computer_name_counts = Counter(df['COMPUTER_NAME'])

# Create a list of duplicated computer names and their counts
duplicated_computer_names = [(name, count) for name, count in computer_name_counts.items() if count > 1]

# Calculate only the rows that exceed one occurrence for each duplicated COMPUTER_NAME
total_duplicated_rows = sum(count - 1 for _, count in duplicated_computer_names)

# Define the years and keywords to check
years_of_interest = ['2007', '2010', '2013', '2016', '2019', '2021']
keywords = ['excel', 'standard', 'plus']

# Initialize a dictionary to hold the count for each year and keyword combination
year_keyword_counts = {}

# Count rows where COLLECTED_SW_NAME contains both the year and each keyword
for year in years_of_interest:
    for keyword in keywords:
        key = f'{year} and {keyword}'
        
        # Make the search case-insensitive and strip any leading/trailing spaces
        filtered_rows = df[
            df['COLLECTED_SW_NAME'].str.contains(year, case=False, na=False) &
            df['COLLECTED_SW_NAME'].str.contains(keyword, case=False, na=False)
        ]
        
        # Check if we found any matching rows and store the count
        count = filtered_rows.shape[0]
        
        # Store the count in the dictionary for each year and keyword combination
        year_keyword_counts[key] = count

# Add the "LTSC" condition but not containing any year
ltsa_condition = 'LTSC but not year'
ltsa_filtered_rows = df[
    df['COLLECTED_SW_NAME'].str.contains('LTSC', case=False, na=False) & 
    ~df['COLLECTED_SW_NAME'].str.contains('|'.join(years_of_interest), case=False, na=False)
]
ltsa_count = ltsa_filtered_rows.shape[0]

# Append rows for each of the year and keyword combinations to the DataFrame
year_keyword_rows = []
for key, count in year_keyword_counts.items():
    year, keyword = key.split(' and ')
    year_keyword_row = pd.DataFrame({'COMPUTER_NAME': [f'Total ({year} and {keyword})'], 'COLLECTED_SW_NAME': [f'Rows with {year} and {keyword}: {count}']})
    year_keyword_rows.append(year_keyword_row)

# Add LTSC condition row
ltsa_row = pd.DataFrame({'COMPUTER_NAME': ['Total (LTSC but not year)'], 'COLLECTED_SW_NAME': [f'Rows with LTSC but not containing year: {ltsa_count}']})
year_keyword_rows.append(ltsa_row)

df = pd.concat([df] + year_keyword_rows, ignore_index=True)

# Option menu function
def display_menu():
    print(f"1. Show Total Rows = {total_rows}")
    print(f"2. Show All Duplicated Rows = {total_duplicated_rows}")
    for key, count in year_keyword_counts.items():
        print(f"3. Show Total Rows with {key} = {count}")  # Option to show the count for each year and keyword
    print(f"4. Show Total Rows with LTSC but not containing year = {ltsa_count}")  # New option for LTSC but not containing year
    return input("Select an option (1, 2, 3, or 4): ")

# Function to show total rows
def show_total_rows():
    print(f"\nTotal Rows: {total_rows}")

# Function to show all duplicated rows
def show_duplicated_rows():
    print("\nDuplicated COMPUTER_NAMEs:")
    for name, count in duplicated_computer_names:
        print(f"  - {name}: {count - 1}")

# Filter DataFrame to only include duplicated COMPUTER_NAME rows
duplicated_df = df[df['COMPUTER_NAME'].isin([name for name, _ in duplicated_computer_names])]

# Main loop for menu selection
while True:
    choice = display_menu()
    if choice == '1':
        show_total_rows()
    elif choice == '2':
        show_duplicated_rows()
    elif choice in [str(i+3) for i in range(len(year_keyword_counts))]:  # Options for each year and keyword combination
        index = int(choice) - 3
        key = list(year_keyword_counts.keys())[index]
        print(f"\nTotal Rows with {key}: {year_keyword_counts[key]}")
    elif choice == '4':  # Option for LTSC but not containing year
        print(f"\nTotal Rows with LTSC but not containing year: {ltsa_count}")
    else:
        print("Invalid option. Please try again.")
        continue
    
    user_input = input("\nDo you want to view the data? (y/n): ")
    if user_input.lower() == 'y':
        # Decide which DataFrame to paginate based on the user's choice
        df_to_paginate = duplicated_df if choice == '2' else df
        break
    elif user_input.lower() == 'n':
        print("Exiting program.")
        exit()
    else:
        print("Invalid input. Returning to menu.")

# Pagination function for data with strict row limit and standard index
def paginate_dataframe(df, page_size=1000):
    num_pages = (len(df) - 1) // page_size + 1
    for page in range(num_pages):
        start = page * page_size
        end = start + page_size
        page_df = df.iloc[start:end].head(page_size).reset_index(drop=True)  # Reset index
        yield page + 1, page_df, num_pages

# Convert generator to list for backward navigation
pages = list(paginate_dataframe(df_to_paginate))

# Display pages with navigation
current_page = 0
while True:
    page_number, page_df, num_pages = pages[current_page]
    print(f"\n--- Page {page_number} of {num_pages} ---")
    with pd.option_context('display.max_rows', None, 'display.max_columns', None, 'display.width', None):
        print(page_df)
    
    # Navigation prompt for data
    if current_page == 0:
        user_input = input("Press Enter for next page or 'q' to quit: ")
    else:
        user_input = input("Press Enter for next page, 'p' for previous page, or 'q' to quit: ")
    
    if user_input.lower() == 'q':
        break
    elif user_input.lower() == 'p' and current_page > 0:
        current_page -= 1
    elif user_input == '':  # Enter key for next page
        if current_page + 1 < len(pages):
            current_page += 1
        else:
            print("You are on the last page.")
    else:
        print("Invalid input. Use 'p' for previous, Enter for next, or 'q' to quit.")
