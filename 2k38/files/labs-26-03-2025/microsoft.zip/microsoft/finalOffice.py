import csv

def read_csv(file_path):
    with open(file_path, mode='r', encoding='utf-8') as file:
        reader = csv.DictReader(file)
        return list(reader)

# Read CSV files
csv1_data = read_csv('data/final_results_10-02-2025.csv')
csv2_data = read_csv('data/Office.csv')

# Mapping for easier comparison (adjust based on exact matches if necessary)
mapping = {
    '2007 and excel': 'Microsoft Excel 2007',
    '2007 and standard': 'Microsoft Office Standard 2007',
    '2007 and plus': 'Microsoft Office Professional Plus 2007',
    '2010 and excel': 'Microsoft Excel 2010',
    '2010 and standard': 'Microsoft Office Standard 2010',
    '2010 and plus': 'Microsoft Office Professional Plus 2010',
    '2013 and excel': 'Microsoft Excel 2013',
    '2013 and standard': 'Microsoft Office Standard 2013',
    '2013 and plus': 'Microsoft Office Professional Plus 2013',
    '2016 and excel': 'Microsoft Excel 2016',
    '2016 and standard': 'Microsoft Office Standard 2016',
    '2016 and plus': 'Microsoft Office Professional Plus 2016',
    '2019 and excel': 'Microsoft Excel 2019',
    '2019 and standard': 'Microsoft Office Standard 2019',
    '2019 and plus': 'Microsoft Office Professional Plus 2019',
    '2021 and excel': 'Microsoft Excel 2021 LTSC',
    '2021 and standard': 'Microsoft Office LTSC Standard 2021',
    '2021 and plus': 'Microsoft Office LTSC Professional Plus 2021',
}

total_balance = 0
results = []

for row in csv1_data:
    if row['Metric'] in mapping:
        for item in csv2_data:
            if item['Licenças'] == mapping[row['Metric']]:
                difference = int(item['Quantidade de licenças']) - int(row['Count'])
                total_balance += difference
                results.append([row['Metric'], difference])
                break

# Append total balance to results
results.append(['Total', total_balance])

# Write results to CSV
with open('BalancoReal.csv', 'w', newline='', encoding='utf-8') as csvfile:
    writer = csv.writer(csvfile)
    writer.writerow(['Metric', 'Difference'])
    writer.writerows(results)

# Print total balance
print(f"Total Balance: {total_balance}")