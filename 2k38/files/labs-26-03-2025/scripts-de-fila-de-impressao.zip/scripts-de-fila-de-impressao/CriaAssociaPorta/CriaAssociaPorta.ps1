Set-Location $PSScriptRoot
$Error.Clear()
$host.ui.RawUI.WindowTitle = "Cria porta e associa"

# Importacoes
.".\ArquivosBase\Menu.ps1"

$dados = Import-Csv -Path ".\Filas.csv" -Delimiter ";"

Write-Host `n"As filas da lista Filas.csv serão alteradas nos servidores escolhidos" -ForegroundColor Yellow
Write-Host "Enter para continuar ou Control+C para encerrar" -ForegroundColor Yellow
pause

function criaPorta($servidor, $fila) {
    $etiqueta = $fila | Select-String -Pattern "ETQ" -SimpleMatch
    $LPName = $fila + ".magazineluiza.intranet"

    if ($etiqueta) {
        try {
            Add-PrinterPort -name $fila -CimSession $servidor -LprQueueName "LP" -LprHostAddress $LPName -AsJob | Out-Null
            Write-Host " - Porta criada com sucesso"
        }
        catch {
            Write-Host " - Erro ao criar porta" $Error[0] -ForegroundColor Red
        }
    }
    else {
        try {
            Add-PrinterPort -name $fila -CimSession $servidor -LprQueueName $fila -LprHostAddress $LPName -AsJob | Out-Null
            Write-Host " - Porta criada com sucesso"
        }
        catch {
            Write-Host " - Erro ao criar porta" $Error[0] -ForegroundColor Red
        }
    }
     
}

function associaPorta($servidor, $fila) {
    try {
        Invoke-Command -ComputerName $servidor -ScriptBlock { Set-Printer -Name $Using:fila -PortName $Using:fila -ErrorAction Stop }
        Write-Host " - Associado com sucesso"
    }
    catch {
        Write-Host " - Erro ao associar porta" $Error[0] -ForegroundColor Red
    }
}

Write-Host `n"Verificando e criando portas"`n -ForegroundColor Blue

foreach ($servidor in $servidores) {

    Write-Host `n$servidor -ForegroundColor Cyan
    
    $dados | ForEach-Object {

        $fila = $_.Filas

        try {
            $portaExiste = Get-PrinterPort -Name $fila -CimSession $servidor -ErrorAction Stop
        }
        catch {
        }
        
        if ($portaExiste) {
            Write-Host "Porta $fila ja existe" -ForegroundColor Yellow
        }
        else {
            Write-Host -NoNewline "Porta $fila criada"
            criaPorta $servidor $fila
        }
    }
}

Write-Host "Processando criacao de portas, aguarde ..."
Start-Sleep -Seconds 10

Write-Host "Associando portas" -ForegroundColor Blue

foreach ($servidor in $servidores) {

    Write-Host `n$servidor -ForegroundColor Cyan

    $dados | ForEach-Object {

        $fila = $_.Filas

        try {
            $portaExiste = Get-PrinterPort -Name $fila -CimSession $servidor -ErrorAction Stop
        }
        catch {
        }
        
        if ($portaExiste) {
            Write-Host -NoNewline "Porta $fila"
            associaPorta $servidor $fila
        }
        else {
            Write-Host "Porta nao foi criada" -ForegroundColor Red
        }
    }
}

Write-Host `n"Processo finalizado, pressione Enter para finalizar"`n
pause

