$servidores = @("")
$opcao = ""

$opt1 = "GemcoVB"
$opt2 = "Aguia"
$opt3 = "NF"
$opt4 = "Banguela"
$opt5 = "WMS"
$opt6 = "Farm_1"
$opt7 = "Farm_2"
$opt8 = "Farm_3"
$opt9 = "Farm_4"
$opt10 = "Faturamento_loja"

While ($opcao -eq "" -or !$opcao -or $opcao.Length -gt 2) {
    Clear-Host
    Write-Host ""
    Write-Host "Escolha um servidor"
    Write-Host "-----------------------------------------------"
    Write-Host "1 - $opt1"
    Write-Host "2 - $opt2"
    Write-Host "3 - $opt3"
    Write-Host "4 - $opt4"
    Write-Host "5 - $opt5"
    Write-Host "6 - $opt6"
    Write-Host "7 - $opt7"
    Write-Host "8 - $opt8"
    Write-Host "9 - $opt9"
    Write-Host "10 - $opt10"
    Write-Host "-----------------------------------------------"
    $opcao = Read-host "Digite a opcao desejada"
    if ($opcao -eq "" -or !$opcao -or $opcao.Length -gt 2) {
        Write-Host("Opcao invalida"); Start-Sleep 2
        Clear-Host
    }
}

switch ($opcao) {
    1 { $servidores = Get-Content ".\ArquivosBase\Servidores\$opt1.txt"; }
    2 { $servidores = Get-Content ".\ArquivosBase\Servidores\$opt2.txt"; }
    3 { $servidores = Get-Content ".\ArquivosBase\Servidores\$opt3.txt"; }
    4 { $servidores = Get-Content ".\ArquivosBase\Servidores\$opt4.txt"; }
    5 { $servidores = Get-Content ".\ArquivosBase\Servidores\$opt5.txt"; }
    6 { $servidores = Get-Content ".\ArquivosBase\Servidores\$opt6.txt"; }
    7 { $servidores = Get-Content ".\ArquivosBase\Servidores\$opt7.txt"; }
    8 { $servidores = Get-Content ".\ArquivosBase\Servidores\$opt8.txt"; }
    9 { $servidores = Get-Content ".\ArquivosBase\Servidores\$opt9.txt"; }
    10 { $servidores = Get-Content ".\ArquivosBase\Servidores\$opt10.txt"; }
}