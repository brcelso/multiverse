function processoGemcoVB () {

    $dominio = "magazineluiza.intranet"
    $permissaoAlterada = ".\ArquivosTemporarios\permissaoAlteradaGemco.txt"

    Remove-Item -Recurse -Force -Path ".\ArquivosTemporarios\*" -ErrorAction SilentlyContinue

    try {
        $permissaoPadrao = Get-Content ".\PermissoesPadrao\GemcoVB.txt"

        #Atribui permissao padrao ao arquivo temporario antes de adicionar as permissoes esejadas
        Set-Content -NoNewline -Path $permissaoAlterada -Value $permissaoPadrao
    }
    catch {
        ShowErrorMessage -message "Arquivo de permissao padrao nao foi encontrado, encerrando aplicacao"
        Pause
        exit
    }

    ShowInfoMessage -message $mensagem_lancando_criacao_portas

    $dados | ForEach-Object {
        $fila = $_.Filas
        Write-Host "Fila $fila"
        CriaPorta -fila $fila -dominio $dominio
    }

    Loading -message $mensagem_processando_criacao_portas
    
    ShowInfoMessage -message $mensagem_lancando_criacao_filas

    $dados | ForEach-Object {
        $fila = $_.Filas
        $driver = $_.Drivers
        $permissoes = $_.Permissoes
            
        Write-Host "Fila $fila"
        criaFilaGemcoVB -fila $fila -driver $driver -permissoes $permissoes
    }

    Loading -message $mensagem_processando_criacao_filas

    VerificaCriacao

    ShowAlertMessage -message $mensagem_processo_finalizado
    pause
    exit
}

function CriaFilaGemcoVB($fila, $driver, $permissoes) {
    try {
        if ($permissoes) {
            $permissoes -split (",") | ForEach-Object {
                try {
                    $permissao = $_.trim()
                    $NomeDaPermissao = New-Object System.Security.Principal.NTAccount($permissao)
                    $SID = $NomeDaPermissao.Translate([System.Security.Principal.SecurityIdentifier])
                    $SDDLString = "A;;SWRC;;;" + $SID + ")"
                    Add-Content -NoNewline -Path ".\ArquivosTemporarios\permissaoAlteradaGemco.txt" -Value $SDDLString
                }
                catch {
                    $_error = $Error[0]
                    ShowAlertMessage -message "Falha ao localizar permissão: $_error"
                }
            }
        }

        $permissaoGemcoVB = Get-Content ".\ArquivosTemporarios\permissaoAlteradaGemco.txt"
                
        Add-Printer -Name $fila -CimSession $servidores -DriverName $driver -PortName $fila -PermissionSDDL $permissaoGemcoVB -AsJob | Out-Null

        Remove-Item -Recurse -Force -Path ".\ArquivosTemporarios\*" #exclui a permissao para a criacao da proxima fila
    }
    catch {
        $_error = $Error[0]
        ShowAlertMessage -message "Erro ao incluir a fila: $_error"
    }
}