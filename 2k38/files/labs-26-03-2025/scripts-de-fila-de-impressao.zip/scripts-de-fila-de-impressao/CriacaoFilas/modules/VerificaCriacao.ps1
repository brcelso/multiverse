function VerificaCriacao() {

   ShowAlertMessage -message $mensagem_verificacao_filas

    $filasEsperadas = @()

    $dados | ForEach-Object {
        $filaEsperada = TrimAndRemoveSpaces -text $_.Filas

        if ($filaEsperada -ne "") {
            $filasEsperadas += $filaEsperada
        }
    }

    foreach ($servidor in $servidores) {

        ShowHeaderMessage -message "`n$servidor"

        if ($servidor -eq $global:hostname) {
            $filasDoServidor = (Get-Printer | Select-Object -ExpandProperty Name)
        } else {
            $filasDoServidor = (Get-Printer -CimSession $servidor | Select-Object -ExpandProperty Name)
        }

        $filasNaoEncontradas = $filasEsperadas | Where-Object { $_ -notin $filasDoServidor }

        if ($filasNaoEncontradas.Count -eq 0) {
            ShowMessage -message "Todas as filas foram criadas com sucesso"
        } else {
            foreach ($fila in $filasNaoEncontradas) {
                ShowAlertMessage -message "Fila $fila - nao encontrada"
            }
        }
    }
}

function VerificaCriacaoComputerName() {

    ShowAlertMessage -message $mensagem_verificacao_filas
 
     $filasEsperadas = @()
 
     $dados | ForEach-Object {
         $filaEsperada = TrimAndRemoveSpaces -text $_.Filas
 
         if ($filaEsperada -ne "") {
             $filasEsperadas += $filaEsperada
         }
     }
 
     foreach ($servidor in $servidores) {
 
         ShowHeaderMessage -message "`n$servidor"
 
         if ($servidor -eq $global:hostname) {
             $filasDoServidor = (Get-Printer | Select-Object -ExpandProperty Name)
         } else {
             $filasDoServidor = (Get-Printer -ComputerName $servidor | Select-Object -ExpandProperty Name)
         }
 
         $filasNaoEncontradas = $filasEsperadas | Where-Object { $_ -notin $filasDoServidor }
 
         if ($filasNaoEncontradas.Count -eq 0) {
             ShowMessage -message "Todas as filas foram criadas com sucesso"
         } else {
             foreach ($fila in $filasNaoEncontradas) {
                 ShowAlertMessage -message "Fila $fila - nao encontrada"
             }
         }
     }
 }