function processoWMS() {

    $dominio = "magazineluiza.intranet"

    ShowInfoMessage -message $mensagem_lancando_criacao_portas

    $dados | ForEach-Object {
        $fila = $_.Filas
        Write-Host "Fila $fila"
        CriaPortaWMS -fila $fila -dominio $dominio
    }

    Loading -message $mensagem_processando_criacao_portas

    ShowInfoMessage -message $mensagem_lancando_criacao_filas
    
    $dados | ForEach-Object {
        $fila = $_.Filas
        $driver = $_.Drivers

        ShowMessage -message "Fila $fila"
        criaFilaWMS -fila $fila -driver $driver
    }

    Loading -message $mensagem_processando_criacao_filas
    
    VerificaCriacao

    ShowAlertMessage -message $mensagem_processo_finalizado
    pause
    exit
}

function CriaPortaWMS($fila, $dominio) {

    $fila = TrimAndRemoveSpaces -text $fila
    $LPName = $fila + "." + $dominio
    $Etiqueta = $fila | Select-String -Pattern "ETQ" -SimpleMatch

    if ($etiqueta) {
        try {
            Add-PrinterPort -name $fila -CimSession $servidores -LprQueueName "LP" -LprHostAddress $LPName -LprByteCounting -AsJob | Out-Null
        }
        catch {
            $_error = $Error[0]
            ShowAlertMessage -message "Erro ao incluir a porta: $_error"
        }
    }
    else {
        try {
            Add-PrinterPort -name $fila -CimSession $servidores -LprQueueName $fila -LprHostAddress $LPName -LprByteCounting -AsJob | Out-Null
        }
        catch {
            $_error = $Error[0]
            ShowAlertMessage -message "Erro ao incluir a porta: $_error"
        }
    }
}

function criaFilaWMS($fila, $driver) {

    $fila = TrimAndRemoveSpaces -text $fila
    $driver = $driver.Trim()

    try {
        $permissaoWMS = Get-Content ".\PermissoesPadrao\WMS.txt" -ErrorAction Stop
        Add-Printer -Name $fila -CimSession $servidores -DriverName $driver -PortName $fila -Shared -ShareName $fila -PermissionSDDL $permissaoWMS -AsJob | Out-Null
    }
    catch {
        $_error = $Error[0]
        ShowErrorMessage -message "Erro ao incluir a fila: $_error"
    }
}
