function processoBanguela() {

    $dominio = "magazineluiza.intranet"
    $wait_time = 60

    ShowInfoMessage -message $mensagem_lancando_criacao_portas

    $dados | ForEach-Object {
        $fila = $_.Filas
        Write-Host "Fila $fila"
        CriaPortaComputerName -fila $fila -dominio $dominio
    }

    Loading -message $mensagem_processando_criacao_portas

    ShowInfoMessage -message $mensagem_lancando_criacao_filas
    
    $dados | ForEach-Object {
        $fila = $_.Filas
        $driver = $_.Drivers

        ShowMessage -message "Fila $fila"
        CriaFilaBanguela -fila $fila -driver $driver
    }

    Loading -message $mensagem_processando_criacao_filas
    
    VerificaCriacaoComputerName

    ShowAlertMessage -message $mensagem_processo_finalizado
    pause
    exit
}

function CriaFilaBanguela($fila, $driver) {

    $fila = TrimAndRemoveSpaces -text $fila
    $driver = $driver.Trim()

    foreach ($servidor in $servidores) {
        try {
            if ($servidor -eq $global:hostname) {
                Add-Printer -Name $fila -DriverName $driver -PortName $fila -Shared -ShareName $fila -AsJob | Out-Null
            }
            else {
                Add-Printer -Name $fila -ComputerName $servidor -DriverName $driver -PortName $fila -Shared -ShareName $fila -AsJob | Out-Null
            }
        }

        catch {
            $_error = $Error[0]
            ShowErrorMessage -message "Erro ao incluir a fila: $_error"
        }
    } 
}