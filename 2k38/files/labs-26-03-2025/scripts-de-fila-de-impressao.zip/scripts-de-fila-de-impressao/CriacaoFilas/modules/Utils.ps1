function TrimAndRemoveSpaces($text) {
    $trim = $text.Trim()
    $cleanString = $trim.replace(" ", "")
    return $cleanString
}

function Loading($message) {
    Write-Host ""
    for ($i = 1; $i -le $wait_time; $i++) {
        $counter = [Math]::Round(($i / $wait_time) * 100)
        Write-Host -NoNewline `r"$message $counter% processados" -ForegroundColor $primary_color
        Start-Sleep -Seconds 1
    }
    Write-Host ""
}

function ShowMessage($message) {
    Write-Host $message
}

function ShowHeaderMessage($message) {
    Write-Host $message -ForegroundColor $global:secondary_color
}

function ShowInfoMessage($message) {
    Write-Host $message -ForegroundColor $global:primary_color
}

function ShowAlertMessage($message) {
    Write-Host $message -ForegroundColor $global:alert_color
}

function ShowErrorMessage($message) {
    Write-Host $message -ForegroundColor $global:error_color
}