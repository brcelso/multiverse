function processoAguia() {

    $dominio = "magazineluiza.intranet"

    ShowInfoMessage -message $mensagem_lancando_criacao_portas

    $dados | ForEach-Object {
        $fila = $_.Filas
        Write-Host "Fila $fila"
        CriaPorta -fila $fila -dominio $dominio
    }

    Loading -message $mensagem_processando_criacao_portas

    ShowInfoMessage -message $mensagem_lancando_criacao_filas
    
    $dados | ForEach-Object {
        $fila = $_.Filas
        $driver = $_.Drivers

        ShowMessage -message "Fila $fila"
        CriaFilaAguia -fila $fila -driver $driver
    }

    Loading -message $mensagem_processando_criacao_filas
    
    VerificaCriacao

    ShowAlertMessage -message $mensagem_processo_finalizado
    pause
    exit
}

function CriaFilaAguia($fila, $driver) {

    $fila = TrimAndRemoveSpaces -text $fila
    $driver = $driver.Trim()

    try {
        Add-Printer -Name $fila -CimSession $servidores -DriverName $driver -PortName $fila -AsJob | Out-Null
    }
    catch {
        $_error = $Error[0]
        ShowErrorMessage -message "Erro ao incluir a fila: $_error"
    }
}