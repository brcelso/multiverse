function processoFarm () {

    $dominio = "lojas.magazineluiza.intranet"
    $permissaoAlterada = ".\ArquivosTemporarios\permissaoAlteradaFarm.txt"

    Remove-Item -Recurse -Force -Path ".\ArquivosTemporarios\*" -ErrorAction SilentlyContinue

    try {
        $permissaoFarm = Get-Content ".\PermissoesPadrao\Farm.txt"

        #Atribui permissao padrao ao arquivo temporario antes de adicionar as permissoes esejadas
        Set-Content -NoNewline -Path $permissaoAlterada -Value $permissaoFarm
    }
    catch {
        ShowErrorMessage -message "Arquivo de permissao padrao nao foi encontrado, encerrando aplicacao"
        Pause
        exit
    }

    ShowInfoMessage -message $mensagem_lancando_criacao_portas

    $dados | ForEach-Object {
        $fila = $_.Filas
        Write-Host "Fila $fila"
        CriaPorta -fila $fila -dominio $dominio
    }

    Loading -message $mensagem_processando_criacao_portas
    
    ShowInfoMessage -message $mensagem_lancando_criacao_filas

    $dados | ForEach-Object {
        $fila = $_.Filas
        $driver = $_.Drivers
        $permissoes = $_.Permissoes
            
        Write-Host "Fila $fila"
        criaFilaFarm -fila $fila -driver $driver -permissoes $permissoes
    }

    Loading -message $mensagem_processando_criacao_filas

    VerificaCriacao

    ShowAlertMessage -message $mensagem_processo_finalizado
    pause
    exit
}

function CriaFilaFarm($fila, $driver, $permissoes) {
    try {
        if ($permissoes) {
            $permissoes -split (",") | ForEach-Object {
                try {
                    $permissao = $_.trim()
                    $NomeDaPermissao = New-Object System.Security.Principal.NTAccount($permissao)
                    $SID = $NomeDaPermissao.Translate([System.Security.Principal.SecurityIdentifier])
                    $SDDLString = "(A;;SWRC;;;" + $SID + ")"
                    Add-Content -NoNewline -Path $permissaoAlterada -Value $SDDLString
                }
                catch {
                    $_error = $Error[0]
                    ShowAlertMessage -message "Falha ao localizar permissão: $_error"
                }
            }
        }

        $permissaoFarm = Get-Content $permissaoAlterada
      
        Add-Printer -Name $fila -CimSession $servidores -DriverName $driver -PortName $fila -PermissionSDDL $permissaoFarm -AsJob | Out-Null

        Remove-Item -Recurse -Force -Path ".\ArquivosTemporarios\*" #exclui a permissao para a criacao da proxima fila
    }
    catch {
        $_error = $Error[0]
        ShowAlertMessage -message "Erro ao incluir a fila: $_error"
    }
}