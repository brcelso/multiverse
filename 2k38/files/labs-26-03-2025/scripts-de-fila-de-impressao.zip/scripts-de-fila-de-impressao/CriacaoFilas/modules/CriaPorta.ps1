function CriaPorta($fila, $dominio) {

    $fila = TrimAndRemoveSpaces -text $fila
    $LPName = $fila + "." + $dominio
    $Etiqueta = $fila | Select-String -Pattern "ETQ" -SimpleMatch

    if ($Etiqueta) {
        Add-PrinterPort -name $fila -CimSession $servidores -LprQueueName "LP" -LprHostAddress $LPName -AsJob | Out-Null
    }
    else {
        Add-PrinterPort -name $fila -CimSession $servidores -LprQueueName $fila -LprHostAddress $LPName -AsJob | Out-Null
    }
}

function CriaPortaComputerName($fila, $dominio) {

    $fila = TrimAndRemoveSpaces -text $fila
    $LPName = $fila + "." + $dominio
    $Etiqueta = $fila | Select-String -Pattern "ETQ" -SimpleMatch

    foreach ($servidor in $servidores) {
        if ($etiqueta) {
            try {
                Add-PrinterPort -name $fila -ComputerName $servidor -LprQueueName "LP" -LprHostAddress $LPName -AsJob | Out-Null
            }
            catch {
                $_error = $Error[0]
                ShowAlertMessage -message "Erro ao incluir a porta: $_error"
            }
        }
        else {
            try {
                Add-PrinterPort -name $fila -ComputerName $servidor -LprQueueName $fila -LprHostAddress $LPName -AsJob| Out-Null
            }
            catch {
                $_error = $Error[0]
                ShowAlertMessage -message "Erro ao incluir a porta: $_error"
            }
        }
    }
}