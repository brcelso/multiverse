Set-Location $PSScriptRoot #Carrega o caminho da pasta atual
$Error.Clear()
$host.ui.RawUI.WindowTitle = "Criacao de filas de impressao"

# Importacoes
.".\modules\Menu.ps1"
.".\config\config.ps1"
.".\modules\Utils.ps1"
.".\modules\CriaPorta.ps1"
.".\modules\GemcoVB.ps1"
.".\modules\Aguia.ps1"
.".\modules\NF.ps1"
.".\modules\WMS.ps1"
.".\modules\Banguela.ps1"
.".\modules\FaturamentoLoja.ps1"
.".\modules\Farm.ps1"
.".\modules\Pimaco.ps1"
.".\modules\VerificaCriacao.ps1"

while ($resposta -ne "s" -and $resposta -ne "n") {
    Write-Host `n"AVISO: Ao continuar as filas incluidas no arquivo CSV $opcaoSelecionada serao criadas, deseja continuar? (s/n):" -NoNewline -ForegroundColor $global:alert_color
    $resposta = Read-Host

    if ($resposta -ne "s" -and $resposta -ne "n") {
        $resposta = ""
        Write-Host `n"Resposta invalida, digite somente s ou n"`n -ForegroundColor $global:alert_color
    }

    if($resposta -eq "n") {
        ShowMessage -message $mensagem_processo_finalizado
        Pause
        Exit
    }
}

if ($resposta -eq "s") { 
    switch ($opcaoSelecionada) {
        "GemcoVB" { processoGemcoVB }
        "Aguia" { processoAguia }
        "NF" { processoNF }
        "Banguela" { processoBanguela }
        "WMS" { processoWMS }
        "Farm1" { processoFarm }
        "Farm2" { processoFarm }
        "Farm3" { processoFarm }
        "Farm4" { processoFarm }
        "Faturamento_loja" { processoFaturamentoLoja }
        "Reimpressao_notas" { processoFaturamentoLoja }
        "Pimaco" { processoPimaco }
    }
}
else {
    Write-Host `n`n"Aplicacao encerrada, pressione enter para fechar"
    Pause
}