$_hostname = (Get-CimInstance -ClassName Win32_ComputerSystem).Name
$_domain = (Get-CimInstance -ClassName Win32_ComputerSystem).Domain
$global:hostname = "$_hostname.$_domain"

$wait_time = 30

if ($dados.Count -le 10) {
    $wait_time = 30
}
elseif ($dados.Count -le 50) {
    $wait_time = 60
}
elseif ($dados.Count -le 100) {
    $wait_time = 120
}
else {
    $wait_time = 300
}

$global:primary_color = "Cyan"
$global:secondary_color = "DarkCyan"
$global:alert_color = "Yellow"
$global:error_color = "Red"

$mensagem_lancando_criacao_portas = "`nLancando comando de criacao de portas"
$mensagem_processando_criacao_portas = "Processando comando de criacao de portas:"
$mensagem_lancando_criacao_filas = "`nLancando comando de criacao de filas"
$mensagem_processando_criacao_filas = "Processando comando de criacao de filas:"
$mensagem_processo_finalizado = "`nProcesso finalizado, pressione enter para encerrar"
$mensagem_verificacao_filas = "`nVerificando filas nos servidores"