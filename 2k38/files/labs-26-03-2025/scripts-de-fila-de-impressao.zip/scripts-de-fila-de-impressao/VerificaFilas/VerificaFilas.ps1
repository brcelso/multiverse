Set-Location $PSScriptRoot
$Error.Clear()

$resposta = "s"
$fila = ""

# Importacoes
.".\ArquivosBase\Menu.ps1"

while ($resposta -eq "s") {

    Write-Host ""
    $fila = Read-Host "Digite o nome da fila a ser consultada"

    while ($fila -eq "" -or !$fila -or $fila.Length -lt 4) {
        
        if ($fila -eq "" -or !$fila -or $fila.Length -lt 4) {
            Write-Host "Digite o nome da fila corretamente" -ForegroundColor Yellow
        }

        Write-Host ""
        $fila = Read-Host "Digite o nome da fila a ser consultada"
    }

    Write-Host ""
    $mostrar_permissoes = Read-Host "Tambem exibir permissoes ? (s / n)"

    while ($mostrar_permissoes -eq "" -or !$mostrar_permissoes -or $mostrar_permissoes -ne "s" -and $mostrar_permissoes -ne "n") {
        
        if ($fila -eq "" -or !$fila -or $fila.Length -lt 4) {
            Write-Host "Valor inválido" -ForegroundColor Yellow
        }

        Write-Host ""
        $fila = Read-Host "Tambem exibir permissoes ? (s / n)"
    }


    foreach ($servidor in $servidores) {

        Write-Host ""
        Write-Host ""
        Write-Host "Servidor $servidor" -ForegroundColor Green -BackgroundColor Black
        Write-Host ""

        try {
            Write-Host "Detalhes da porta" -ForegroundColor DarkBlue
            Get-PrinterPort -CimSession $servidor -Name $fila | Select-Object Name, Protocol, Description, LprByteCounting, LprQueueName, PrinterHostAddress -ErrorAction Stop
        }
        catch {
            Write-Host "Erro ao buscar a porta no servidor $servidor" $Error[0] -ForegroundColor Red
        }


        try {
            Write-Host "Detalhes da fila" -ForegroundColor DarkBlue
            
            Get-Printer -CimSession $servidor -Name $fila | Select-Object PrinterStatus, Name, Datatype, DriverName, PortName -ErrorAction Stop
            
            
            $jobs = Get-PrintJob -PrinterName $fila -CimSession $servidor | Select-Object Id -ExpandProperty Id
            Write-Host "Trabalho de impressao: " $jobs.count "trabalho[s]"
            
            Write-Host ""
            
            if ($mostrar_permissoes -eq "s") {
                Write-Host "Permissoes:"
                $sddl = Get-Printer -CimSession $servidor -Name $fila -full | Select-Object -ExpandProperty PermissionSDDL -ErrorAction Stop
                $permissoes = ConvertFrom-SddlString -Sddl $sddl | Foreach-Object { $_.DiscretionaryAcl }
            
                foreach ($permissao in $permissoes) {
                    $string = $permissao -split ":"
                    Write-Host $string[0]
                }
            }
        }
        catch {
            Write-Host "Erro ao buscar a fila no servidor $servidor" $Error[0] -ForegroundColor Red
        }
    }
   
    $resposta = Read-Host "Deseja pesquisar outra fila do mesmo servidor (s / n)"

    while ($resposta -ne "s" -and $resposta -ne "n") {

        
        if ($resposta -ne "s" -and $resposta -ne "n") {
            Write-Host "Responda somente s ou n" -ForegroundColor Yellow
            Write-Host ""
        }
        
        $resposta = Read-Host "Deseja pesquisar outra fila do mesmo servidor (s / n)"

    }

    if ($resposta -eq "s") {
        Clear-Host
    }

}

Write-Host `n `n "Processo finalizado" -ForegroundColor Green
Pause

