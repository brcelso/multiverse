﻿Set-Location $PSScriptRoot

# Importacoes
.".\ArquivosBase\Menu.ps1"

$fila = ""

While ($fila -eq "") {
    $fila = Read-Host `n"Insira o nome da fila a ser limpa"
    if ($fila -eq "") {
        Write-Host `n"E necessario preencher o nome da fila a ser limpa" -ForegroundColor Red
    }
    else {
        Write-Host `n"Verificando se fila existe..."

        if ($opcaoSelecionada -eq "WMS") {
            $verificaSeFilaExiste = Get-Printer -Name $fila -ComputerName $servidores[0] -ErrorAction SilentlyContinue
            if (-not $verificaSeFilaExiste) {
                Write-Host `n"Fila $fila nao existe nos servidores $opcaoSelecionada" -ForegroundColor Red
                $fila = ""
            }
        }
        # elseif ($identificador -eq "WMS_Linux") {
        #     $host_remoto = $servidores[0]
        #     $password = ConvertTo-SecureString "sythex" -AsPlainText -Force
        #     $credential = New-Object System.Management.Automation.PSCredential ("usr_sythex", $password)

        #     # Comando para verificar a existência da fila de impressão no sistema remoto
        #     $comando_remoto = "lpstat -p '$fila'"

        #     try {
        #         $sshSession = New-SSHSession -ComputerName $host_remoto -Port 22 -AcceptKey -Credential $credential
        #         $retorno_linux = Invoke-SSHCommand -Index 0 -Command $comando_remoto
        #         Remove-SSHSession -Index 0 | Out-Null
        #     }
        #     catch {
        #         Write-Host "Ocorreu um erro ao verificar a fila de impressão no sistema remoto"
        #     }

        #     $erro = $retorno_linux | Select-Object -ExpandProperty Error

        #     if ($erro -ne "") {
        #         Write-Host "A fila de impressão $fila não existe nos servidores $identificador."
        #         $fila = "" 
        #     }
        # }
        # else {
        $verificaSeFilaExiste = Get-Printer -Name $fila -CimSession $servidores[0] -ErrorAction SilentlyContinue
        if (-not $verificaSeFilaExiste) {
            Write-Host `n"Fila $fila nao existe nos servidores $opcaoSelecionada" -ForegroundColor Red
            $fila = ""
        }
        # }
    }
        
}

Write-Host `n"A fila $fila tera todos os seus trabalhos cancelados nos servidores $opcaoSelecionada" -ForegroundColor Yellow
Write-Host "Enter para continuar ou Control+C para encerrar" -ForegroundColor Yellow
pause

    
Write-Host `n"Limpando a fila $fila ..."`n -ForegroundColor Blue
    
foreach ($servidor in $servidores) {
        
    Write-Host `n"Servidor" $servidor -ForegroundColor Cyan

    if ($opcaoSelecionada -eq "WMS") {
        try {
            $jobsWMS = Get-PrintJob -PrinterName $fila -ComputerName $servidor | Select-Object Id -ExpandProperty Id
        }
        catch {
            Write-Host "Falha ao localizar impressões, servidor indisponível" -ForegroundColor Red
        }
    
        if ($jobsWMS) {
            Write-Host "Limpando" $jobsWMS.count "trabalho[s] ..." -ForegroundColor Yellow
            foreach ($job in $jobsWMS) {
                Remove-PrintJob -PrinterName $fila -ID $job -ComputerName $servidor -ErrorAction SilentlyContinue         
            }
            Write-Host "Todos os trabalhos foram excluídos com sucesso"
        }
        else {
            Write-Host "Nao ha impressões pendentes na fila"
        }
    }
    # elseif ($identificador -eq "WMS_Linux") {
    #     $usuario_remoto = "usr_sythex"
    #     $password = ConvertTo-SecureString "sythex" -AsPlainText -Force
    #     $credential = New-Object System.Management.Automation.PSCredential ("usr_sythex", $password)
            
    #     try {
    #         $ssh_session = New-SSHSession -ComputerName $host_remoto -Port 22 -AcceptKey -Credential $credential
    #         $stream = $ssh_session.Session.CreateShellStream("PS-SSH", 0, 0, 0, 0, 100)
    #         $result_stream = Invoke-SSHStreamExpectSecureAction -ShellStream $stream -Command "sudo su -" -ExpectString "Senha para usr_sythex em localhost?" -SecureAction $password -Verbose
    #         $stream_return = $stream.Read()
    #         $stream.WriteLine("cancel -a $fila")
    #         Start-Sleep -Seconds 5
    #         $stream_return = $stream.Read()
    #         Remove-SSHSession -Index 0 | Out-Null
    #         Write-Host "Fila de impressão $fila no servidor $servidor foi limpa com sucesso."
    #     }
    #     catch {
    #         Write-Host "Ocorreu um erro ao limpar a fila de impressão no sistema remoto -" $Error[0]
    #     }

    # }
    else {
        #Outros exceto WMS

        try {
            $jobs = Get-PrintJob -PrinterName $fila -CimSession $servidor | Select-Object Id -ExpandProperty Id
        }
        catch {
            Write-Host "Falha ao localizar impressões, servidor indisponível" -ForegroundColor Red
        }

        if ($jobs) {
            Write-Host "Limpando" $jobs.count "trabalho[s] ..." -ForegroundColor Yellow
            foreach ($job in $jobs) {
                Remove-PrintJob -PrinterName $fila -ID $job -CimSession $servidor -ErrorAction SilentlyContinue         
            }
            Write-Host "Os trabalhos de impressao foram excluídos com sucesso"
        }
        else {
            Write-Host "Nao ha impressões pendentes na fila"
        }
    }
}

Write-Host `n`n"Processo concluido, pressione enter para encerrar a aplicacao"
Pause

