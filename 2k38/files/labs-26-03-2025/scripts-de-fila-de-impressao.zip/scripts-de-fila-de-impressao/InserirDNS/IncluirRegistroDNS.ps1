﻿Set-Location $PSScriptRoot #Carrega o caminho da pasta atual
$Error.Clear()
$host.ui.RawUI.WindowTitle = "Inserir registros DNS"

# Importacoes
.".\ArquivosBase\Menu.ps1"
$dados = Import-Csv -Path ".\DNS.csv" -Delimiter ";"
$global:dominio = ""

if ($servidor -eq "ML-IBM-AD01.magazineluiza.intranet") {
    $global:dominio = "magazineluiza.intranet"
}
elseif ($servidor -eq "ml-ibm-adlj04.lojas.magazineluiza.intranet") {
    $global:dominio = "lojas.magazineluiza.intranet"
}
else {
    Write-Host "Dominio nao definido para o servidor $servidor, contate wellington.rocha@luizalabs.com"
    exit
}

function trim($text) {
    return $text.Trim();
}

function rmSpace($text) {
    return $text.replace(" ", "")
}

function Logger($text) {
    $TimeComplete = Get-Date
    $TimeAbbreviated = Get-Date -Format "yyyy-MM-dd"
    Add-Content -Path ".\Logs\$TimeAbbreviated.txt" -Value "$text - $TimeComplete"
}


Write-Host `n"Os registros do arquivo DNS.csv serao inseridos no servidor $servidor apos a confirmacao" -ForegroundColor Yellow
pause

Write-Host `n"Incluindo registros no servidor $servidor"`n -ForegroundColor Blue
    
$dados | ForEach-Object {

    $fila = trim $_.Filas | rmSpace $_.Filas
    $ip = trim $_.IPs | rmSpace $_.IPs

    Write-Host -NoNewline "Registro $fila - $ip"
    Logger "Registro $fila - $ip"

    try {
        $verificaSeRegistroDNSExiste = Get-DnsServerResourceRecord -CimSession $servidor -ZoneName $global:dominio -RRType "A" -Name $fila -ErrorAction SilentlyContinue

        if ($verificaSeRegistroDNSExiste -eq $null) {
            try {
                Add-DnsServerResourceRecordA -Name $fila -CimSession $servidor -ZoneName $global:dominio -AllowUpdateAny -IPv4Address $ip -ErrorAction Stop
                Write-Host " -  incluido com sucesso"
                Logger " -  incluido com sucesso"

                Start-Sleep -Seconds 4
            }
            catch {
                $erro = $Error[0]
                Write-Host " - falha ao inserir registro DNS: " $Error[0] -ForegroundColor Yellow
                Logger " - falha ao inserir registro DNS $erro"
            }
        }
        else {
            Write-Host " - registro ja existe" -ForegroundColor Yellow
            Logger " - registro ja existe"
        }
    
    }
    catch {
        $erro = $Error[0]
        Write-Host " - falha ao verificar se registro existe" $Error[0]
        Logger " - falha ao verificar se registro existe $erro"
    }
}

Write-Host `n`n"Processo finalizado, pressione enter para encerrar a aplicacao"
Logger "`n`nProcesso finalizado, pressione enter para encerrar a aplicacao"
Pause