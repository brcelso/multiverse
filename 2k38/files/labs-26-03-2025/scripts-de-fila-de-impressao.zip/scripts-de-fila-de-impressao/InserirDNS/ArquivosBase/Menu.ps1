if (-not (Get-Module -Name PSReadLine -ListAvailable)) {
    Install-Module -Name PSReadLine -Force -SkipPublisherCheck
}

Import-Module PSReadLine

function trim($text) {
    return $text.Trim();
}

function rmSpace($text) {
    return $text.replace(" ", "")
}

function exibir_menu() {
    $opcoes = @("ML-IBM-AD01.magazineluiza.intranet", "ml-ibm-adlj04.lojas.magazineluiza.intranet")
    
    do {
        Clear-Host
        Write-Host "=== Selecione um servidor para inserir o DNS ==="
        
        # Exibe as opções com uma seta para indicar a seleção
        for ($i = 0; $i -lt $opcoes.Count; $i++) {
            $opcao = $opcoes[$i]
            $seta = if ($i -eq $selecao) { ">" } else { " " }
            Write-Host "$seta $opcao"
        }

        # Aguarda a entrada do usuário
        $tecla = $null
        $tecla = $host.UI.RawUI.ReadKey("NoEcho,IncludeKeyDown")

        # Atualiza a seleção com base na tecla pressionada
        switch ($tecla.VirtualKeyCode) {
            38 { $selecao = [Math]::Max(0, $selecao - 1) }  # Seta para cima
            40 { $selecao = [Math]::Min($opcoes.Count - 1, $selecao + 1) }  # Seta para baixo
        }
    } while ($tecla.VirtualKeyCode -ne 13)  # Continue até que Enter seja pressionado

    # Retorna a opção selecionada
    return $opcoes[$selecao]
}

# Inicializa a variável de seleção
$selecao = 0

# Chama a função Exibir-Menu e obtém a opção selecionada
$opcaoSelecionada = exibir_menu
$servidor = $opcaoSelecionada