﻿Set-Location $PSScriptRoot
$host.ui.RawUI.WindowTitle = "Analise de fila"

. ".\config\config.ps1"

#hostname do servidor atual
$_hostname = (Get-CimInstance -ClassName Win32_ComputerSystem).Name
$_domain = (Get-CimInstance -ClassName Win32_ComputerSystem).Domain
$global:hostname = "$_hostname.$_domain"

#inicialização de valores
$global:printer_name = ""
$global:numero_filial = ""
$global:endereco_ip = ""
$global:servidores_driver_errado = @()
$global:servidores_com_impressao_presa = @()

while ($global:printer_name -eq "") {
    Clear-Host
    Write-Host ""
    $pattern = '^IMP_\d{2,4}_[A-Za-z0-9_]+$'

    $global:printer_name = Read-Host "Digite o hostname da fila"
    
    if ($global:printer_name -eq "") {
        Write-Host "Campo obrigatorio" -ForegroundColor Yellow
        Start-Sleep -Seconds 2
        Clear-Host
    }

    if ($global:printer_name -notmatch $pattern) {
        $global:printer_name = ""
        Write-Host "Valor de hostname invalido" -ForegroundColor Yellow
        Start-Sleep -Seconds 2
        Clear-Host
    }
}

$global:numero_filial = $global:printer_name.Split('_')[1].TrimStart('0')
$farm = $relacao_farm_filial[$numero_filial]

switch ($farm) {
    "Farm Piloto" { $servidores = $servidores_farm_piloto }
    "Farm 1" { $global:servidores = $servidores_farm_1 }
    "Farm 2" { $global:servidores = $servidores_farm_2 }
    "Farm 3" { $global:servidores = $servidores_farm_3 }
    "Farm 4" { $global:servidores = $servidores_farm_4 }
    Default { Write-Host "Grupo de servidores inexistente, encerrando a aplicacao"; Exit }
} 

try {
    $global:endereco_ip = (Resolve-DnsName -Name "$printer_name.lojas.magazineluiza.intranet" -Server "ml-ibm-adlj04.lojas.magazineluiza.intranet" -ErrorAction Stop).IPAddress
}
catch {
    Write-Host `n"Falha ao localizar no DNS, registro da fila $printer_name nao existe"`n -ForegroundColor $alert_color
    exit
}

$SNMP = New-Object -ComObject olePrn.OleSNMP
$SNMP.open($global:endereco_ip, "public", 2, 1000)

. ".\modules\Loading.ps1"
. ".\modules\VerificarServidores.ps1"
. ".\modules\LimparTrabalhos.ps1"
. ".\modules\CorrigirDrivers.ps1"
. ".\modules\CriarFila.ps1"
. ".\modules\RecriarFila.ps1"
. ".\modules\ReiniciarPrintSpooler.ps1"
. ".\modules\ExibirMenu.ps1"

Write-Host `n"Testando ping com 10 pacotes ..."

$ping_test = Test-Connection -ComputerName $global:endereco_ip -Count 10 -ErrorAction SilentlyContinue
$global:ping_sucesso = $ping_test.Count
$global:ping_perdidos = 10 - $global:ping_sucesso

if ($global:ping_perdidos -ne 10) {
    
    . ".\modules\ConsultaSNMP.ps1"

    Write-Host ""

    Write-Host -NoNewline "Status: " -ForegroundColor $global:secondary_color
    Write-Host "Online" -ForegroundColor Green

    Write-Host -NoNewline "Hostname: " -ForegroundColor $global:secondary_color
    Write-Host $global:printer_name

    Write-Host -NoNewline "IP: " -ForegroundColor $global:secondary_color
    Write-Host $global:endereco_ip

    Write-Host -NoNewline "Grupo de servidores: " -ForegroundColor $global:secondary_color
    Write-Host $relacao_farm_filial[$global:numero_filial]

    Write-Host -NoNewline "Ping com sucesso: " -ForegroundColor $global:secondary_color
    Write-Host $global:ping_sucesso

    Write-Host -NoNewline "Ping perdidos: " -ForegroundColor $global:secondary_color
    Write-Host $global:ping_perdidos

    Write-Host -NoNewline "Fabricante: " -ForegroundColor $global:secondary_color
    Write-Host $fabricante

    Write-Host -NoNewline "Modelo da impressora: " -ForegroundColor $global:secondary_color
    Write-Host $modelo

    Write-Host -NoNewline "Toner: "  -ForegroundColor $global:secondary_color
    Write-Host $toner

    Write-Host -NoNewline "Kit Manutencao: "  -ForegroundColor $global:secondary_color
    Write-Host $kit_manutencao

    Write-Host -NoNewline "Unidade de imagem: " -ForegroundColor $global:secondary_color
    Write-Host $unidade_imagem

    Write-Host -NoNewline "Numero de serie: " -ForegroundColor $global:secondary_color
    Write-Host $serial

    Write-Host -NoNewline "Contador: " -ForegroundColor $global:secondary_color
    Write-Host $contador

    VerificarServidores -PrinterName $global:printer_name

    if (-not $relacao_driver.ContainsKey($modelo)) {
        Write-Host `n"Obs: O modelo de impressora nao existe na relacao de drivers"`n -ForegroundColor $global:alert_color
        exit
    }

    do {
        $opcoes = @(
            "Corrigir drivers", 
            "Limpar trabalhos", 
            "Reiniciar print spooler", 
            "Recriar fila",
            "Criar Fila", 
            "Fazer nova verificacao", 
            "Encerrar aplicacao"
        )

        $opcao_escolhida = ExibirMenu -Opcoes $opcoes

        switch ($opcao_escolhida) {
            $opcoes[0] { CorrigirDrivers -PrinterName $global:printer_name -DriverName $relacao_driver[$modelo] }
            $opcoes[1] { LimparTrabalhos -PrinterName $global:printer_name -Servers $global:servidores_com_impressao_presa }
            $opcoes[2] { ReiniciarPrintSpooler -Servers $global:servidores_com_impressao_presa }
            $opcoes[3] { RecriarFila -PrinterName $global:printer_name -DriverName $relacao_driver[$modelo] }
            $opcoes[4] { CriarFila -PrinterName $global:printer_name -DriverName $relacao_driver[$modelo] }
            $opcoes[5] { VerificarServidores -PrinterName $global:printer_name }
            $opcoes[6] { $SNMP.Close(); Clear-Host }
        }
    } while ($opcao_escolhida -ne "Encerrar aplicacao")

}
else {
    Write-Host ""

    Write-Host -NoNewline "Status: " -ForegroundColor $global:secondary_color
    Write-Host "Offline" -ForegroundColor Red

    Write-Host -NoNewline "Hostname: " -ForegroundColor $global:secondary_color
    Write-Host $global:printer_name

    Write-Host -NoNewline "Fila em uso: " -ForegroundColor $global:secondary_color
    Write-Host $global:printer_in_use

    Write-Host -NoNewline "IP: " -ForegroundColor $global:secondary_color
    Write-Host $global:ip_adress

    Write-Host -NoNewline "Ping com sucesso: " -ForegroundColor $global:secondary_color
    Write-Host $global:ping_sucesso

    Write-Host -NoNewline "Ping com perdidos: " -ForegroundColor $global:secondary_color
    Write-Host $global:ping_perdidos

    VerificarServidores -PrinterName $global:printer_name

    Write-Host ""
}