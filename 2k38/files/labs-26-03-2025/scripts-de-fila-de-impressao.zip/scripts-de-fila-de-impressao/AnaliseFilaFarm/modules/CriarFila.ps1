function CriarFila($PrinterName, $DriverName) {

    while ($resposta -ne "s" -and $resposta -ne "n") {
        Write-Host `n"Apos a confirmacao a fila $PrinterName sera criada, deseja continuar ? (s/n): " -NoNewline -ForegroundColor $global:alert_color
        $resposta = Read-Host

        if ($resposta -ne "s" -and $resposta -ne "n") {
            $resposta = ""
            Write-Host `n"Resposta invalida, digite somente s ou n"`n -ForegroundColor Yellow
        }
    }

    if ($resposta -eq "s") {

        Write-Host ""

        $diretorioPermissao = ".\config\permissaoFarm.txt"
        $diretorioPermissaoAlterada = ".\config\permissaoAlteradaFarm.txt"

        try {
            $permissaoPadraoFarm = Get-Content $diretorioPermissao
            Set-Content -NoNewline -Path $diretorioPermissaoAlterada -Value $permissaoPadraoFarm
        }
        catch {
            Write-Host "Arquivo de permissao padrao nao foi encontrado"`n -ForegroundColor $global:alert_color
            exit
        }

        try {
            
            $novaPermissao = "GIMP_LJ_$global:numero_filial"
                            
            $NomeDaPermissao = New-Object System.Security.Principal.NTAccount($novaPermissao)
            $SID = $NomeDaPermissao.Translate([System.Security.Principal.SecurityIdentifier])
                    
            $SDDLString = "(A;;SWRC;;;" + $SID + ")"
    
            Add-Content -NoNewline -Path ".\config\permissaoAlteradaFarm.txt" -Value $SDDLString 
        }
        catch {
            Write-Host "Erro ao buscar permissao" $Error[0] -ForegroundColor $global:alert_color
            exit
        }
        
        try {
            $permissaoInserida = Get-Content ".\config\permissaoAlteradaFarm.txt"
        }
        catch {
            Write-Host "Arquivo de permissao alterada nao encontrado" -ForegroundColor $global:alert_color
            exit
        }

        #Criar porta
        foreach ($servidor in $global:servidores) {

            if ($servidor -eq $global:hostname) {
                try {
                    $LPName = "$PrinterName.lojas.magazineluiza.intranet"
                    Add-PrinterPort -name $PrinterName -LprQueueName $PrinterName -LprHostAddress $LPName -AsJob | Out-Null
                }
                catch {
                    Write-Host "Erro ao criar a porta no servidor $servidor`:" $Error[0] -ForegroundColor $global:alert_color
                }
            }
            else {
                try {
                    $session = New-CimSession -ComputerName $servidor -ErrorAction Stop
                }
                catch {
                    Write-Host "Nao foi possivel conectar ao servidor $servidor" -ForegroundColor $global:alert_color
                    Continue
                }
                        
                try {
                    $LPName = "$PrinterName.lojas.magazineluiza.intranet"
                    Add-PrinterPort -name $PrinterName -CimSession $session -LprQueueName $PrinterName -LprHostAddress $LPName -AsJob | Out-Null
                }
                catch {
                    Write-Host "Erro ao criar a porta no servidor $servidor`:" $Error[0] -ForegroundColor $global:alert_color
                }
                        
            }
        
        }

        loading "Criando portas, " 40
        
        #Criar fila
        foreach ($servidor in $global:servidores) {
            if ($servidor -eq $global:hostname) {
                try {
                    Add-Printer -Name $PrinterName -DriverName $DriverName -PortName $PrinterName -PermissionSDDL $permissaoInserida -AsJob | Out-Null
                }
                catch {
                    Write-Host "Erro ao criar a fila no servidor $servidor`:" $Error[0] -ForegroundColor $global:alert_color
                }
            }
            else {
                try {
                    $session = New-CimSession -ComputerName $servidor -ErrorAction Stop
                }
                catch {
                    Write-Host "Nao foi possivel conectar ao servidor $servidor" -ForegroundColor $global:alert_color
                    Continue
                }
                        
                try {
                    Add-Printer -Name $PrinterName -CimSession $session -DriverName $DriverName -PortName $PrinterName -PermissionSDDL $permissaoInserida -AsJob | Out-Null
                }
                catch {
                    Write-Host "Erro ao criar a fila no servidor $servidor`:" $Error[0] -ForegroundColor $global:alert_color
                }
                        
            }
        
        }
        
        loading "Criando filas, " 20
        
        Remove-Item -Path ".\config\permissaoAlteradaFarm.txt" -ErrorAction SilentlyContinue

        VerificarServidores -PrinterName $PrinterName

            
        
    }
}