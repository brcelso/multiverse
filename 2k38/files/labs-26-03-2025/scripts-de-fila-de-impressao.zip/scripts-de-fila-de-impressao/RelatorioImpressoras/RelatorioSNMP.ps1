﻿Set-Location $PSScriptRoot
$host.ui.RawUI.WindowTitle = "Relatorios SNMP"

$servidor = ""
$csv_path = ".\Relatorios\$servidor.csv"

Remove-Item -Path $csv_path -Recurse -Force -ErrorAction SilentlyContinue

while ($servidor -eq "") {
    Clear-Host
    $servidor = Read-Host "Digite o hostname do servidor"

    $verificaDominio = $servidor.split(".")

    if ($servidor -eq "") {
        Write-Host "Campo obrigatorio" -ForegroundColor Yellow
        Start-Sleep -Seconds 2
        Clear-Host
    }
    elseif ($verificaDominio.Length -lt 2) {
        Write-Host "Necessario digitar o host com dominio" -ForegroundColor Yellow
        $servidor = ""
        Start-Sleep -Seconds 2
        Clear-Host
    }
    
}

#variaveis
$snmpCommunity = "public"

#SNMP OID
$serial_OID = ".1.3.6.1.2.1.43.5.1.1.17.1"
$fabricante_OID = ".1.3.6.1.2.1.43.8.2.1.14.1.1"

$samsung_modelo_OID = ".1.3.6.1.4.1.236.11.5.1.1.1.1.0"
$hp_modelo_OID = ".1.3.6.1.2.1.25.3.2.1.3.1"

Write-Host `n"Buscando impressoras no servidor $servidor" -ForegroundColor Blue

$printers = Get-Printer -CimSession $servidor -Name "IMP_*" | Select-Object Name, PortName | Sort-Object -Property Name

foreach ($printer in $printers) {

    $printer_name = $printer.Name
    $printer_name_with_domain = $printer.Name + ".lojas.magazineluiza.intranet"
    $printer_portname = $printer.PortName

    Write-Host -NoNewline "Impressora" $printer_name

    $test_port_name = ( $printer_portname).Substring(0, 3)

    if ($test_port_name -eq "IP_") {
        $ip_address = ( $printer_portname).Substring(3)
    }
    else {
        try {
            $ip_address = (Resolve-DnsName -Name $printer_name_with_domain -ErrorAction Stop).IPAddress 
        }
        catch {
            Write-Host " - Erro ao resolver DNS" -ForegroundColor Yellow
            Continue
        }
    }

    try {
        $pingResult = Test-Connection -ComputerName $ip_address -Count 1 -ErrorAction Stop
    }
    catch {
        Write-Host " - Nao responde ao ping" -ForegroundColor Yellow

        $_printer_name = $printer_name
        $_printer_status = Get-Printer -CimSession $servidor -Name $printer_name | Select-Object -ExpandProperty "PrinterStatus"
        $_printer_portname = Get-Printer -CimSession $servidor -Name $printer_name | Select-Object -ExpandProperty "PortName"
        $_printer_driver_name = Get-Printer -CimSession $servidor -Name $printer_name | Select-Object -ExpandProperty "DriverName"
        $_printer_model = "Nao responde"
        $_serial = "Nao responde"
        $_fabricante = "Nao responde"
        $_endereco_IP = $ip_address
        $_server = $servidor
    
        $object = [PSCustomObject]@{
            "Status"     = $_printer_status
            "Nome"       = $_printer_name
            "IP"         = $_endereco_IP
            "Porta"      = $_printer_portname
            "Driver"     = $_printer_driver_name
            "Modelo"     = $_printer_model
            "Serial"     = $_serial
            "Fabricante" = $_fabricante
            "Server"     = $_server

        }

        $object | Export-Csv -Path ".\Relatorios\$servidor.csv" -NoTypeInformation -Delimiter ';' -Append
            
        Continue
    }


    if ($pingResult) {

        try {

            $SNMP = New-Object -ComObject olePrn.OleSNMP

            $SNMP.open($ip_address, $snmpCommunity, 2, 1000)

            $fabricante = $SNMP.Get($fabricante_OID)
            $serial = $SNMP.Get($serial_OID)
                

            if ($fabricante -eq "HP") {
                $modelo = $SNMP.Get($hp_modelo_OID)
            }
            elseif ($fabricante -eq "Samsung Electronics") {
                $modelo = $SNMP.Get($samsung_modelo_OID)
            }
            else {
                $modelo = $SNMP.Get($hp_modelo_OID)

                if (!$modelo -or $modelo -eq "") {
                    $modelo = "Nao encontrado"
                }
            }
               
            $SNMP.Close()
                
            Write-Host " - Executado com sucesso"
        }
        catch {
                
        }    
    }
    else {
        $modelo = "Nao responde"
        $serial = "Nao responde"
        $fabricante = "Nao responde"
    }

    $_printer_name = $printer_name
    $_printer_status = Get-Printer -CimSession $servidor -Name $printer_name | Select-Object -ExpandProperty "PrinterStatus"
    $_printer_portname = Get-Printer -CimSession $servidor -Name $printer_name | Select-Object -ExpandProperty "PortName"
    $_printer_driver_name = Get-Printer -CimSession $servidor -Name $printer_name | Select-Object -ExpandProperty "DriverName"
    $_printer_model = $modelo
    $_serial = $serial
    $_fabricante = $fabricante
    $_endereco_IP = $ip_address
    $_server = $servidor

    $object = [PSCustomObject]@{
        "Status"     = $_printer_status
        "Nome"       = $_printer_name
        "IP"         = $_endereco_IP
        "Porta"      = $_printer_portname
        "Driver"     = $_printer_driver_name
        "Modelo"     = $_printer_model
        "Serial"     = $_serial
        "Fabricante" = $_fabricante
        "Server"     = $_server

    }

    $object | Export-Csv -Path ".\Relatorios\$servidor.csv" -NoTypeInformation -Delimiter ';' -Append
            
}
                    
Write-Host `n"Verifique na pasta relatorios o arquivo CSV gerado com o nome de $servidor .csv"
Write-Host `n`n"Processo finalizado, pressione Enter para encerrar a aplicacao" -ForegroundColor Yellow
Pause