﻿Set-Location $PSScriptRoot

# Importacoes
.".\ArquivosBase\Menu.ps1"

Remove-Item -Path ".\Relatorios\$opcaoSelecionada*" -Recurse -Force -ErrorAction SilentlyContinue

foreach ($servidor in $servidores) {

    Write-Host `n"Buscando impressoras no servidor $servidor" -ForegroundColor Blue

    $printers = Get-Printer -CimSession $servidor -Name "*" |`
        Select-Object PrinterStatus, Name, PortName, DriverName | Sort-Object -Property Name |`
        Add-Member -MemberType NoteProperty -Name "Servidor" -Value $servidor -PassThru |`
        Export-Csv -Path ".\Relatorios\$opcaoSelecionada.csv" -NoTypeInformation -Delimiter ';' 
}
                    
Write-Host `n"Verifique na pasta relatorios o arquivo CSV gerado com o nome de $opcaoSelecionada"
Write-Host `n`n"Processo finalizado, pressione Enter para encerrar a aplicacao" -ForegroundColor Yellow
Pause