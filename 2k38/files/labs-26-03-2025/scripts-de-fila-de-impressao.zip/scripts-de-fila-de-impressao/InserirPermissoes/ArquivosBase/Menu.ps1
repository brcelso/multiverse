if (-not (Get-Module -Name PSReadLine -ListAvailable)) {
    Install-Module -Name PSReadLine -Force -SkipPublisherCheck
}

Import-Module PSReadLine

$opcoes = @(
    "GemcoVB",
    "Aguia",
    "NF",
    "Banguela",
    "WMS",
    "Farm1",
    "Farm2",
    "Farm3",
    "Farm4",
    "Faturamento_loja"
)

function exibir_menu() {
    do {
        Clear-Host
        Write-Host `n"=== Selecione o servidor em que as alteracoes serao realizadas ==="`n
        
        # Exibe as opções com uma seta para indicar a seleção
        for ($i = 0; $i -lt $opcoes.Count; $i++) {
            $opcao = $opcoes[$i]
            $seta = if ($i -eq $selecao) { ">" } else { " " }
            Write-Host "$seta $opcao"
        }

        # Aguarda a entrada do usuário
        $tecla = $null
        $tecla = $host.UI.RawUI.ReadKey("NoEcho,IncludeKeyDown")

        # Atualiza a seleção com base na tecla pressionada
        switch ($tecla.VirtualKeyCode) {
            38 { $selecao = [Math]::Max(0, $selecao - 1) }  # Seta para cima
            40 { $selecao = [Math]::Min($opcoes.Count - 1, $selecao + 1) }  # Seta para baixo
        }
    } while ($tecla.VirtualKeyCode -ne 13)  # Continue até que Enter seja pressionado

    # Retorna a opção selecionada
    return $opcoes[$selecao]
}

# Inicializa a variável de seleção
$selecao = 0

# Chama a função Exibir-Menu e obtém a opção selecionada
$opcaoSelecionada = exibir_menu

$servidores = Get-Content ".\ArquivosBase\Servidores\$opcaoSelecionada.txt"
$dados = Import-Csv -Path ".\CSV\$opcaoSelecionada.csv" -Delimiter ";"