﻿Set-Location $PSScriptRoot #Carrega o caminho da pasta atual
$Error.Clear()
$host.ui.RawUI.WindowTitle = "Permissoes extras"

import-module ActiveDirectory

# Importacoes
.".\ArquivosBase\Menu.ps1"

Remove-Item -Force -Recurse -Path ".\Permissoes\*" -ErrorAction SilentlyContinue

$servidorModelo = $servidores[0]

Write-Host `n"Apos a confirmacao as filas do arquivo CSV terao sua permissao alterada nos servidores do $opcaoSelecionada" -ForegroundColor Yellow
Write-Host "O servidor $servidorModelo sera usado como base para copia das permissoes atuais" -ForegroundColor Yellow
pause

function trim($text) {
    return $text.Trim();
}

function rmSpace($text) {
    return $text.replace(" ", "")
}

function PegaPermissoesAtuais($fila, $servidorModelo) {
    try {
            (Get-Printer -Name $fila -CimSession $servidorModelo -Full).PermissionSDDL | Out-File ".\Permissoes\$fila.txt" | Out-Null
    }
    catch {
        Write-Host "Erro ao salvar permissao:" $Error[0] -ForegroundColor Red
        Write-Host "Encerrando o programa"
        Pause
    }
}

function alteraPermissaoSalva($fila, $permissao) {
    try {
        $NomeDaPermissao = New-Object System.Security.Principal.NTAccount($permissao)
        $SID = $NomeDaPermissao.Translate([System.Security.Principal.SecurityIdentifier])
        
        #Permissão de impressão
        $SDDLString = "(A;;SWRC;;;" + $SID + ")"

        #Permissão de impressão e gerenciamento
        #SDDLString = "(A;;LCSWSDRCWDWO;;;" + $SID + ")"

        #Permissao de leitura, documentos e gerenciamento
        #$SDDLString = "(A;;LCSWSDRCWDWO;;;" + $SID + ")(A;OIIO;RPWPSDRCWDWO;;;" + $SID + ")"
                
        Add-Content -NoNewline -Path ".\Permissoes\$fila.txt" -Value $SDDLString
    }
    catch {
        Write-Host "Erro ao alterar permissao salva:" $Error[0] -ForegroundColor Red
        Write-Host "Encerrando o programa"
        Pause
    }
}

$dados | ForEach-Object {

    $_.Filas = trim $_.Filas | rmSpace $_.Filas
    $_.Permissoes = trim $_.Permissoes

    $fila = $_.Filas
    $permissoes = $_.Permissoes
    
    $verificaSeFilaExiste = Get-Printer -Name $fila -CimSession $servidorModelo -ErrorAction SilentlyContinue

    if ($verificaSeFilaExiste) {
        
        Write-Host `n"Fila $fila" -ForegroundColor Blue

        Write-Host "Buscando permissao ..."
        pegaPermissoesAtuais $fila $servidorModelo

        $VerificaSeArquivoExiste = Test-Path -Path ".\Permissoes\$fila.txt" -IsValid -ErrorAction SilentlyContinue
            
        if ($verificaSeArquivoExiste) {

            try {

                Write-Host "Alterando permissao salvas"
                $permissoes -split (",") | ForEach-Object {
                    $permissao = $_.trim()
                    alteraPermissaoSalva $fila $permissao
                }
                
                Write-Host "Alterando permissao nos servidores"
                $NovaPermissao = Get-Content ".\Permissoes\$fila.txt"
                Invoke-Command -ComputerName $servidores -ScriptBlock { Set-Printer -Name $Using:fila -PermissionSDDL $Using:NovaPermissao } -AsJob | Out-Null

            }
            catch {
                Write-Host "Erro ao incluir permissao:" $Error[0] -ForegroundColor Red
            }
        }
        else {
            Write-Host "Arquivo de permissao nao encontrado, permissao da fila nao sera alterada nos servidores" -ForegroundColor Yellow
        }
        
    }
    else {
        Write-Host "Fila $fila nao existe no servidor $servidoModelo" -ForegroundColor Yellow
    }
}
        
Write-Host `n"Processo finalizado, pressione enter para encerrar a aplicacao"`n
pause
