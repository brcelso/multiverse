﻿Set-Location $PSScriptRoot
$host.ui.RawUI.WindowTitle = "Verifica fila de faturamento"

$servidor = "ml-ibm-adlj04.lojas.magazineluiza.intranet"
$dados = Import-Csv -Path ".\FilasParaVerificar.csv" -Delimiter ";"
$resultado = @()
$dns = @()

Remove-Item -Path ".\Relatorio\*" -ErrorAction SilentlyContinue

function trim($text) {
    return $text.Trim();
}

function rmSpace($text) {
    return $text.replace(" ", "")
}

$dados | ForEach-Object {

    $host_fila_comum = trim $_.Filas | rmSpace $_.Filas

    Write-Host "Verificando fila $host_fila_comum"

    $split_numero_filial = $host_fila_comum.split("_")
    $numero_filial = $split_numero_filial[1]

    $host_fila_faturamento = "IMP_" + $numero_filial + "_FAT_NF1"

    try {
        $dns_fila_comum = [System.Net.Dns]::GetHostAddresses($host_fila_comum).IPAddressToString
    }
    catch {
        $objeto = New-Object PSObject -Property @{
            "HostName" = $host_fila_comum
        }
        $dns += $objeto
    }

    try {
        $dns_fila_faturamento = [System.Net.Dns]::GetHostAddresses($host_fila_faturamento).IPAddressToString
    }
    catch {
        $objeto = New-Object PSObject -Property @{
            "HostName" = $host_fila_faturamento
        }
        $dns += $objeto
    }

    if ($dns_fila_comum.Count -gt 0 -and $dns_fila_faturamento.Count -gt 0) {
        if ($dns_fila_comum -eq $dns_fila_faturamento) {
            $objeto = New-Object PSObject -Property @{
                "HostName"    = $host_fila_comum
                "Faturamento" = "Sim"
            }
            $resultado += $objeto
        }
        else {
            $objeto = New-Object PSObject -Property @{
                "HostName"    = $host_fila_comum
                "Faturamento" = "Nao"
            }
            $resultado += $objeto
        }
    }
    else {
        Write-Host $host_fila_faturamento "- Nao encontrado no DNS" -ForegroundColor Yellow
    }
}

$resultado | Export-Csv -Path ".\Relatorio\FilasDeFaturamento.csv" -NoTypeInformation -Delimiter ";"
$dns | Export-Csv -Path ".\Relatorio\DNS.csv" -NoTypeInformation -Delimiter ";"

Write-Host `n`n"Processo finalizado, pressione enter para finalizar a aplicacao" -ForegroundColor Yellow
Pause


