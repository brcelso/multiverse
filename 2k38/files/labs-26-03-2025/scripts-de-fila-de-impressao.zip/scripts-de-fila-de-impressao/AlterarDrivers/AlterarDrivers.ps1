﻿Set-Location $PSScriptRoot
$Error.Clear()
$host.ui.RawUI.WindowTitle = "Alteracao de drivers"

# Importacoes
.".\ArquivosBase\Menu.ps1"

# Invoke-Item ".\Filas.csv"
$dados = Import-Csv -Path ".\Filas.csv" -Delimiter ";"

#hostname do servidor atual
$_hostname = (Get-CimInstance -ClassName Win32_ComputerSystem).Name
$_domain = (Get-CimInstance -ClassName Win32_ComputerSystem).Domain
$global:hostname = "$_hostname.$_domain"

Write-Host `n"As filas da lista Filas.csv serão alteradas nos servidores escolhidos" -ForegroundColor Yellow
Write-Host "Enter para continuar ou Control+C para encerrar" -ForegroundColor Yellow
pause


function alteraDriver($servidor, $fila, $driver) {
    
    try {
        if ($servidor -eq $global:hostname) {
            $impressora_existe = Get-Printer -Name $fila -ErrorAction Stop
        }
        else {
            $impressora_existe = Get-Printer -Name $fila -CimSession $servidor -ErrorAction Stop
        }
    }
    catch {
        Write-Host " - impressora não existe nesse servidor" -ForegroundColor Red
    }
    
    try {
        if ($servidor -eq $global:hostname) {
            $driver_existe = Get-PrinterDriver -Name $driver -ErrorAction Stop
        }
        else {
            $driver_existe = Get-PrinterDriver -Name $driver -CimSession $servidor -ErrorAction Stop
        }
    }
    catch {
        Write-Host " - driver não existe nesse servidor" -ForegroundColor Red
    }
            
    if ($impressora_existe -and $driver_existe) {
        try {
            if ($servidor -eq $global:hostname) {
                $comando = Set-Printer -Name $fila -DriverName $driver -AsJob | Out-Null
                Write-Host " - Comando enviado"
            }
            else {
                $session = New-PSSession -ComputerName $servidor
                $comando = Invoke-Command -Session $session -ScriptBlock { Set-Printer -Name $Using:fila -DriverName $Using:driver } -AsJob
                Write-Host " - Comando enviado"
            }
        }
        catch {
            Write-Host -NoNewline " - Erro ao alterar a fila:" $Error[0] -ForegroundColor Red
        }
    }
}

function verificaAlteracao($servidor, $fila, $driver) {

    try {
        if ($servidor -eq $global:hostname) {
            $driver_localizado = Get-Printer -Name $fila -ErrorAction Stop | Select-Object -ExpandProperty DriverName
        }
        else {
            $driver_localizado = Get-Printer -CimSession $servidor -Name $fila -ErrorAction Stop | Select-Object -ExpandProperty DriverName
        }

        if ($driver_localizado -eq $driver) {
            Write-Host " - Alterado com sucesso"
        }
        else {
            Write-Host " - Drive não foi alterado, driver desejado: $driver, driver atual: $driver_localizado"
        }
    }
    catch {
        Write-Host " - impressora nao existe nesse servidor" -ForegroundColor Red
    }
}

Write-Host `n`n"Alterando driver de fila nos servidores ..." -ForegroundColor Blue
foreach ($servidor in $servidores) {

    Write-Host `n"Servidor $servidor" -ForegroundColor Cyan
    
    $dados | ForEach-Object {
    
        $_.Filas = $_.Filas.Trim()
        $_.Drivers = $_.Drivers.Trim()
        
        $fila = $_.Filas
        $driver = $_.Drivers
        $servidor = $servidor.Trim()

        Write-Host -NoNewline "Substituindo driver na fila" $fila

        alteraDriver $servidor $fila $driver
    }

    Write-Host ""
}

Write-Host `n"Aguarde, realizando alterações ..." -ForegroundColor Yellow
Start-Sleep -s 10

Write-Host `n"Verificando se o driver foi alterado nos servidores" -ForegroundColor Blue
foreach ($servidor in $servidores) {

    Write-Host `n
    Write-Host $servidor -ForegroundColor Cyan

    $dados | ForEach-Object {

        $_.Filas = $_.Filas.Trim()
        $_.Drivers = $_.Drivers.Trim()
        
        $fila = $_.Filas
        $driver = $_.Drivers
        $servidor = $servidor.Trim()

        Write-Host -NoNewline $fila

        verificaAlteracao $servidor $fila $driver
    }
}

Write-Host `n"Processo finalizado, pressione Enter para finalizar"`n -ForegroundColor Yellow
pause

