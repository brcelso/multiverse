const express = require("express");
const cors = require("cors");
const https = require("https");
const fs = require("fs");

const automatosRoutes = require("./src/routes/automatosRoutes");

const app = express();
const port = 3002;

const allowedOrigins = ["https://opsmagalu.zendesk.com, https://helpdesk.magalu.com.br"];

app.use(
  cors({
    origin: (origin, callback) => {
      if (!origin || allowedOrigins.some((allowed) => origin && origin.startsWith(allowed))) {
        callback(null, true);
      } else {
        callback(new Error("Origin not allowed"), false);
      }
    },
    methods: ["GET", "POST", "OPTIONS"],
    credentials: true,
  })
);

app.use((req, res, next) => {
  const origin = req.headers.origin || req.headers.referer;

  if (!origin || allowedOrigins.some((allowed) => origin && origin.startsWith(allowed))) {
    next();
  } else {
    res.status(403).json({ message: "Origin or Referer not allowed" });
  }
});

app.use(express.json());
app.use(express.urlencoded({ extended: true }));

app.use("/automatos", automatosRoutes);

const options = {
  key: fs.readFileSync("/etc/letsencrypt/live/automatos-send.site/privkey.pem"),
  cert: fs.readFileSync("/etc/letsencrypt/live/automatos-send.site/fullchain.pem"),
};

https.createServer(options, app).listen(3002, () => {
  console.log(`Server is running on http://localhost:${port}`);
});
