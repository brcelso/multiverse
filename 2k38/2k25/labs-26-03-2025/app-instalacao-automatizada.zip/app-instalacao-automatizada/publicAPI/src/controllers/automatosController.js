const axios = require("axios");

exports.findMachineData = async (req, res) => {
  const { hostname, ticket_id } = req.body;
  const apiKey = req.headers["x-api-key"];
  API_automatosID = "338313379563";
  API_automatosKey = "RDMwRTk3MTFDMzNFRjJDRjdDNEE1N0JFRTdDMDVDRTQ=";

  const secret_key =
    "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9yJpZCI6MywibG9naW4iOiJfd2VsbGluZ3RvbiIsInVzZXJuYW1lIjoiV0VMTElOR1RPTiBERSBGUkVJVEFTIFJPQ0hBIiwiaWF0IjoxNzM3MzcxMzkxLCJleHAiOjE3Mzc0NTc3OTF9";

  if (!apiKey || apiKey !== secret_key) {
    return res.status(400).json({ message: "Incorrect or bad format token" });
  }

  if (!ticket_id || !hostname) {
    return res.status(400).json({ message: "Missing required fields" });
  }

  async function sendZendeskInternalNote(message, ticket_id, serial_number) {
    const zendeskDomain = "opsmagalu.zendesk.com";
    const zendeskEmail = "chatbot_helpdesk@magazineluiza.com.br";
    const zendeskApiToken = "RNO4VasuSYjeNdAwBGtlwRth3acguqwYYesYuIEZ";
    const zendesk_url = `https://${zendeskDomain}/api/v2/tickets/${ticket_id}`;

    const date = new Date();
    const month = date.toLocaleString("pt-BR", { month: "long" }).toString().toLocaleLowerCase();
    const year = date.getFullYear().toString().toLowerCase();

    const auth = Buffer.from(`${zendeskEmail}/token:${zendeskApiToken}`).toString("base64");

    const ticket_reponse = {
      ticket: {
        comment: {
          html_body: message,
          public: false,
        },
        custom_fields: [
          {
            id: 23125562451863,
            value: serial_number,
          },
          {
            id: 14609168610967,
            value: `noc_mes_compra_${month}`,
          },
          {
            id: 14609215743255,
            value: `${year}`,
          },
        ],
      },
    };

    try {
      await axios.put(zendesk_url, ticket_reponse, {
        headers: {
          Authorization: `Basic ${auth}`,
          "Content-Type": "application/json",
        },
      });
    } catch (error) {
      console.error("Erro ao adicionar observação interna:", error.response?.data || error.message);
      return res.status(400).send("Erro ao adicionar a observação no ticket: ");
    }
  }

  const base_url = "https://lad1-smartcenter.almaden.app/api/public";
  const getAllHardwareEndpoint = `${base_url}/api/getAllHardware/desktops?AutomatosId=${API_automatosID}&Securitykey=${API_automatosKey}&hostname=${hostname}`;

  try {
    const getHardwareResponse = await axios.get(getAllHardwareEndpoint, {
      httpsAgent: new (require("https").Agent)({ rejectUnauthorized: false }),
      timeout: 30000,
    });

    if (getHardwareResponse.status === 200) {
      const machineData = getHardwareResponse.data || [];
      const machine = machineData[0];
      const serial_number = machine.system_serial_number || "Não localizado";

      if (machineData.length === 0 || machineData.length > 1) {
        const message = machineData.length === 0 ? "Máquina não encontrada no portal automatos" : "Máquina com hostname duplicado no portal automatos";
        sendZendeskInternalNote(message, ticket_id, serial_number);
        return res.status(200).send(message);
      } else {
        const message = `
      <p><strong>Máquina localizada no portal Automatos</strong></p>
      <p><strong>Hostname:</strong> ${machine.computer_name || "Não localizado"}</p>
      <p><strong>Serial:</strong> ${machine.system_serial_number || "Não localizado"}</p>
      <p><strong>ID Automatos:</strong> ${machine.machine_id || "Não localizado"}</p>
      <p><strong>Última coleta:</strong> ${machine.collect_date || "Não localizado"}</p>
    `;
        sendZendeskInternalNote(message, ticket_id, serial_number);

        return res.status(200).send({ "Máquina localizada no portal Automatos: ": machine.computer_name });
      }
    }
  } catch (error) {
    const status = error.response?.status || 500;

    if (error.code === "ECONNABORTED") {
      return res.status(408).json({
        message: "Tempo esgotado na requisição",
        error: error.message,
      });
    }

    console.error("Erro ao consultar máquina:", {
      hostname,
      ticket_id,
      message: error.message,
      response: error.response?.data || "Sem detalhes adicionais",
    });

    return res.status(status).json({
      message: "Erro ao consultar a máquina. Tente novamente mais tarde.",
    });
  }
};
