const express = require("express");
const router = express.Router();

const automatosController = require("../controllers/automatosController");

router.post("/findmachine", automatosController.findMachineData);

module.exports = router;
