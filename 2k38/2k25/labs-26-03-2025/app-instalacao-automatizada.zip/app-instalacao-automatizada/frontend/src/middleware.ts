import { NextURL } from "next/dist/server/web/next-url";
import { NextResponse } from "next/server";
import type { NextRequest } from "next/server";
import { jwtDecode } from "jwt-decode";

export function middleware(req: NextRequest) {
  const token = req.cookies.get("token")?.value;
  const { origin, pathname } = req.nextUrl;

  function isTokenExpired(token: string): boolean {
    try {
      const decoded: { exp: number } = jwtDecode(token);
      const currentTime = Math.floor(Date.now() / 1000);
      return decoded.exp < currentTime;
    } catch (error) {
      console.error("Erro ao decodificar o token:", error);
      return true;
    }
  }

  function redirectToLoginPage() {
    const redirectUrl = new NextURL("/auth/login", origin);
    redirectUrl.searchParams.set("redirect", pathname);
    return NextResponse.redirect(redirectUrl);
  }

  if (!token || isTokenExpired(token)) {
    return redirectToLoginPage();
  }

  if (token && pathname === "/auth/login") {
    const redirectUrl = new NextURL("/automatos/consulta", origin);
    return NextResponse.redirect(redirectUrl);
  }

  return NextResponse.next();
}

export const config = {
  matcher: ["/", "/automatos/:path*", "/config", "/auth/changepassword"],
};
