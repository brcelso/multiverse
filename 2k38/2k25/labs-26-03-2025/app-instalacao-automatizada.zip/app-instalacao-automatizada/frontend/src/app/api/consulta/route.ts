import { NextResponse } from "next/server";
import axios from "axios";
import { cookies } from "next/headers";

export async function GET(req: Request) {
  try {
    const { searchParams } = new URL(req.url);
    const hostname = searchParams.get("hostname");

    if (!hostname) {
      return NextResponse.json({ message: "Hostname inválido ou ausente" }, { status: 400 });
    }

    const token = cookies().get("token")?.value;

    if (!token) {
      return NextResponse.json({ message: "Token ausente" }, { status: 401 });
    }

    const authResponse = await axios.get(`${process.env.NEXT_PUBLIC_BASE_URL}/automatos/public/machine?hostname=${hostname}`, {
      headers: {
        Authorization: `Bearer ${token}`,
      },
    });

    if (!authResponse.data) {
      return NextResponse.json({ message: "Resposta da API está vazia." }, { status: 500 });
    }

    return NextResponse.json(authResponse.data);
  } catch (error: any) {
    if (error.response) {
      const errorMessage = error.response.data.message || "Erro desconhecido na resposta da API";
      const errorDetails = error.response.data.details || "Sem detalhes adicionais";

      console.error("API Error:", errorMessage, errorDetails);

      // Retorna a mensagem de erro e detalhes ao frontend
      return NextResponse.json(
        {
          message: errorMessage,
          details: errorDetails,
        },
        { status: error.response.status || 500 }
      );
    } else {
      const fallbackMessage = "Erro na requisição ou na conexão com o servidor";
      console.error("Erro sem resposta:", fallbackMessage);

      return NextResponse.json({ message: fallbackMessage }, { status: 500 });
    }
  }
}
