"use client";

import { useEffect, useState } from "react";
import Swal, { SweetAlertIcon, SweetAlertPosition } from "sweetalert2";
import withReactContent from "sweetalert2-react-content";
import styles from "./styles.module.scss";
import { FiAirplay, FiCopy } from "react-icons/fi";
import { formatDate } from "@/app/utils/date";
import { useRouter } from "next/navigation";
import { FaCalendarAlt, FaDesktop, FaLaptop, FaNetworkWired, FaSearch, FaSpinner, FaUser } from "react-icons/fa";
import { Accordion, AccordionSummary, AccordionDetails, Typography, Button, TextField, Box } from "@mui/material";
import ArrowDropDownIcon from "@mui/icons-material/ArrowDropDown";

interface MachineData {
  computer_name: string;
  computer_type: string;
  department_name: string;
  so_string: string;
  system_serial_number: string;
  machine_id: string;
  system_manufacturer: string;
  top_user: string;
  last_login: string;
  collect_date: string;
  softwareDetails: string;
  machine_net_ipaddress: string;
  machine_ipdomain: string;
  dns_servers: string;
}

interface SoftwareDetailsInfo {
  name: string;
  instalation_dates: [string];
}

export default function Consulta() {
  const [hostname, setHostname] = useState("");
  const [dados, setDados] = useState<MachineData>();
  const [loading, setLoading] = useState(false);
  const [openIndex, setOpenIndex] = useState<number | null>(null);
  const [softwareDetails, setSoftwareDetails] = useState<SoftwareDetailsInfo[]>([]);

  const MySwal = withReactContent(Swal);
  const router = useRouter();

  const showSwal = (title: string, text: string, toast: boolean, position: SweetAlertPosition, icon: SweetAlertIcon) => {
    MySwal.fire({
      title: (
        <div>
          <p>{title}</p>
          <p>
            <small>{text}</small>
          </p>
        </div>
      ),
      toast: toast,
      position: position,
      timer: 2000,
      timerProgressBar: true,
      showConfirmButton: false,
      icon: icon,
    });
  };

  const handleCopy = (title: string, text: string) => {
    navigator.clipboard
      .writeText(text)
      .then(() => {
        showSwal(title, text, true, "bottom-end", "success");
      })
      .catch(() => {
        showSwal(title, text, true, "bottom-end", "error");
      });
  };

  const responseError = (data: string) => {
    showSwal(data, "", false, "center", "error");
    setDados(undefined);
    sessionStorage.setItem("machineData", "");
  };

  const handleConsulta = async (e: React.FormEvent) => {
    e.preventDefault();

    setDados(undefined);
    sessionStorage.setItem("machineData", "");

    setLoading(true);

    try {
      const response = await fetch(`/api/consulta?hostname=${hostname}`);
      const data = await response.json();

      if (!response.ok) {
        responseError(data.message);
        return;
      }

      const parsedDetails = JSON.parse(data.data[0].softwareDetails);
      setSoftwareDetails(parsedDetails);

      setDados(data.data[0]);
      sessionStorage.setItem("machineData", JSON.stringify(data.data[0]));
    } catch (error: any) {
      const errorMessage = error?.message || "Erro não identificado.";
      responseError(errorMessage);
    } finally {
      setLoading(false);
    }
  };

  const handleEnviarDistribuicao = (automatosID: string, hostname: string) => {
    router.push(`/automatos/distribuicao?automatosID=${automatosID}&hostname=${hostname}`);
  };

  const toggleAccordion = (index: number) => {
    setOpenIndex(openIndex === index ? null : index);
  };

  const getAccordionClassname = (name: string) => {
    if (name.toLocaleLowerCase().includes("microsoft") || name.toLocaleLowerCase() === "office") {
      return `${styles.accordionItem} ${styles.accordionOfficeColor}`;
    } else if (name.toLocaleLowerCase().includes("automatos")) {
      return `${styles.accordionItem} ${styles.accordionAutomatosColor}`;
    } else if (name.toLocaleLowerCase().includes("trend")) {
      return `${styles.accordionItem} ${styles.accordionTrendMicroColor}`;
    } else if (name.toLocaleLowerCase().includes("netskope")) {
      return `${styles.accordionItem} ${styles.accordionNetskopeColor}`;
    } else if (name.toLocaleLowerCase().includes("libre") || name.toLocaleLowerCase().includes("openoffice")) {
      return `${styles.accordionItem} ${styles.accordionLibreColor}`;
    } else if (name.toLocaleLowerCase().includes("manageengine")) {
      return `${styles.accordionItem} ${styles.accordionManageEngineColor}`;
    } else {
      return `${styles.accordionItem}`;
    }
  };

  useEffect(() => {
    const storedData = sessionStorage.getItem("machineData");
    if (storedData) {
      const parsedDetails = JSON.parse(storedData);
      setDados(parsedDetails);
      setSoftwareDetails(JSON.parse(parsedDetails.softwareDetails));
    }
  }, []);

  return (
    <div className={styles.container}>
      <div className={styles.consulta}>
        <form onSubmit={handleConsulta}>
          <TextField
            variant="filled"
            inputProps={{
              maxLength: 60,
            }}
            value={hostname}
            label="Hostname"
            onChange={(e) => setHostname(e.target.value)}
            className={styles.inputSearch}
            fullWidth
            required
          />
          <Button variant="outlined" type="submit" startIcon={<FaSearch />} className={styles.buttonConsultar} disabled={hostname === ""}>
            BUSCAR
          </Button>
        </form>
      </div>
      <div className={styles.content}>
        <div className={styles.resultadoConsulta}>
          {dados ? (
            <>
              <div className={styles.resultadoConsultaDetalhes}>
                <div className={styles.divIconeEnviarDistribuicao} onClick={() => handleEnviarDistribuicao(dados.machine_id, dados.computer_name)}>
                  <FiAirplay className={styles.iconeEnviarDistribuicao} />
                </div>

                <div className={styles.detalhesCard}>
                  <div className={styles.divIconeDetalhesCard}>
                    {dados.computer_type === "DESKTOP" ? <FaDesktop className={styles.iconeDetalhesCard} /> : <FaLaptop className={styles.iconeDetalhesCard} />}
                  </div>
                  <div>
                    <div className={styles.formInline}>
                      <p className={styles.formTitle}>Hostname</p>
                      <span>{dados.computer_name || "N/A"}</span>
                      <button onClick={() => handleCopy("Hostname copiado", dados.computer_name)} className={styles.copyIcon}>
                        <FiCopy />{" "}
                      </button>
                      <p className={styles.formTitle}>Tipo</p>
                      <span className={styles.formValue}>{dados.computer_type || "N/A"}</span>
                      <p className={styles.formTitle}>Sistema operacional</p>
                      <span className={styles.formValue}>{dados.so_string || "N/A"}</span>
                    </div>

                    <div className={styles.formInline}>
                      <p className={styles.formTitle}>Serial</p>
                      <span>{dados.system_serial_number || "N/A"}</span>
                      <button aria-label="system_serial_number_copy" onClick={() => handleCopy("Serial copiado", dados.system_serial_number)} className={styles.copyIcon}>
                        <FiCopy />{" "}
                      </button>

                      <p className={styles.formTitle}>ID Automatos</p>
                      <span>{dados.machine_id || "N/A"}</span>
                      <button aria-label="machine_id_copy" onClick={() => handleCopy("ID Automatos copiado", dados.machine_id)} className={styles.copyIcon}>
                        <FiCopy />
                      </button>
                    </div>

                    <div className={styles.formInline}>
                      <p className={styles.formTitle}>Departamento</p>
                      <span className={styles.formValue}>{dados.department_name || "N/A"}</span>

                      <p className={styles.formTitle}>Fabricante</p>
                      <span className={styles.formValue}>{dados.system_manufacturer || "N/A"}</span>
                    </div>
                  </div>
                </div>

                <div className={styles.detalhesCard}>
                  <div className={styles.divIconeDetalhesCard}>
                    <FaNetworkWired className={styles.iconeDetalhesCard} />
                  </div>
                  <div>
                    <div className={styles.formInline}>
                      <p className={styles.formTitle}>Domínio</p>
                      <span className={styles.formValue}>{dados.machine_ipdomain || "N/A"}</span>

                      <p className={styles.formTitle}>IP</p>
                      <span className={styles.formValue}>{dados.machine_net_ipaddress.replaceAll(",", " / ") || "N/A"}</span>

                      <p className={styles.formTitle}>DNS</p>
                      <span className={styles.formValue}>{dados.dns_servers.replaceAll(",", " / ") || "N/A"}</span>
                    </div>
                  </div>
                </div>

                <div className={styles.detalhesCard}>
                  <div className={styles.divIconeDetalhesCard}>
                    <FaUser className={styles.iconeDetalhesCard} />
                  </div>
                  <div>
                    <div className={styles.formInline}>
                      <p className={styles.formTitle}>Último usuário logado</p>
                      <span className={styles.formValue}>{dados.last_login || "N/A"}</span>

                      <p className={styles.formTitle}>Usuário que mais utiliza</p>
                      <span className={styles.formValue}>{dados.top_user || "N/A"}</span>
                    </div>
                  </div>
                </div>

                <div className={styles.detalhesCard}>
                  <div className={styles.divIconeDetalhesCard}>
                    <FaCalendarAlt className={styles.iconeDetalhesCard} />
                  </div>
                  <div>
                    <div className={styles.formInline}>
                      <p className={styles.formTitle}>Data da última coleta</p>
                      <span>{formatDate(dados.collect_date) || "N/A"}</span>
                    </div>
                  </div>
                </div>
              </div>

              <div className={styles.accordionContainer}>
                <Typography className={styles.accordionTitle}>Softwares instalados</Typography>
                {softwareDetails.length > 0 ? (
                  softwareDetails
                    .sort((a, b) => a.name.localeCompare(b.name))
                    .map((instalation, index) => (
                      <Accordion
                        slotProps={{ heading: { component: "h4" } }}
                        key={index}
                        expanded={openIndex === index}
                        onChange={() => toggleAccordion(index)}
                        className={getAccordionClassname(instalation.name)}
                      >
                        <AccordionSummary expandIcon={<ArrowDropDownIcon />} aria-controls={`panel${index}-content`} id={`panel${index}-header`}>
                          <Typography className={styles.accordionHeader}>{instalation.name}</Typography>
                        </AccordionSummary>
                        <AccordionDetails>
                          {instalation.instalation_dates.map((date, dateIndex) => (
                            <Typography key={dateIndex}>Data de Instalação: {formatDate(date)}</Typography>
                          ))}
                        </AccordionDetails>
                      </Accordion>
                    ))
                ) : (
                  <Typography>Nenhuma instalação encontrada</Typography>
                )}
              </div>
            </>
          ) : (
            <p className={styles.formTitle} style={{ textAlign: "center", fontSize: "14px" }}>
              {loading ? (
                <div className={styles.loadingOverlay}>
                  <FaSpinner className={styles.loading} />
                </div>
              ) : (
                "Nenhuma consulta realizada"
              )}
            </p>
          )}
        </div>
      </div>
    </div>
  );
}
