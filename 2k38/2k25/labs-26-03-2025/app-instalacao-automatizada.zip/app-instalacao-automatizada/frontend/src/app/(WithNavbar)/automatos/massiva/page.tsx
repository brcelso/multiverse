"use client";

import React, { FormEvent, useState } from "react";
import { Box, Button, Container, TextField, Typography, FormControl, InputLabel, Select, MenuItem } from "@mui/material";
import styles from "./styles.module.scss";
import { FaCheckCircle, FaList, FaSpinner, FaTimesCircle, FaUpload } from "react-icons/fa";
import Swal, { SweetAlertIcon } from "sweetalert2";
import withReactContent from "sweetalert2-react-content";

interface Result {
  status: string;
  hostname: string;
  package: string;
  message: string;
}

export default function HostnameInstaller() {
  const [hostnames, setHostnames] = useState("");
  const [pacote, setPacote] = useState("");
  const [results, setResults] = useState<Result[]>([]);
  const [loading, setLoading] = useState(false);

  const MySwal = withReactContent(Swal);

  const pacotes = [
    { value: "Excel_2007_X86.exe", label: "Excel 2007 (x86)" },
    { value: "Excel_2010_X64.exe", label: "Excel 2010 (x64)" },
    { value: "Excel_2013_X64.exe", label: "Excel 2013 (x64)" },
    { value: "Excel_2016_X64.exe", label: "Excel 2016 (x64)" },
    { value: "Excel_2021_X64.exe", label: "Excel 2021 (x64)" },
    { value: "Office_STD_2007_X86.exe", label: "Office Standard 2007 (X86)" },
    { value: "Office_STD_2010_X64.exe", label: "Office Standard 2010 (x64)" },
    { value: "Office_STD_2013_X64.exe", label: "Office Standard 2013 (x64)" },
    { value: "Office_STD_2016_X64.exe", label: "Office Standard 2016 (x64)" },
    { value: "Office_STD_2021_X64.exe", label: "Office Standard 2021 (x64)" },
    { value: "Office_PRO_2007_X86.exe", label: "Office Professional 2007 (x86)" },
    { value: "Office_PRO_2010_X64.exe", label: "Office Professional 2010 (X64)" },
    { value: "Office_PRO_2013_X64.exe", label: "Office Professional 2013 (x64)" },
    { value: "Office_PRO_2016_X64.exe", label: "Office Professional 2016 (x64)" },
  ];

  const showSwal = (title: string, text: string, icon: SweetAlertIcon) => {
    MySwal.fire({
      title: (
        <div>
          <p>{title}</p>
          <p>
            <small>{text}</small>
          </p>
        </div>
      ),
      position: "center",
      timer: 2000,
      timerProgressBar: true,
      showConfirmButton: false,
      icon: icon,
    });
  };

  const handleSubmit = (e: FormEvent) => {
    e.preventDefault();

    MySwal.fire({
      title: "Confirma o envio?",
      text: "Após a confirmação não será possível cancelar",
      toast: false,
      position: "center",
      showConfirmButton: true,
      showCancelButton: true,
      confirmButtonText: "Sim",
      cancelButtonText: "Cancelar",
    }).then((result) => {
      if (result.isConfirmed) {
        sendInstallations();
      }
    });
  };

  const sendInstallations = async () => {
    setLoading(true);

    const hostnameArray = hostnames
      .split(",")
      .map((host) => host.trim())
      .filter((host) => host);

    try {
      const response = await fetch("/api/massiva", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({ pacote: pacote, hostnames: hostnameArray }),
      });

      if (!response.ok) {
        const errorData = await response.json();
        throw new Error(`Erro ${response.status}: ${errorData.message}`);
      }

      const data = await response.json();

      setResults(data.data.results);
    } catch (error: any) {
      console.error("Houve um erro ao realizar a checagem:", error);
      showSwal("Erro ao enviar dados", "Tente novamente mais tarde", "error");
    } finally {
      setLoading(false);
    }
  };

  const handleFileUpload = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = () => {
      const content = reader.result as string;

      const parsedHostnames = content
        .split(/\r?\n/)
        .map((line) => line.trim())
        .filter((line) => line);

      setHostnames((prev) => {
        const existingHostnames = prev.trim();
        return existingHostnames ? `${existingHostnames},${parsedHostnames.join(",")}` : parsedHostnames.join(",");
      });
    };
    reader.readAsText(file);
  };

  return (
    <Container maxWidth="md" className={styles.container}>
      <div className={styles.content}>
        <div className={styles.contentHeader}>
          <div>
            <FaList className={styles.iconHeader} />
          </div>
          <div>
            <Typography variant="h6" gutterBottom>
              Distribuição massiva
            </Typography>
            <small>Insira os hostnames e clique em Enviar</small>
          </div>
        </div>

        <form className={styles.contentBody} onSubmit={handleSubmit}>
          <Box>
            <FormControl fullWidth sx={{ mb: 1 }}>
              <Box sx={{ display: "flex", alignItems: "center", gap: 1 }}>
                <TextField
                  label="Hostnames"
                  multiline
                  rows={4}
                  fullWidth
                  variant="outlined"
                  value={hostnames}
                  onChange={(e) => setHostnames(e.target.value)}
                  placeholder="Insira os hostnames separados por vírgula ou envie um arquivo (txt/csv) com os hostnames separados por linha"
                  className={styles.formInput}
                />
                <Button variant="contained" component="label" className={styles.loadFileIcon}>
                  <FaUpload />
                  <input type="file" hidden accept=".txt, .csv" onChange={handleFileUpload} />
                </Button>
              </Box>
            </FormControl>

            <FormControl fullWidth sx={{ mb: 1, mt: 1 }}>
              <InputLabel id="pacote">Pacote</InputLabel>
              <Select labelId="pacote" id="pacote" value={pacote} onChange={(e) => setPacote(e.target.value)} label="Pacote">
                <MenuItem value="">
                  <em>Selecione</em>
                </MenuItem>
                {pacotes.map((item) => (
                  <MenuItem key={item.value} value={item.value}>
                    {item.label}
                  </MenuItem>
                ))}
              </Select>
            </FormControl>

            <Box sx={{ display: "flex", justifyContent: "center" }}>
              <Button variant="contained" color="primary" disabled={!hostnames.trim() || !pacote.trim()} className={styles.submitButton} type="submit">
                {loading ? "Enviando" : "Enviar"}
              </Button>
            </Box>
          </Box>
          {loading ? (
            <div className={styles.loadingOverlay}>
              <FaSpinner className={styles.loading} />
            </div>
          ) : (
            <Box>
              {results.length > 0 && (
                <div className={styles.listContainer}>
                  <div className={styles.gridHeader}>
                    <span>Status</span>
                    <span>Hostname</span>
                    <span>Pacote</span>
                    <span className={styles.mobileView}>Mensagem</span>
                  </div>
                  {results.map((data, index) => (
                    <div key={index} className={`${styles.logLines} ${data.status === "success" ? styles.success : styles.failure}`}>
                      <span>{data.status === "success" ? <FaCheckCircle className={styles.successIcon} /> : <FaTimesCircle className={styles.failureIcon} />}</span>
                      <span>{data.hostname}</span>
                      <span>{data.package}</span>
                      <span className={styles.mobileView}>{data.message}</span>
                    </div>
                  ))}
                </div>
              )}
            </Box>
          )}
        </form>
      </div>
    </Container>
  );
}
