"use client";

import { useEffect, useState } from "react";
import styles from "./styles.module.scss";
import withReactContent from "sweetalert2-react-content";
import Swal from "sweetalert2";
import { formatDate } from "@/app/utils/date";
import { FaSpinner, FaShareSquare } from "react-icons/fa";

interface HistoricoItem {
  id: number;
  created_at: string;
  software: string;
  hostname_maquina_alvo: string;
  id_automatos_maquina_alvo: string;
  status: string;
  enviado_por: string;
}

export default function Distribuicao() {
  const MySwal = withReactContent(Swal);
  const [historico, setHistorico] = useState<HistoricoItem[]>([]);
  const [loading, setLoading] = useState(true);

  const showSwal = (title: string, text: string) => {
    MySwal.fire({
      title: (
        <div>
          <p>{title}</p>
          <p>
            <small>{text}</small>
          </p>
        </div>
      ),
      toast: true,
      position: "bottom-end",
      timer: 2000,
      timerProgressBar: true,
      showConfirmButton: false,
      icon: "success",
    });
  };

  const handleChecagemManual = async (id: number, opcao: string) => {
    try {
      const response = await fetch("/api/checagem", {
        method: "PATCH",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({ id, opcao }),
      });

      if (response.ok) {
        fetchHistorico();
      } else {
        console.log("Erro ao realizar a checagem manualmente");
      }
    } catch (error) {
      console.error("Houve um erro ao realizar a checagem:", error);
      showSwal("Houve um erro ao realizar a checagem", "");
    }
  };

  const fetchHistorico = async () => {
    setLoading(true);
    try {
      const response = await fetch("/api/historico");
      const data = await response.json();
      setHistorico(data);
    } catch (error) {
      console.error("Erro ao buscar o histórico:", error);
      showSwal("Erro ao carregar histórico", "");
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchHistorico();

    const intervalId = setInterval(fetchHistorico, 60000);
    return () => clearInterval(intervalId);
  }, []);

  const instaladoChecagemManual = (id: number) => {
    MySwal.fire({
      title: <p>Escolha uma opção</p>,
      toast: false,
      position: "center",
      showConfirmButton: true,
      showCancelButton: true,
      icon: "info",
      confirmButtonText: "Instalado",
      cancelButtonText: "Instalação falhou",
    }).then((result) => {
      if (result.isConfirmed) {
        handleChecagemManual(id, "Instalado");
      } else if (result.dismiss === Swal.DismissReason.cancel) {
        handleChecagemManual(id, "Instalação falhou");
      }
    });
  };

  const removidoChecagemManual = (id: number) => {
    MySwal.fire({
      title: <p>Escolha uma opção</p>,
      toast: false,
      position: "center",
      showConfirmButton: true,
      showCancelButton: true,
      icon: "info",
      confirmButtonText: "Removido",
      cancelButtonText: "Remoção falhou",
    }).then((result) => {
      if (result.isConfirmed) {
        handleChecagemManual(id, "Removido");
      } else if (result.dismiss === Swal.DismissReason.cancel) {
        handleChecagemManual(id, "Remoção falhou");
      }
    });
  };

  const questionResendInstallation = (id: number) => {
    MySwal.fire({
      title: "Confirma o reenvio?",
      text: "Após a confirmação não será possível cancelar",
      toast: false,
      position: "center",
      showConfirmButton: true,
      showCancelButton: true,
      confirmButtonText: "Confirmar",
      cancelButtonText: "Cancelar",
    }).then((result) => {
      if (result.isConfirmed) {
        resendInstallation(id);
      }
    });
  };

  const resendInstallation = async (id: number) => {
    try {
      const response = await fetch("/api/resend", {
        method: "PATCH",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({ id }),
      });

      if (response.ok) {
        fetchHistorico();
        showSwal("Reinstalação enviada", "");
      } else {
        console.log("Erro ao reenviar a instalação");
      }
    } catch (error) {
      console.error("Houve um erro ao reenviar a instalação:", error);
      showSwal("Houve um erro ao reenviar a instalação", "");
    }
  };

  return (
    <div className={styles.container}>
      {loading ? (
        <div className={styles.loadingOverlay}>
          <FaSpinner className={styles.loading} />
        </div>
      ) : (
        <div className={styles.tableContainer}>
          <table className={styles.table}>
            <thead className={styles.tableHeader}>
              <tr>
                <th>Data de envio</th>
                <th>Software</th>
                <th>Hostname</th>
                <th>ID Automatos</th>
                <th>Status</th>
                <th>Enviado por</th>
                <th>Reenviar</th>
              </tr>
            </thead>
            <tbody>
              {historico.map((item) => (
                <tr key={item.id} className={styles.tableBody}>
                  <td>{formatDate(item.created_at)}</td>
                  <td>{item.software}</td>
                  <td>{item.hostname_maquina_alvo}</td>
                  <td>{item.id_automatos_maquina_alvo}</td>
                  <td>
                    {item.status === "Verificação manual" ? (
                      item.software.toLowerCase().includes("remover") ? (
                        <span className={styles.manualCheck} onClick={() => removidoChecagemManual(item.id)}>
                          {item.status}
                        </span>
                      ) : (
                        <span className={styles.manualCheck} onClick={() => instaladoChecagemManual(item.id)}>
                          {item.status}
                        </span>
                      )
                    ) : (
                      <span>{item.status}</span>
                    )}
                  </td>
                  <td>{item.enviado_por}</td>
                  <td>
                    {item.status !== "Instalado" && item.status !== "Removido" ? (
                      <FaShareSquare
                        className={styles.btnResend}
                        onClick={() => {
                          questionResendInstallation(item.id);
                        }}
                      />
                    ) : (
                      <FaShareSquare className={`${styles.btnResend} ${styles.btnResendDisabled}`} />
                    )}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </div>
  );
}
