"use client";

import { useRouter } from "next/navigation";
import styles from "./styles.module.scss";
import Link from "next/link";
import Image from "next/image";
import { useEffect, useState } from "react";

export function Navbar() {
  const router = useRouter();
  const [isUserButtonOpen, setUserButtonOpen] = useState(false);
  const [isMenuOpen, setIsMenuOpen] = useState(false);

  async function handleLogout() {
    await fetch("/api/logout", {
      method: "POST",
    })
      .then((response) => response.json())
      .then(() => {
        sessionStorage.setItem("machineData", "");
        router.push("/auth/login");
        window.location.reload();
      })
      .catch((error) => console.error("Erro ao fazer logout:", error));
  }

  const toggleDropdown = () => {
    setUserButtonOpen(!isUserButtonOpen);
  };

  const toggleMenu = () => {
    setIsMenuOpen(!isMenuOpen);
  };

  return (
    <div className={styles.container}>
      <nav className={styles.nav}>
        <div className={styles.navLogo}>
          <Link href="/automatos/consulta">
            <Image src="/images/logoAutomatos.png" alt="Logo" width={150} height={45} priority={true} />
          </Link>
        </div>

        <button className={styles.hamburgerButton} aria-label="Abrir menu" onClick={toggleMenu}>
          ☰
        </button>

        <div className={`${isMenuOpen ? styles.navLinksOpen : styles.navLinks}`}>
          <Link href="/automatos/consulta">Consulta</Link>
          <Link href="/automatos/distribuicao">Distribuição</Link>
          <Link href="/automatos/massiva">Massiva</Link>
          <Link href="/automatos/historico">Histórico</Link>
        </div>

        <div className={styles.dropdownMenu}>
          <button className={styles.dropdownMenuButton} onClick={toggleDropdown}>
            ☰
          </button>
          {isUserButtonOpen && (
            <ul className={styles.dropdownMenuContent} onMouseLeave={() => setUserButtonOpen(false)}>
              <li>
                <Link href="/auth/changepassword">Trocar Senha</Link>
              </li>
              <li>
                <Link href="" onClick={handleLogout}>
                  Sair
                </Link>
              </li>
            </ul>
          )}
        </div>
      </nav>
    </div>
  );
}
