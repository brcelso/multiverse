import { NextResponse } from "next/server";
import axios from "axios";
import { cookies } from "next/headers";

export async function POST(req: Request) {
  try {
    const { password, newPassword } = await req.json();

    if (!password || !newPassword) {
      return NextResponse.json({ message: "Todos os dados são necessários" }, { status: 400 });
    }

    const token = cookies().get("token")?.value;

    if (!token) {
      return NextResponse.json({ message: "Token ausente" }, { status: 401 });
    }

    const authResponse = await axios.post(
      `${process.env.NEXT_PUBLIC_BASE_URL}/api/changepassword`,
      {
        password,
        newPassword,
      },
      {
        headers: {
          Authorization: `Bearer ${token}`,
        },
      }
    );

    if (!authResponse.data) {
      return NextResponse.json({ message: "Resposta da API está vazia." }, { status: 500 });
    }

    return NextResponse.json(authResponse.data);
  } catch (error: any) {
    if (error.response) {
      const errorMessage = error.response.data.message || "Erro desconhecido na resposta da API";

      console.error("API Error:", errorMessage);

      return NextResponse.json(
        {
          message: errorMessage,
        },
        { status: error.response.status || 500 }
      );
    } else {
      const fallbackMessage = "Erro na requisição ou na conexão com o servidor";
      console.error("Erro na requisição ou na conexão com o servidor:", fallbackMessage);

      return NextResponse.json({ message: fallbackMessage }, { status: 500 });
    }
  }
}
