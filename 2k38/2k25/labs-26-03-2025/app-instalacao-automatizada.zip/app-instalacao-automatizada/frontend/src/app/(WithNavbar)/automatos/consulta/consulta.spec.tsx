import { render, screen, fireEvent, waitFor } from "@testing-library/react";
import Consulta from "./page";
import { vi, describe, beforeEach, afterEach, expect, it } from "vitest";
import "@testing-library/jest-dom";

describe("Página Consulta", () => {
  vi.mock("next/navigation", () => ({
    useRouter() {
      return {
        prefetch: () => null,
      };
    },
  }));

  beforeEach(() => {
    global.fetch = vi.fn(() =>
      Promise.resolve(
        new Response(JSON.stringify({ data: [mockMachineData] }), {
          status: 200,
          headers: { "Content-Type": "application/json" },
        })
      )
    );
  });

  afterEach(() => {
    vi.clearAllMocks();
  });

  const mockMachineData = {
    computer_name: "Machine_123",
    computer_type: "Desktop",
    department_name: "IT",
    so_string: "Windows 10",
    system_serial_number: "ABC123456",
    machine_id: "MACHINE123",
    system_manufacturer: "Dell",
    top_user: "user1",
    last_login: "2023-10-01",
    collect_date: "2023-10-15",
  };

  it("Deve renderizar o formulário com o input de pesquisa e o botão consultar", () => {
    render(<Consulta />);

    expect(screen.getByPlaceholderText(/Digite um hostname/i)).toBeInTheDocument();
    expect(screen.getByText(/consultar/i)).toBeInTheDocument();
  });

  it("Deve mostrar o loading no botão com a mensagem consultando enquanto realiza a requisição", async () => {
    render(<Consulta />);

    const input = screen.getByPlaceholderText(/Digite um hostname/i);
    fireEvent.change(input, { target: { value: "Machine_123" } });

    fireEvent.click(screen.getByText(/consultar/i));

    expect(screen.getByText(/consultando/i)).toBeInTheDocument();

    await waitFor(() => expect(screen.queryByText(/consultando/i)).not.toBeInTheDocument());
  });

  it("Deve buscar e mostrar os dados na tela quando pesquisado", async () => {
    render(<Consulta />);

    const input = screen.getByPlaceholderText(/Digite um hostname/i);
    fireEvent.change(input, { target: { value: "Machine_123" } });

    fireEvent.click(screen.getByText(/consultar/i));

    await waitFor(() => {
      expect(screen.getByText(mockMachineData.computer_name)).toBeInTheDocument();
      expect(screen.getByText(mockMachineData.computer_type)).toBeInTheDocument();
      expect(screen.getByText(mockMachineData.department_name)).toBeInTheDocument();
      expect(screen.getByText(mockMachineData.so_string)).toBeInTheDocument();
      expect(screen.getByText(mockMachineData.system_serial_number)).toBeInTheDocument();
      expect(screen.getByText(mockMachineData.machine_id)).toBeInTheDocument();
    });
  });

  it("Deve mostrar um erro quando a requisição para a API falhar", async () => {
    vi.mocked(global.fetch).mockRejectedValueOnce(new Error("API Error"));

    render(<Consulta />);

    const input = screen.getByPlaceholderText(/Digite um hostname/i);
    fireEvent.change(input, { target: { value: "Machine_123" } });

    fireEvent.click(screen.getByText(/consultar/i));

    await waitFor(() => {
      expect(screen.getByText(/máquina não localizada/i)).toBeInTheDocument();
    });
  });
});
