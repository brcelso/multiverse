import { NextResponse } from "next/server";
import axios from "axios";
import { cookies } from "next/headers";

export async function POST(req: Request) {
  try {
    const { hostname, automatosID, packageToInstall } = await req.json();

    const token = cookies().get("token")?.value;

    const response = await axios.post(
      `${process.env.NEXT_PUBLIC_BASE_URL}/automatos/distribution/send`,
      {
        hostname,
        automatosID,
        packageToInstall,
      },
      {
        headers: {
          Authorization: `Bearer ${token}`,
        },
      }
    );

    return NextResponse.json({ message: response.data.message }, { status: 200 });
  } catch (error: any) {
    return NextResponse.json({ message: error.response.data?.message }, { status: 500 });
  }
}

export async function GET() {
  return NextResponse.json({ message: "Método GET não suportado para esta rota" }, { status: 405 });
}
