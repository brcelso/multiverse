import type { Metadata } from "next";
import "../globals.css";

export const metadata: Metadata = {
  title: "Automatos API",
  description: "Envio de instalações de software automatizadas",
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="pt-br">
      <body>{children}</body>
    </html>
  );
}
