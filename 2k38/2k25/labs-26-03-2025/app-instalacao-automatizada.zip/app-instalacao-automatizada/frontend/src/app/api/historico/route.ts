import axios from "axios";
import { cookies } from "next/headers";
import { NextResponse } from "next/server";

export async function GET() {
  try {
    const token = cookies().get("token")?.value;

    if (!token) {
      return NextResponse.json({ message: "Token ausente" }, { status: 401 });
    }

    const response = await axios.get(`${process.env.NEXT_PUBLIC_BASE_URL}/api/history`, {
      headers: {
        Authorization: `Bearer ${token}`,
      },
    });

    return NextResponse.json(response.data);
  } catch (error: any) {
    return NextResponse.json({
      message: "Erro ao buscar o histórico",
      error: error.message,
    });
  }
}
