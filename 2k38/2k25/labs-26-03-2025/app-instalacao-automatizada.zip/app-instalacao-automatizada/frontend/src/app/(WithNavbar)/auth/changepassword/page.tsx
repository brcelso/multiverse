"use client";

import { FormEvent, useState } from "react";
import Swal, { SweetAlertIcon } from "sweetalert2";
import styles from "./styles.module.scss";
import withReactContent, { SweetAlert2 } from "sweetalert2-react-content";

export default function ChangePassword() {
  const [password, setPassword] = useState("");
  const [newPassword, setNewPassword] = useState("");
  const [newPasswordRepeat, setNewPasswordRepeat] = useState("");

  const MySwal = withReactContent(Swal);

  const handleSubmit = async (e: FormEvent) => {
    e.preventDefault();

    if (!password || !newPassword) {
      showSwal("Todos os campos são obrigatórios", "", "error");
      return;
    }

    if (newPassword !== newPasswordRepeat) {
      showSwal("Senhas não conferem", "", "error");
      return;
    }

    try {
      const response = await fetch("/api/changepassword", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({ password, newPassword }),
      });

      const data = await response.json();

      if (response.ok) {
        setPassword("");
        setNewPassword("");
        setNewPasswordRepeat("");
        showSwal("Senha alterada com sucesso", "", "success");
      } else {
        showSwal("Erro ao alterar a senha", data.message, "error");
      }
    } catch (error: any) {
      showSwal("Erro ao alterar a senha", error.message, "error");
    }
  };

  const showSwal = (title: string, text: string, icon: SweetAlertIcon) => {
    MySwal.fire({
      title: (
        <div>
          <p>{title}</p>
          <p>
            <small>{text}</small>
          </p>
        </div>
      ),
      position: "center",
      timer: 2000,
      timerProgressBar: true,
      showConfirmButton: false,
      icon: icon,
    });
  };

  return (
    <div className={styles.container}>
      <div className={styles.content}>
        <h1>Alterar Senha</h1>
        <form onSubmit={handleSubmit} className={styles.form}>
          <div>
            <label>Senha Atual</label>
            <input type="password" value={password} onChange={(e) => setPassword(e.target.value)} required />
          </div>
          <div>
            <label>Nova Senha</label>
            <input type="password" value={newPassword} onChange={(e) => setNewPassword(e.target.value)} required />
          </div>
          <div>
            <label>Repita a nova Senha</label>
            <input type="password" value={newPasswordRepeat} onChange={(e) => setNewPasswordRepeat(e.target.value)} required />
          </div>
          <button type="submit">Alterar Senha</button>
        </form>
      </div>
    </div>
  );
}
