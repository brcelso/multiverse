import { vi, describe, expect, it } from "vitest";
import "@testing-library/jest-dom";
import Distribuicao from "./page";
import { fireEvent, render, screen, waitFor } from "@testing-library/react";

vi.mock("next/navigation", () => ({
  useSearchParams: () => ({
    get: (key: string) => {
      if (key === "automatosID") return "123";
      if (key === "hostname") return "Machine_ABC";
      return null;
    },
  }),
}));

global.fetch = vi.fn();

describe("Página Distribuição", () => {
  it("Deve renderizar a página e carregar os parâmetro vindos da URL", () => {
    render(<Distribuicao />);

    const hostnameInput = screen.getByLabelText("Hostname");
    const idAutomatosInput = screen.getByLabelText("ID Automatos");

    expect(hostnameInput).toHaveValue("Machine_ABC");
    expect(idAutomatosInput).toHaveValue("123");
  });

  it("Deve renderizar a página e carregar os inputs, labels e botão", () => {
    render(<Distribuicao />);

    const labelHostname = screen.getByText("Hostname");
    const labelIDAutomatos = screen.getByText("ID Automatos");
    const labelTipo = screen.getByText("Tipo");
    const labelSoftware = screen.getByText("Software");
    const labelVersao = screen.getByText("Versão");
    const labelEdicao = screen.getByText("Edição");
    const labelArquitetura = screen.getByText("Arquitetura");

    const inputHostname = screen.getByLabelText("Hostname");
    const inputIDAutomatos = screen.getByLabelText("ID Automatos");
    const selectTipo = screen.getByLabelText("Tipo");
    const selectSoftware = screen.getByLabelText("Software");
    const selectVersao = screen.getByLabelText("Versão");
    const selectEdicao = screen.getByLabelText("Edição");
    const selectArquitetura = screen.getByLabelText("Arquitetura");

    const buttonEnviar = screen.getByRole("button", { name: /enviar/i });

    expect(labelHostname).toBeInTheDocument();
    expect(labelIDAutomatos).toBeInTheDocument();
    expect(labelTipo).toBeInTheDocument();
    expect(labelSoftware).toBeInTheDocument();
    expect(labelVersao).toBeInTheDocument();
    expect(labelEdicao).toBeInTheDocument();
    expect(labelArquitetura).toBeInTheDocument();

    expect(inputHostname).toBeInTheDocument();
    expect(inputIDAutomatos).toBeInTheDocument();
    expect(selectTipo).toBeInTheDocument();
    expect(selectSoftware).toBeInTheDocument();
    expect(selectVersao).toBeInTheDocument();
    expect(selectEdicao).toBeInTheDocument();
    expect(selectArquitetura).toBeInTheDocument();

    expect(buttonEnviar).toBeInTheDocument();
  });

  it("Deve mostrar um erro quando a requisição para a API falhar", async () => {
    vi.mocked(global.fetch).mockRejectedValueOnce(new Error("API Error"));

    render(<Distribuicao />);

    const inputHostname = screen.getByLabelText("Hostname");
    const inputIDAutomatos = screen.getByLabelText("ID Automatos");
    const selectTipo = screen.getByLabelText("Tipo");
    const selectSoftware = screen.getByLabelText("Software");
    const selectVersao = screen.getByLabelText("Versão");
    const selectEdicao = screen.getByLabelText("Edição");
    const selectArquitetura = screen.getByLabelText("Arquitetura");
    const buttonEnviar = screen.getByRole("button", { name: "Enviar" });

    fireEvent.change(inputHostname, { target: { value: "Machine_ABC" } });
    fireEvent.change(inputIDAutomatos, { target: { value: "123" } });
    fireEvent.change(selectTipo, { target: { value: "instalacao" } });
    fireEvent.change(selectSoftware, { target: { value: "Excel" } });
    fireEvent.change(selectVersao, { target: { value: "STD" } });
    fireEvent.change(selectEdicao, { target: { value: "2013" } });
    fireEvent.change(selectArquitetura, { target: { value: "X86" } });

    fireEvent.click(buttonEnviar);

    await waitFor(() => expect(screen.getByText(/erro ao enviar/i)).toBeInTheDocument());
  });

  describe("Botão de envio", () => {
    it("Deve estar desabilitado quando qualquer campo obrigatório está vazio", () => {
      render(<Distribuicao />);

      const buttonEnviar = screen.getByRole("button", { name: /enviar/i });
      expect(buttonEnviar).toBeDisabled();
    });

    it("Deve estar habilitado quando todos os campos obrigatórios estão preenchidos", () => {
      render(<Distribuicao />);

      const inputHostname = screen.getByLabelText("Hostname");
      const inputIDAutomatos = screen.getByLabelText("ID Automatos");
      const selectTipo = screen.getByLabelText("Tipo");
      const selectSoftware = screen.getByLabelText("Software");
      const selectVersao = screen.getByLabelText("Versão");
      const selectEdicao = screen.getByLabelText("Edição");
      const selectArquitetura = screen.getByLabelText("Arquitetura");

      fireEvent.change(inputHostname, { target: { value: "Machine_ABC" } });
      fireEvent.change(inputIDAutomatos, { target: { value: "123" } });
      fireEvent.change(selectTipo, { target: { value: "instalacao" } });
      fireEvent.change(selectSoftware, { target: { value: "Excel" } });
      fireEvent.change(selectVersao, { target: { value: "STD" } });
      fireEvent.change(selectEdicao, { target: { value: "2013" } });
      fireEvent.change(selectArquitetura, { target: { value: "X86" } });

      const buttonEnviar = screen.getByRole("button", { name: "Enviar" });
      expect(buttonEnviar).toBeEnabled();
    });

    it('Deve mostrar "Enviando..." quando loading é true', async () => {
      render(<Distribuicao />);

      const inputHostname = screen.getByLabelText("Hostname");
      const inputIDAutomatos = screen.getByLabelText("ID Automatos");
      const selectTipo = screen.getByLabelText("Tipo");
      const selectSoftware = screen.getByLabelText("Software");
      const selectVersao = screen.getByLabelText("Versão");
      const selectEdicao = screen.getByLabelText("Edição");
      const selectArquitetura = screen.getByLabelText("Arquitetura");
      const buttonEnviar = screen.getByRole("button", { name: "Enviar" });

      fireEvent.change(inputHostname, { target: { value: "Machine_ABC" } });
      fireEvent.change(inputIDAutomatos, { target: { value: "123" } });
      fireEvent.change(selectTipo, { target: { value: "instalacao" } });
      fireEvent.change(selectSoftware, { target: { value: "Excel" } });
      fireEvent.change(selectVersao, { target: { value: "STD" } });
      fireEvent.change(selectEdicao, { target: { value: "2013" } });
      fireEvent.change(selectArquitetura, { target: { value: "X86" } });

      fireEvent.click(buttonEnviar);

      await waitFor(() => expect(buttonEnviar).toHaveTextContent("Enviando..."));
    });
  });
});
