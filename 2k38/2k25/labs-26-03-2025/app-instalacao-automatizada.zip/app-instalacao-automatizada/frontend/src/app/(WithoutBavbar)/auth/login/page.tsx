"use client";

import { useEffect, useState } from "react";
import { useRouter } from "next/navigation";
import { Button, CircularProgress, FormControl, InputLabel, Input, InputAdornment } from "@mui/material";

import styles from "./styles.module.scss";
import Image from "next/image";
import { FaKey, FaUser } from "react-icons/fa";

export default function LoginPage() {
  const [login, setLogin] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState("");
  const [usuario, setUsuario] = useState("");
  const [loading, setLoading] = useState(false);

  const router = useRouter();

  useEffect(() => {
    if (typeof window !== "undefined") {
      localStorage.setItem("usuario", usuario);
    }
  }, [usuario]);

  useEffect(() => {
    if (typeof window !== "undefined") {
      setTimeout(() => {
        setError("");
      }, 3000);
    }
  }, [error]);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);

    try {
      const response = await fetch("/api/login", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({ login: login, password: password }),
      });

      if (!response.ok) {
        const errorData = await response.json();
        setError(errorData.message);
        return;
      }

      const responseData = await response.json();
      setUsuario(responseData.username);

      router.push("/automatos/consulta");
    } catch (err) {
      setError("Erro ao realizar login. Tente novamente!");
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className={styles.container}>
      <form onSubmit={handleSubmit} className={styles.loginForm}>
        <div className={styles.logoMobile}>
          <Image src="/images/logoAutomatos.png" alt="Logo" width={300} height={90} priority={true} />
        </div>

        <h1 className={styles.title}>Login</h1>

        <div className={styles.loginInput}>
          <FormControl variant="standard" fullWidth>
            <InputLabel htmlFor="usuario">Usuário</InputLabel>
            <Input
              startAdornment={
                <InputAdornment position="start">
                  <FaUser />
                </InputAdornment>
              }
              inputProps={{
                maxLength: 60,
              }}
              id="usuario"
              value={login}
              onChange={(e) => setLogin(e.target.value)}
              required
            />
          </FormControl>
        </div>

        <div className={styles.loginInput}>
          <FormControl variant="standard" fullWidth>
            <InputLabel htmlFor="senha">Senha</InputLabel>
            <Input
              startAdornment={
                <InputAdornment position="start">
                  <FaKey />
                </InputAdornment>
              }
              inputProps={{
                maxLength: 30,
              }}
              type="password"
              id="senha"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              required
            />
          </FormControl>
        </div>

        <div className="divButton">
          <Button type="submit" variant="contained" color="primary" fullWidth className={styles.loginButton} disabled={loading}>
            {loading ? <CircularProgress size={24} /> : "Acessar"}
          </Button>
        </div>

        {error && <p className={styles.errorMessage}>{error}</p>}
      </form>

      <div className={styles.logoBackground}>
        <Image src="/images/logoAutomatos.png" alt="Logo" width={450} height={135} priority={true} className={styles.logo} />
      </div>
    </div>
  );
}
