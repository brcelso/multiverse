"use client";

import { useEffect, useState } from "react";
import styles from "./styles.module.scss";
import withReactContent from "sweetalert2-react-content";
import Swal from "sweetalert2";
import { useSearchParams } from "next/navigation";
import { Select, MenuItem, FormControl, InputLabel, TextField, Button, Typography, Box } from "@mui/material";
import { FaPaperPlane } from "react-icons/fa";

export default function Distribuicao() {
  const [hostname, setHostname] = useState("");
  const [automatosID, setAutomatosID] = useState("");
  const [tipo, setTipo] = useState("");
  const [software, setSoftware] = useState("");
  const [versao, setVersao] = useState("");
  const [edicao, setEdicao] = useState("");
  const [arquitetura, setArquitetura] = useState("");
  const [loading, setLoading] = useState(false);
  const [empresa, setEmpresa] = useState("");
  const [pacote, setPacote] = useState("");

  const MySwal = withReactContent(Swal);
  const searchParams = useSearchParams();

  useEffect(() => {
    const _hostname = searchParams.get("hostname");
    const _automatosID = searchParams.get("automatosID");

    if (_hostname && _automatosID) {
      setHostname(_hostname);
      setAutomatosID(_automatosID);
    }
  }, []);

  const showSwal = (title: string, text: string) => {
    MySwal.fire({
      title: (
        <div>
          <p>{title}</p>
          <p>
            <small>{text}</small>
          </p>
        </div>
      ),
      position: "center",
      timer: 2000,
      timerProgressBar: true,
      showConfirmButton: false,
      icon: "success",
    });
  };

  const gerarNomePacote = () => {
    let _pacote = "";

    if (tipo === "instalacao") {
      _pacote = software === "Excel" ? `${software}_${edicao}_${arquitetura}.exe` : `${software}_${versao}_${edicao}_${arquitetura}.exe`;
    }

    if (tipo === "remocao") {
      _pacote = software === "Excel" ? `Remover_${software}_${edicao}.exe` : `Remover_${software}_${versao}_${edicao}.exe`;
    }

    setPacote(_pacote);
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);

    try {
      const response = await fetch("/api/distribuicao", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          hostname: hostname,
          automatosID: automatosID,
          packageToInstall: pacote,
        }),
      });

      if (!response.ok) {
        const errorData = await response.json();
        throw new Error(`Erro ${response.status}: ${errorData.message}`);
      }

      const data = await response.json();
      showSwal("Envio realizado", "");
    } catch (error: any) {
      const errorMessage = error.message.toLowerCase().includes("file") ? "Arquivo não encontrado na irradiadora" : error.message;
      showSwal("Houve um erro ao enviar", errorMessage);
    }

    setLoading(false);

    setTimeout(() => {
      setHostname("");
      setAutomatosID("");
      setTipo("");
      setSoftware("");
      setVersao("");
      setEdicao("");
      setArquitetura("");
      setPacote("");
      setEmpresa("");
    }, 2000);
  };

  return (
    <div className={styles.container}>
      <div className={styles.content}>
        <div className={styles.contentHeader}>
          <div>
            <FaPaperPlane className={styles.iconHeader} />
          </div>
          <div>
            <Typography variant="h6" gutterBottom>
              Distribuição de software
            </Typography>
            <small>Preencha todo o formulário para liberar o envio</small>
          </div>
        </div>

        <Box sx={{ mb: 4 }}>
          <form onSubmit={handleSubmit} className={styles.form}>
            <TextField
              id="hostname"
              label="Hostname"
              value={hostname}
              onChange={(e) => setHostname(e.target.value)}
              variant="outlined"
              fullWidth
              inputProps={{
                maxLength: 60,
              }}
              autoFocus
              required
              className={styles.formInput}
            />

            <TextField
              id="automatos_id"
              label="ID Automatos"
              value={automatosID}
              onChange={(e) => setAutomatosID(e.target.value)}
              variant="outlined"
              fullWidth
              inputProps={{
                maxLength: 60,
              }}
              required
              className={styles.formInput}
            />

            <FormControl fullWidth disabled={automatosID === "" || hostname === ""} className={styles.formInput}>
              <InputLabel id="empresa">Empresa</InputLabel>
              <Select labelId="empresa" id="empresa" value={empresa} onChange={(e) => setEmpresa(e.target.value)} label="Empresa">
                <MenuItem value="">
                  <em>Selecione</em>
                </MenuItem>
                <MenuItem value="Magalu">Magalu</MenuItem>
                <MenuItem value="Absorção">Absorção</MenuItem>
              </Select>
            </FormControl>

            {empresa === "Magalu" && (
              <>
                <FormControl fullWidth variant="outlined" disabled={!automatosID.trim() || !hostname.trim()} className={styles.formInput}>
                  <InputLabel id="tipo">Tipo</InputLabel>
                  <Select labelId="tipo" id="tipo" value={tipo} onChange={(e) => setTipo(e.target.value)} label="Tipo">
                    <MenuItem value="">
                      <em>Selecione</em>
                    </MenuItem>
                    <MenuItem value="instalacao">Instalação</MenuItem>
                    <MenuItem value="remocao">Remoção</MenuItem>
                  </Select>
                </FormControl>

                <FormControl fullWidth variant="outlined" disabled={!automatosID.trim() || !tipo.trim()} className={styles.formInput}>
                  <InputLabel id="software">Software</InputLabel>
                  <Select labelId="software" id="software" value={software} onChange={(e) => setSoftware(e.target.value)} label="Software">
                    <MenuItem value="">
                      <em>Selecione</em>
                    </MenuItem>
                    <MenuItem value="Office">Office</MenuItem>
                    <MenuItem value="Excel">Excel</MenuItem>
                  </Select>
                </FormControl>

                <FormControl fullWidth variant="outlined" disabled={!automatosID.trim() || !software.trim() || !tipo.trim()} className={styles.formInput}>
                  <InputLabel id="versao">Versão</InputLabel>
                  <Select labelId="versao" id="versao" value={versao} onChange={(e) => setVersao(e.target.value)} label="Versão">
                    <MenuItem value="">
                      <em>Selecione</em>
                    </MenuItem>
                    <MenuItem value="STD">Standard</MenuItem>
                    {software !== "Excel" && <MenuItem value="PRO">Professional</MenuItem>}
                  </Select>
                </FormControl>

                <FormControl fullWidth variant="outlined" disabled={!automatosID.trim() || !software.trim() || !versao.trim() || !tipo.trim()} className={styles.formInput}>
                  <InputLabel id="edicao">Edição</InputLabel>
                  <Select labelId="edicao" id="edicao" value={edicao} onChange={(e) => setEdicao(e.target.value)} label="Edição">
                    <MenuItem value="">
                      <em>Selecione</em>
                    </MenuItem>
                    <MenuItem value="2007">2007</MenuItem>
                    <MenuItem value="2010">2010</MenuItem>
                    <MenuItem value="2013">2013</MenuItem>
                    <MenuItem value="2016">2016</MenuItem>
                    <MenuItem value="2019">2019</MenuItem>
                    <MenuItem value="2021">2021</MenuItem>
                  </Select>
                </FormControl>

                <FormControl
                  fullWidth
                  variant="outlined"
                  disabled={!automatosID.trim() || !tipo.trim() || !software.trim() || !versao.trim() || !edicao.trim()}
                  className={styles.formInput}
                >
                  <InputLabel id="arquitetura">Arquitetura</InputLabel>
                  <Select labelId="arquitetura" id="arquitetura" value={arquitetura} onChange={(e) => setArquitetura(e.target.value)} label="Arquitetura">
                    <MenuItem value="">
                      <em>Selecione</em>
                    </MenuItem>
                    <MenuItem value="X86">X86</MenuItem>
                    {edicao !== "2007" && <MenuItem value="X64">X64</MenuItem>}
                  </Select>
                </FormControl>

                <Box sx={{ display: "flex", justifyContent: "center", mt: 2 }}>
                  <Button
                    variant="contained"
                    type="submit"
                    onClick={gerarNomePacote}
                    disabled={!automatosID.trim() || !tipo.trim() || !software.trim() || !versao.trim() || !edicao.trim() || !arquitetura.trim()}
                    fullWidth
                    style={{ textTransform: "none" }}
                    className={styles.submitButton}
                  >
                    {loading ? "Enviando..." : "Enviar"}
                  </Button>
                </Box>
              </>
            )}
            {empresa === "Absorção" && (
              <>
                <FormControl fullWidth>
                  <InputLabel id="pacote">Pacote</InputLabel>
                  <Select labelId="pacote" id="pacote" value={pacote} onChange={(e) => setPacote(e.target.value)} label="Pacote">
                    <MenuItem value="">
                      <em>Selecione</em>
                    </MenuItem>
                    <MenuItem value="Excel_2016_X64_GFL.exe">Excel_2016_X64_GFL</MenuItem>
                    <MenuItem value="Excel_2016_X64_Netshoes.exe">Excel_2016_X64_Netshoes</MenuItem>
                    <MenuItem value="Excel_2016_X64_SmartHint.exe">Excel_2016_X64_SmartHint</MenuItem>
                    <MenuItem value="Office_PRO_2016_X64_GFL.exe">Office_PRO_2016_X64_GFL</MenuItem>
                  </Select>
                </FormControl>
                <div className={styles.buttonContainer}>
                  <Button
                    variant="contained"
                    type="submit"
                    disabled={!hostname.trim() || !automatosID.trim() || !pacote.trim()}
                    fullWidth
                    style={{ textTransform: "none" }}
                    className={styles.submitButton}
                  >
                    {loading ? "Enviando..." : "Enviar"}
                  </Button>
                </div>
              </>
            )}
          </form>
        </Box>
      </div>
    </div>
  );
}
