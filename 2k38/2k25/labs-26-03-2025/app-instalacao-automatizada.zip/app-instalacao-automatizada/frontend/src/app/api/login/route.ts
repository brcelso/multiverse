import { NextResponse } from "next/server";
import axios from "axios";

export async function POST(req: Request) {
  try {
    const { login, password } = await req.json();

    const response = await axios.post(`${process.env.NEXT_PUBLIC_BASE_URL}/api/login`, {
      login,
      password,
    });

    const token = response.data.token;
    const username = response.data.username;
    const res = NextResponse.json({ username });

    res.cookies.set("token", token, {
      httpOnly: true,
      secure: process.env.NODE_ENV === "production",
      sameSite: "strict",
      path: "/",
      maxAge: 60 * 60 * 24,
    });

    return res;
  } catch (error: any) {
    const statusCode = error.response?.status || 500;
    const errorMessage = error.response?.data?.message || "Erro ao conectar com o servidor.";

    return NextResponse.json({ message: errorMessage }, { status: statusCode });
  }
}
