import { NextResponse } from "next/server";
import axios from "axios";
import { cookies } from "next/headers";

export async function POST(req: Request) {
  try {
    const { hostnames, pacote } = await req.json();

    const token = cookies().get("token")?.value;

    const response = await axios.post(
      `${process.env.NEXT_PUBLIC_BASE_URL}/automatos/distribution/massive`,
      {
        hostnames: hostnames,
        packageToInstall: pacote,
      },
      {
        headers: {
          Authorization: `Bearer ${token}`,
        },
      }
    );

    console.log(response.data);

    return NextResponse.json({ data: response.data }, { status: 200 });
  } catch (error: any) {
    return NextResponse.json({ message: error.response.data?.message }, { status: 500 });
  }
}
