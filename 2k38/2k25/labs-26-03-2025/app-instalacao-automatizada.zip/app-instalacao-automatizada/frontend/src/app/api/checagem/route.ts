import { NextResponse } from "next/server";
import axios from "axios";
import { cookies } from "next/headers";

export async function PATCH(req: Request) {
  try {
    const { id, opcao } = await req.json();

    const token = cookies().get("token")?.value;

    const response = await axios.patch(
      `${process.env.NEXT_PUBLIC_BASE_URL}/api/manualcheck`,
      {
        id,
        opcao,
      },
      {
        headers: {
          Authorization: `Bearer ${token}`,
        },
      }
    );

    return NextResponse.json({ message: response.data.message }, { status: 200 });
  } catch (error: any) {
    return NextResponse.json({ message: error.response.data?.message }, { status: 500 });
  }
}
