### Frontend do projeto para envio de instalações automatizadas

O projeto visa acelerar o processo a consulta de máquinas e envio das instalações automatizadas<br />
mantendo um histórico de envios e fazendo o acompanhamento da instalação diretamente no portal<br />
