const swaggerJsdoc = require("swagger-jsdoc");

const options = {
  definition: {
    openapi: "3.0.0",
    info: {
      title: "Instalação Automatizada",
      version: "1.0.0",
      description: "Documentação da API",
    },
    servers: [
      {
        url: "http://localhost:3001",
      },
    ],
  },
  apis: ["./src/docs/*.js", "./src/routes/*.js"],
};

const specs = swaggerJsdoc(options);

module.exports = specs;
