require("dotenv").config();
const axios = require("axios");
var cron = require("node-cron");
const knexConfig = require("../../knexfile").development;
const knex = require("knex")(knexConfig);

exports.startService = () => {
  const formatDate = (date) => {
    return date.toLocaleString("pt-BR", { hour12: false, month: "2-digit", day: "2-digit", year: "numeric", hour: "2-digit", minute: "2-digit" }).replace(",", "");
  };

  cron.schedule("*/1 * * * *", async () => {
    try {
      const now = new Date();

      const installationsToCheck = await knex("history").where("status", "=", "Em verificação").andWhere("tempo_ate_verificacao", ">=", now);

      console.log(installationsToCheck);

      for (const installation of installationsToCheck) {
        console.log(`Iniciando verificação para o ID: ${installation.id}`);

        const { id, hostname_maquina_alvo, software, tempo_ate_verificacao } = installation;

        const _now = formatDate(new Date());
        const _tempo_ate_verificacao = formatDate(new Date(tempo_ate_verificacao));

        if (_tempo_ate_verificacao <= _now) {
          await knex("history").where({ id }).update({ status: "Verificação manual" });
          console.log(`Verifique manualmente: ${hostname_maquina_alvo}`);
          continue;
        }

        try {
          const automatos_id = process.env.AUTOMATOS_ID;
          const automatos_key = process.env.AUTOMATOS_KEY;
          const endpoint = `https://lad1-smartcenter.almaden.app/api/public/api/getAllSoftware/nextpage/desktops?AutomatosId=${automatos_id}&Securitykey=${automatos_key}&hostname=${hostname_maquina_alvo}`;

          const response = await axios.get(endpoint, {
            httpsAgent: new (require("https").Agent)({ rejectUnauthorized: false }),
          });

          if (response.status === 200) {
            let filtro = software.match(/20\d{2}/)[0];

            const today = new Date();
            const currentDate = today.toISOString().slice(0, 10);

            const filteredData = response.data.data.filter((item) => {
              const isSoftwareVersion = item.normalized_software_name.toLowerCase().includes(filtro);
              const isInstalledToday = item.instalation_date.startsWith(currentDate);

              return isSoftwareVersion && isInstalledToday;
            });

            if (filteredData.length > 0) {
              console.log(`Instalação confirmada para o ID: ${id}`);
              await knex("history").where({ id }).update({ status: "Instalado" });
            } else {
              console.log(`Instalação não confirmada para o ID: ${id}`);
            }
          } else {
            console.log("Erro ao efetuar a requisição para verificação da instalação");
          }
        } catch (error) {
          console.error(`Erro ao verificar instalação para o ID: ${id}: ${error.message}`);
        }
      }
    } catch (error) {
      console.error("Erro ao checar o banco de dados: ", error.message);
    }
  });
};
