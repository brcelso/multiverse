/**
 * @swagger
 * components:
 *   securitySchemes:
 *     bearerAuth:
 *       type: http
 *       scheme: bearer
 *       bearerFormat: JWT
 *   schemas:
 *     User:
 *       type: object
 *       properties:
 *         id:
 *           type: integer
 *         name:
 *           type: string
 *         email:
 *           type: string
 * security:
 *   - bearerAuth: []
 */

/**
 * @swagger
 * /distribution/machine:
 *   get:
 *     tags:
 *       - API Distribuição Automatos
 *     summary: Busca a máquina e o ID para envio da instalação
 *     responses:
 *       200:
 *         description: Busca a máquina e o ID para envio da instalação
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 status:
 *                   type: boolean
 *                   description: Status da operação.
 *                   example: true
 *                 data:
 *                   type: object
 *                   properties:
 *                     machines:
 *                       type: array
 *                       items:
 *                         type: object
 *                         properties:
 *                           machineId:
 *                             type: string
 *                             description: Identificador único da máquina.
 *                             example: "string"
 *                           hostname:
 *                             type: string
 *                             description: Nome do host da máquina.
 *                             example: "string"
 *                           department:
 *                             type: string
 *                             description: Nome do departamento ao qual a máquina pertence.
 *                             example: "string"
 *       400:
 *         description: Requisição inválida ou máquina não localizada
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 status:
 *                   type: boolean
 *                   example: false
 *                 data:
 *                   type: object
 *                   example: {}
 *                 error:
 *                   type: string
 *                   example: "Machine not found"
 */

/**
 * @swagger
 * /distribution/auth:
 *   post:
 *     tags:
 *       - API Distribuição Automatos
 *     summary: Realiza o login e retorna o JWT token para uso da api de instalação
 *     requestBody:
 *           required: true
 *           content:
 *             application/json:
 *               schema:
 *                 type: object
 *                 properties:
 *                   automatosId:
 *                     type: string
 *                     description: Id automatos
 *                     example: "string"
 *                   automatosKey:
 *                     type: string
 *                     description: Key Automatos
 *                     example: "string"
 *                 required:
 *                   - automatosId
 *                   - automatosKey
 *     responses:
 *       200:
 *         description: Realiza o login e retorna o JWT token para uso da api de instalação
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 status:
 *                   type: boolean
 *                   description: Status da operação.
 *                   example: true
 *                 data:
 *                   type: object
 *                   properties:
 *                     token:
 *                       type: string
 *                       example: "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9..."
 *
 *       400:
 *         description: Requisição inválida ou máquina não localizada
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 status:
 *                   type: boolean
 *                   example: false
 *                 data:
 *                   type: object
 *                   example: {}
 *                 error:
 *                   type: string
 *                   example: "Machine not found"
 */

/**
 * @swagger
 * /distribution/send:
 *   post:
 *     tags:
 *       - API Distribuição Automatos
 *     summary: Realiza o envio da distribuição
 *     responses:
 *       200:
 *         description: Realiza o login e retorna o JWT token para uso da api de instalação
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 status:
 *                   type: boolean
 *                   description: Status da operação.
 *                   example: true
 *                 data:
 *                   type: object
 *                   properties:
 *                     token:
 *                       type: string
 *                       example: "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9..."
 *
 *       400:
 *         description: Requisição inválida ou máquina não localizada
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 status:
 *                   type: boolean
 *                   example: false
 *                 data:
 *                   type: object
 *                   example: {}
 *                 error:
 *                   type: string
 *                   example: "Machine not found"
 */

/**
 * @swagger
 * /distribution/resend:
 *   patch:
 *     tags:
 *       - API Distribuição Automatos
 *     summary: Realiza o reenvio da distribuição
 *     requestBody:
 *           required: true
 *           content:
 *             application/json:
 *               schema:
 *                 type: object
 *                 properties:
 *                   id:
 *                     type: number
 *                     description: Id da instalação salva na banco de dados
 *                     example: 1
 *                 required:
 *                   - id
 *     responses:
 *       200:
 *         description: Realiza o reenvio da distribuição
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 message:
 *                   type: string
 *                   description: Mensagem de sucesso no reenvio da instalação
 *                   example: "Instalação enviada"
 *       400:
 *         description: Requisição inválida ou falha no reenvio da instalação
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 message:
 *                   type: string
 *                   example: "error.message"
 */

/**
 * @swagger
 * /public/machine:
 *   get:
 *     tags:
 *       - API Pública Automatos
 *     summary: Busca as informações de hardware e software de uma máquina
 *     responses:
 *       200:
 *         description: Retorna informações detalhadas da máquina, incluindo hardware, software e rede.
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 computer_name:
 *                   type: string
 *                   description: Nome do computador.
 *                   example: "WN094TI001"
 *                 department_name:
 *                   type: string
 *                   description: Nome do departamento associado à máquina.
 *                   example: "CDS"
 *                 department_hierarchy:
 *                   type: string
 *                   description: Hierarquia do departamento.
 *                   example: "CDS"
 *                 so_string:
 *                   type: string
 *                   description: Sistema operacional instalado.
 *                   example: "WINDOWS 11 PRO"
 *                 system_manufacturer:
 *                   type: string
 *                   description: Fabricante do sistema.
 *                   example: "Dell"
 *                 computer_type:
 *                   type: string
 *                   description: Tipo do computador (desktop, notebook, etc.).
 *                   example: "NOTEBOOK"
 *                 machine_net_ipaddress:
 *                   type: string
 *                   description: Endereço IP da máquina.
 *                   example: "192.168.15.19"
 *                 bios_release_date:
 *                   type: string
 *                   format: date
 *                   description: Data de liberação da BIOS.
 *                   example: "2023-07-06"
 *                 machine_ipdomain:
 *                   type: string
 *                   description: Domínio IP da máquina.
 *                   example: "magazineluiza.intranet"
 *                 is_virtual_machine:
 *                   type: string
 *                   description: Indica se a máquina é virtual.
 *                   example: "S"
 *                 system_product_name:
 *                   type: string
 *                   description: Nome do produto do sistema.
 *                   example: "Latitude 3410"
 *                 system_serial_number:
 *                   type: string
 *                   description: Número de série do sistema.
 *                   example: "4JLCH73"
 *                 machine_id:
 *                   type: string
 *                   description: ID único da máquina.
 *                   example: "8C47BE1555CD08B37670155D"
 *                 os_bits:
 *                   type: integer
 *                   description: Quantidade de bits do sistema operacional.
 *                   example: 64
 *                 login_name:
 *                   type: string
 *                   description: Nome de login do usuário atual.
 *                   example: "wel_rocha"
 *                 cpu_identity:
 *                   type: string
 *                   description: Identidade do processador.
 *                   example: "Intel(R) Core(TM) i5-10210U CPU @ 1.60GHz"
 *                 memory_range:
 *                   type: string
 *                   description: Faixa de memória disponível.
 *                   example: "32 GB"
 *                 softwareDetails:
 *                   type: array
 *                   description: Lista de softwares instalados e suas datas de instalação.
 *                   items:
 *                     type: object
 *                     properties:
 *                       name:
 *                         type: string
 *                         description: Nome do software.
 *                         example: "MICROSOFT EXCEL 2013"
 *                       instalation_dates:
 *                         type: array
 *                         description: Datas de instalação do software.
 *                         items:
 *                           type: string
 *                           format: date-time
 *                           example: "2024-02-07 08:07:10"
 *       400:
 *         description: Requisição inválida ou máquina não localizada
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 message:
 *                   type: string
 *                   example: "Erro ao consultar a máquina"
 *                 details:
 *                   type: object
 *                   example: {}
 *                 error:
 *                   type: string
 *                   example: "error.message"
 */
