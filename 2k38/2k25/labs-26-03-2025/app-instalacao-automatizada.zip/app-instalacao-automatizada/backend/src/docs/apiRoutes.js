/**
 * @swagger
 * components:
 *   securitySchemes:
 *     bearerAuth:
 *       type: http
 *       scheme: bearer
 *       bearerFormat: JWT
 *   schemas:
 *     User:
 *       type: object
 *       properties:
 *         id:
 *           type: integer
 *         name:
 *           type: string
 *         email:
 *           type: string
 * security:
 *   - bearerAuth: []
 */

/**
 * @swagger
 * /api/history:
 *   get:
 *     tags:
 *       - API própria
 *     summary: Histórico de instalações enviadas
 *     responses:
 *       200:
 *         description: Histórico de instalações enviadas
 *         content:
 *           application/json:
 *             schema:
 *               type: array
 *               items:
 *                 type: object
 *                 properties:
 *                   id:
 *                     type: integer
 *                   software:
 *                     type: string
 *                   hostname_maquina_alvo:
 *                     type: string
 *                   id_automatos_maquina_alvo:
 *                     type: string
 *                   status:
 *                     type: string
 *                   enviado_por:
 *                     type: string
 *                   tempo_ate_verificacao:
 *                     type: string
 *                   create_at:
 *                     type: string
 *                     format: date-time
 *                   updated_at:
 *                     type: string
 *                     format: date-time
 */

/**
 * @swagger
 * /api/manualcheck:
 *   patch:
 *     summary: Faz a checagem manual das instalações
 *     tags:
 *       - API própria
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             type: object
 *             properties:
 *               hostname:
 *                 type: string
 *               automatosID:
 *                 type: string
 *               packageToInstall:
 *                 type: string
 *     responses:
 *       200:
 *         description: "Instalação enviada"
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 message:
 *                   type: string
 *                   example: Instalação enviada
 *       500:
 *         description: "Erro na instalação"
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 message:
 *                   type: string
 *                   example: error.message
 */

/**
 * @swagger
 * /api/register:
 *   post:
 *     summary: Registra um novo usuário
 *     description: Essa rota permite registrar um novo usuário no sistema, verificando se o login já existe e criando o usuário com uma senha criptografada.
 *     tags:
 *         - API própria
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             type: object
 *             properties:
 *               username:
 *                 type: string
 *                 description: Nome completo do usuário
 *               login:
 *                 type: string
 *                 description: Login único do usuário
 *               password:
 *                 type: string
 *                 description: Senha do usuário
 *     responses:
 *       201:
 *         description: Usuário registrado com sucesso
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 message:
 *                   type: string
 *                   example: "Usuário registrado com sucesso!"
 *       400:
 *         description: Erro ao registrar o usuário, como login já existente ou falha ao consultar banco de dados
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 error:
 *                   type: string
 *                   example: "error.message"
 */

/**
 * @swagger
 * /api/login:
 *   post:
 *      summary: Realiza o login do usuário
 *      description: Autentica o usuário com base no login e senha fornecidos e retorna um token JWT
 *      tags:
 *         - API própria
 *      requestBody:
 *        required: true
 *        content:
 *          application/json:
 *            schema:
 *              type: object
 *              properties:
 *                login:
 *                  type: string
 *                  description: Nome de usuário ou e-mail cadastrado no sistema.
 *                  example: "string"
 *                password:
 *                  type: string
 *                  description: Senha do usuário.
 *                  example: "string"
 *              required:
 *                - login
 *                - password
 *      responses:
 *        '200':
 *          description: Login bem-sucedido.
 *          content:
 *            application/json:
 *              schema:
 *                type: object
 *                properties:
 *                  message:
 *                    type: string
 *                    example: "Login bem-sucedido"
 *                  token:
 *                    type: string
 *                    description: Token JWT válido por 24 horas.
 *                    example: "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9..."
 *                  username:
 *                    type: string
 *                    description: Nome do usuário autenticado.
 *                    example: "string"
 *        400:
 *          description: Requisição inválida
 *          content:
 *            application/json:
 *              schema:
 *                type: object
 *                properties:
 *                  error:
 *                    type: string
 *                    example: "error.message"
 */

/**
 * @swagger
 * /api/changepassword:
 *   post:
 *      summary: Realiza o troca de senha do usuário
 *      description:
 *      tags:
 *         - API própria
 *      requestBody:
 *        required: true
 *        content:
 *          application/json:
 *            schema:
 *              type: object
 *              properties:
 *                password:
 *                  type: string
 *                  description: Senha atual
 *                  example: "string"
 *                newPassword:
 *                  type: string
 *                  description: Nova senha
 *                  example: "string"
 *              required:
 *                - password
 *                - newPassword
 *      responses:
 *        '200':
 *          description: Login bem-sucedido.
 *          content:
 *            application/json:
 *              schema:
 *                type: object
 *                properties:
 *                  message:
 *                    type: string
 *                    example: "Login bem-sucedido"
 *                  token:
 *                    type: string
 *                    description: Token JWT válido por 24 horas.
 *                    example: "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9..."
 *                  username:
 *                    type: string
 *                    description: Nome do usuário autenticado.
 *                    example: "string"
 *        400:
 *          description: Requisição inválida
 *          content:
 *            application/json:
 *              schema:
 *                type: object
 *                properties:
 *                  error:
 *                    type: string
 *                    example: "error.message"
 */
