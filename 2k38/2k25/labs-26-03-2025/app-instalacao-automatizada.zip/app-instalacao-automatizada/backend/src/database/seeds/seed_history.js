exports.seed = function (knex) {
  return knex("history")
    .del()
    .then(function () {
      return knex("history").insert([
        {
          software: "Office_STD_2013_X64",
          maquina_alvo: "8C47BE1555CD08B37670155D",
          status: "enviado",
          enviado_por: "wel_rocha",
        },
        {
          software: "Office_STD_2013_X64",
          maquina_alvo: "9F67BE1555CD08B37670188D",
          status: "pendente",
          enviado_por: "wel_rocha",
        },
        {
          software: "Office_STD_2013_X64",
          maquina_alvo: "9F67BE1555CD08B37670188D",
          status: "pendente",
          enviado_por: "wel_rocha",
        },
        {
          software: "Office_STD_2013_X64",
          maquina_alvo: "9F67BE1555CD08B37670188D",
          status: "pendente",
          enviado_por: "wel_rocha",
        },
        {
          software: "Office_STD_2013_X64",
          maquina_alvo: "9F67BE1555CD08B37670188D",
          status: "pendente",
          enviado_por: "wel_rocha",
        },
        {
          software: "Office_STD_2013_X64",
          maquina_alvo: "9F67BE1555CD08B37670188D",
          status: "enviado",
          enviado_por: "wel_rocha",
        },
        {
          software: "Office_STD_2013_X64",
          maquina_alvo: "9F67BE1555CD08B37670188D",
          status: "cancelado",
          enviado_por: "wel_rocha",
        },
        {
          software: "Office_STD_2013_X64",
          maquina_alvo: "9F67BE1555CD08B37670188D",
          status: "com erro",
          enviado_por: "wel_rocha",
        },
      ]);
    });
};
