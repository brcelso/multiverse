const knex = require("knex")(require("../../../knexfile").development);

exports.up = async function (knex) {
  const tableExists = await knex.schema.hasTable("users");

  if (!tableExists) {
    return knex.schema
      .createTable("users", (table) => {
        table.increments("id").primary();
        table.string("username").notNullable();
        table.string("login").notNullable();
        table.string("password").notNullable();
        table.timestamps(true, true);
      })
      .then(() => {
        console.log("Tabela 'users' criada");
      })
      .catch((err) => {
        console.error("Erro ao criar a tabela users:", err.message);
      });
  }
};

exports.down = function (knex) {
  return knex.schema.dropTableIfExists("users");
};
