const knex = require("knex")(require("../../../knexfile").development);

exports.up = async function (knex) {
  const tableExists = await knex.schema.hasTable("history");

  if (!tableExists) {
    return knex.schema
      .createTable("history", (table) => {
        table.increments("id").primary();
        table.string("software").notNullable();
        table.string("hostname_maquina_alvo").notNullable();
        table.string("id_automatos_maquina_alvo").notNullable();
        table.string("status").notNullable();
        table.string("enviado_por").notNullable();
        table.dateTime("tempo_ate_verificacao").notNullable();
        table.timestamps(true, true);
      })
      .then(() => {
        console.log("Tabela 'history' criada com sucesso");
      })
      .catch((err) => {
        console.error("Erro ao criar a tabela 'history':", err.message);
      });
  }
};

exports.down = function (knex) {
  return knex.schema.dropTableIfExists("history");
};
