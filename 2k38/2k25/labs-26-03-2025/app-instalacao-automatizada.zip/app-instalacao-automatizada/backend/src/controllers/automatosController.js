require("dotenv").config();
const axios = require("axios");
const knexConfig = require("../../knexfile").development;
const knex = require("knex")(knexConfig);

const API_automatosID = process.env.AUTOMATOS_ID;
const API_automatosKey = process.env.AUTOMATOS_KEY;

exports.distributionAuth = async (req, res) => {
  const authEndpoint = "https://lad1-smartcenter.almaden.app/api/distribution/api/auth";

  const authPayload = {
    automatosId: API_automatosID,
    automatosKey: API_automatosKey,
  };

  try {
    const authResponse = await axios.post(authEndpoint, authPayload, {
      httpsAgent: new (require("https").Agent)({ rejectUnauthorized: false }),
    });

    if (authResponse.status === 200) {
      const token = authResponse.data?.data?.token;

      if (token) {
        req.session.token = token;
        res.status(200).json({ message: "Login realizado com sucesso", token: token });
      } else {
        res.status(400).json({ message: "Token não encontrado na resposta" });
      }
    } else {
      res.status(authResponse.status).json({
        message: `Erro ao requisitar o token, status: ${authResponse.status}`,
        details: authResponse.data,
      });
    }
  } catch (error) {
    res.status(500).json({ message: "Erro ao fazer a requisição", error: error.message });
  }
};

exports.distributionMachine = async (req, res) => {
  const getMachineEndpoint = "https://lad1-smartcenter.almaden.app/api/distribution/api/machine";

  const token = req.session.token;
  const { hostname } = req.query;

  if (!token) {
    return res.status(401).json({ message: "Token não encontrado. Por favor, faça o login novamente." });
  }

  try {
    const machineResponse = await axios.get(`${getMachineEndpoint}?hostname=${hostname}`, {
      headers: { Authorization: `Bearer ${token}` },
      httpsAgent: new (require("https").Agent)({ rejectUnauthorized: false }),
    });

    if (machineResponse.status === 200) {
      const machines = machineResponse.data?.data?.machines || [];

      if (machines.length > 0) {
        if (machines.length > 1) {
          console.log(`Mais de uma máquina encontrada com o hostname ${hostname}`);
          return res.status(400).json({
            message: `Mais de uma máquina encontrada com esse hostname`,
            data: machines.map((machine) => machine.machineId),
          });
        }

        let machineId = machines[0]?.machineId;

        return res.status(200).json({
          message: `Máquina ${hostname} encontrada`,
          machineId: machineId,
        });
      } else {
        return res.status(404).json({
          message: "Nenhuma máquina encontrada para o hostname fornecido.",
        });
      }
    } else {
      return res.status(machineResponse.status).json({
        message: `Erro na requisição para consultar a máquina, status: ${machineResponse.status}`,
        details: machineResponse.data,
      });
    }
  } catch (error) {
    return res.status(500).json({
      message: "Erro ao consultar a máquina",
      error: error.message,
    });
  }
};

exports.distributionSend = async (req, res) => {
  const { hostname, automatosID, packageToInstall } = req.body;
  let status = "";

  if (packageToInstall.toLowerCase().includes("remover")) {
    status = "Verificação manual";
  } else {
    status = "Em verificação";
  }

  const sendDistributionEndpoint = "https://lad1-smartcenter.almaden.app/api/distribution/api/express/distribution";

  const token = req.session.token;

  const sendDistributionPayload = {
    machineId: automatosID,
    package: packageToInstall,
    domain: "magazineluiza",
    user: process.env.ADMIN_USER,
    password: process.env.ADMIN_PASSWORD,
    irradiadora: "0050569D1593CA8AC001114D",
  };

  let distributionResponse = "";
  let insertedId = "";

  try {
    distributionResponse = await axios.post(sendDistributionEndpoint, sendDistributionPayload, {
      headers: { Authorization: `Bearer ${token}` },
      httpsAgent: new (require("https").Agent)({ rejectUnauthorized: false }),
    });
  } catch (error) {
    console.error(`Erro ao enviar a distribuição: ${error.response?.data?.error}`);
    return res.status(500).send({ message: error.response?.data?.error });
  }

  if (distributionResponse.status === 200) {
    let { login } = req.user;
    let now = new Date();
    let timeUntilVerification = new Date(now.getTime() + 30 * 60 * 1000);

    try {
      [insertedId] = await knex("history").insert({
        software: sendDistributionPayload.package,
        hostname_maquina_alvo: hostname,
        id_automatos_maquina_alvo: sendDistributionPayload.machineId,
        status: status,
        tempo_ate_verificacao: timeUntilVerification,
        enviado_por: login,
      });

      console.log("Dados persistidos com sucesso! ID da instalação:", insertedId);

      return res.status(200).send({ message: "Instalação enviada" });
    } catch (error) {
      console.error("Erro ao salvar a distribuição:", error.message);
      return res.status(500).send({ message: error.message });
    }
  }
};

exports.distributionResend = async (req, res) => {
  const { id } = req.body;
  let status = "";

  const distribution = await knex("history").where("id", id).first();

  if (distribution.software.toLowerCase().includes("remover")) {
    status = "Verificação manual";
  } else {
    status = "Em verificação";
  }

  const sendDistributionEndpoint = "https://lad1-smartcenter.almaden.app/api/distribution/api/express/distribution";

  const token = req.session.token;

  const sendDistributionPayload = {
    machineId: distribution.id_automatos_maquina_alvo,
    package: distribution.software,
    domain: "magazineluiza",
    user: process.env.ADMIN_USER,
    password: process.env.ADMIN_PASSWORD,
    irradiadora: "0050569D1593CA8AC001114D",
  };

  let distributionResponse = "";

  try {
    distributionResponse = await axios.post(sendDistributionEndpoint, sendDistributionPayload, {
      headers: { Authorization: `Bearer ${token}` },
      httpsAgent: new (require("https").Agent)({ rejectUnauthorized: false }),
    });
  } catch (error) {
    console.error(`Erro ao reenviar a distribuição: ${error.response?.data?.error}`);
    return res.status(500).send({ message: error.response?.data?.error });
  }

  if (distributionResponse.status === 200) {
    let { login } = req.user;
    let now = new Date();
    let timeUntilVerification = new Date(now.getTime() + 30 * 60 * 1000);

    try {
      await knex("history").where("id", id).update({
        status: status,
        tempo_ate_verificacao: timeUntilVerification,
        enviado_por: login,
        created_at: now,
      });

      console.log("Dados do reenvio persistidos com sucesso!");

      return res.status(200).send({ message: "Instalação enviada" });
    } catch (error) {
      console.error("Erro ao salvar a distribuição:", error.message);
      return res.status(500).send({ message: error.message });
    }
  }
};

exports.findMachineData = async (req, res) => {
  const { hostname } = req.query;

  const base_url = "https://lad1-smartcenter.almaden.app/api/public";
  const getAllHardwareEndpoint = `${base_url}/api/getAllHardware/desktops?AutomatosId=${API_automatosID}&Securitykey=${API_automatosKey}&hostname=${hostname}`;
  const getAllSoftwareEndpoint = `${base_url}/v1/getAllSoftware/nextpage/desktops?AutomatosId=${API_automatosID}&Securitykey=${API_automatosKey}&hostname=${hostname}`;

  try {
    const getHardwareResponse = await axios.get(getAllHardwareEndpoint, {
      httpsAgent: new (require("https").Agent)({ rejectUnauthorized: false }),
      timeout: 30000,
    });

    const getSoftwareResponse = await axios.get(getAllSoftwareEndpoint, {
      httpsAgent: new (require("https").Agent)({ rejectUnauthorized: false }),
      timeout: 30000,
    });

    if (getHardwareResponse.status === 200) {
      let machineData = getHardwareResponse.data || [];

      if (machineData.length <= 0) {
        return res.status(404).json({
          message: `Máquina não encontrada`,
        });
      }

      if (machineData.length > 1) {
        return res.status(404).json({
          message: `Mais de uma máquina encontrada com o hostname ${hostname}`,
          data: machineData.map((machine) => machine.machineId),
        });
      }

      if (getSoftwareResponse.status === 200) {
        const getSoftwareResponseData = getSoftwareResponse.data.data;
        const inclusionKeywords = ["excel", "office", "automatos", "trend", "netskope", "power", "manageengine"];
        const exclusionKeywords = ["dell", "powershell", "mui", "shared", "proofing", "herramientas", "revisores", "components", "proof", "teams", "pdf", "click", "visual"];

        const findInstallations = getSoftwareResponseData.filter((software) => {
          const softwareName = software.software_name.toLowerCase();

          const isIncluded = inclusionKeywords.some((keyword) => softwareName.includes(keyword));
          const isExcluded = exclusionKeywords.some((keyword) => softwareName.includes(keyword));

          return isIncluded && !isExcluded;
        });

        if (findInstallations.length > 0) {
          const groupedSoftwareDetails = findInstallations.reduce((accumulator, software) => {
            const { software_name: software_name, instalation_date } = software;

            if (accumulator[software_name]) {
              accumulator[software_name].push(instalation_date);
            } else {
              accumulator[software_name] = [instalation_date];
            }

            return accumulator;
          }, {});

          const softwareDetails = Object.entries(groupedSoftwareDetails).map(([name, dates]) => ({
            name,
            instalation_dates: dates,
          }));

          machineData[0] = {
            ...machineData[0],
            softwareDetails: JSON.stringify(softwareDetails),
          };
        } else {
          machineData[0] = {
            ...machineData[0],
            softwareDetails: JSON.stringify([]),
          };
        }

        return res.status(200).json({
          message: `Máquina ${hostname} encontrada`,
          data: machineData,
        });
      }
    }
  } catch (error) {
    const status = error.response?.status || 500;
    const details = error.response?.data || "Erro desconhecido";
    console.log(error.message);

    if (error.code === "ECONNABORTED") {
      return res.status(408).json({
        message: "Tempo esgotado na requisição",
        error: error.message,
      });
    }

    return res.status(status).json({
      message: "Erro ao consultar a máquina",
      details,
      error: error.message,
    });
  }
};

exports.massiveDistribution = async (req, res) => {
  const { hostnames, packageToInstall } = req.body;
  const token = req.session.token;
  const results = [];
  const base_url = "https://lad1-smartcenter.almaden.app/api";

  if (!Array.isArray(hostnames) || hostnames.length === 0) {
    return res.status(400).json({ error: "Campo Hostnames está vazio" });
  }

  if (!packageToInstall) {
    return res.status(400).json({ error: "Campo Pacote está vazio" });
  }

  async function getMachineID(hostname) {
    const getAllHardwareEndpoint = `${base_url}/public/api/getAllHardware/desktops?AutomatosId=${API_automatosID}&Securitykey=${API_automatosKey}&hostname=${hostname}`;
    let machine_id = "";

    try {
      const getHardwareResponse = await axios.get(getAllHardwareEndpoint, {
        httpsAgent: new (require("https").Agent)({ rejectUnauthorized: false }),
        timeout: 30000,
      });

      if (getHardwareResponse.status !== 200 || !getHardwareResponse.data || getHardwareResponse.data.length === 0) {
        results.push({
          hostname,
          package: packageToInstall,
          status: "failure",
          message: "Máquina não encontrada",
        });

        return (machine_id = "");
      }

      const machineData = getHardwareResponse.data;

      if (machineData.length > 1) {
        results.push({
          hostname,
          package: packageToInstall,
          status: "failure",
          message: "Hostname duplicado",
        });

        return (machine_id = "");
      }

      return (machine_id = machineData[0].machine_id);
    } catch (error) {
      results.push({
        hostname,
        package: packageToInstall,
        status: "failure",
        message: "Erro ao buscar máquina",
      });

      console.log(`Erro ao buscar a máquina: ${error.response?.data?.error || error.message}`);
      return (machine_id = "");
    }
  }

  async function sendDistribution(hostname, machine_id, packageToInstall) {
    const sendDistributionEndpoint = `${base_url}/distribution/api/express/distribution`;

    const sendDistributionPayload = {
      machineId: machine_id,
      package: packageToInstall,
      domain: "magazineluiza",
      user: process.env.ADMIN_USER,
      password: process.env.ADMIN_PASSWORD,
      irradiadora: "0050569D1593CA8AC001114D",
    };

    try {
      const distributionResponse = await axios.post(sendDistributionEndpoint, sendDistributionPayload, {
        headers: { Authorization: `Bearer ${token}` },
        httpsAgent: new (require("https").Agent)({ rejectUnauthorized: false }),
      });

      if (distributionResponse.status === 200) {
        await persistInDatabase(packageToInstall, hostname, machine_id);

        results.push({
          hostname,
          package: packageToInstall,
          status: "success",
          message: "Enviada com sucesso",
        });
      }
    } catch (error) {
      results.push({
        hostname,
        package: packageToInstall,
        status: "failure",
        message: `Erro ao enviar a distribuição`,
      });

      console.log(`Erro ao enviar a distribuição: ${error.response?.data?.error || error.message}`);
    }
  }

  async function persistInDatabase(packageToInstall, hostname, machine_id) {
    const { login } = req.user;
    const status = "Em verificação";
    const now = new Date();
    const timeUntilVerification = new Date(now.getTime() + 30 * 60 * 1000);

    try {
      await knex("history").insert({
        software: packageToInstall,
        hostname_maquina_alvo: hostname,
        id_automatos_maquina_alvo: machine_id,
        status: status,
        tempo_ate_verificacao: timeUntilVerification,
        enviado_por: login,
      });
    } catch (error) {
      results.push({
        hostname,
        package: packageToInstall,
        status: "failure",
        message: "Erro ao salvar a distribuição",
      });

      console.log(`Erro ao salvar a distribuição: ${error.response?.data?.error || error.message}`);
    }
  }

  for (const hostname of hostnames) {
    let machine_id = await getMachineID(hostname);

    if (machine_id !== "") {
      await sendDistribution(hostname, machine_id, packageToInstall);
    }
  }

  return res.status(200).json({ results });
};
