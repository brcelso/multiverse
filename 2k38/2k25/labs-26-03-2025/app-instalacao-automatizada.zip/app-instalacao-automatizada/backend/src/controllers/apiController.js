require("dotenv").config();
const axios = require("axios");
const knexConfig = require("../../knexfile").development;
const knex = require("knex")(knexConfig);

exports.getHistory = async (req, res) => {
  try {
    const historyData = await knex("history").orderBy("created_at", "desc").limit(15);
    return res.status(200).json(historyData);
  } catch (error) {
    console.error("Erro ao buscar o histórico:", error.message);
    return res.status(500).json({ message: "Erro ao buscar o histórico", error: error.message });
  }
};

exports.manualCheck = async (req, res) => {
  const { id, opcao } = req.body;

  try {
    const updatedRows = await knex("history").where({ id: id }).update({ status: opcao });

    if (updatedRows) {
      return res.status(200).json({ message: "Status atualizado com sucesso!" });
    } else {
      return res.status(404).json({ message: "Item não encontrado" });
    }
  } catch (error) {
    console.log("Erro ao atualizar o status da instalação manualmente: " + error);
    return res.status().json({ message: "Erro ao atualizar o status da instalação" });
  }
};
