require("dotenv").config();
const knexConfig = require("../../knexfile").development;
const knex = require("knex")(knexConfig);
const bcrypt = require("bcryptjs");
const jwt = require("jsonwebtoken");

exports.register = async (req, res) => {
  const { username, login, password } = req.body;

  try {
    const userExists = await knex("users").where("login", login).first();

    if (userExists) {
      return res.status(400).json({ message: "Usuário já existe!" });
    }
  } catch (error) {
    console.log("Erro ao constular o usuário", error.message);
    return res.status(400).json({ message: "Erro ao constular o usuário", error: error.message });
  }
  const hashedPassword = await bcrypt.hash(password, 10);

  try {
    const [insertedUserId] = await knex("users").insert({
      username: username,
      login: login,
      password: hashedPassword,
    });

    console.log("Dados persistidos com sucesso! ID do usuário:", insertedUserId.id);

    return res.status(201).json({ message: "Usuário registrado com sucesso!" });
  } catch (error) {
    console.error("Erro ao criar o usuário:", error.message);
    return res.status(400).send({ message: error.message });
  }
};

exports.login = async (req, res) => {
  const { login, password } = req.body;

  const user = await knex("users").where("login", login).first();

  if (!user) {
    return res.status(400).json({ message: "Usuário não encontrado" });
  }

  const isMatch = await bcrypt.compare(password, user.password);
  if (!isMatch) {
    return res.status(400).json({ message: "Usuário ou senha incorretos" });
  }

  const token = jwt.sign({ id: user.id, login: user.login, username: user.username }, process.env.JWT_SECRET, { expiresIn: "24h" });

  console.log("Sucesso na autenticação");
  return res.json({ message: "Login bem-sucedido", token: token, username: user.username });
};

exports.changePassword = async (req, res) => {
  const { password, newPassword } = req.body;

  if (!password || !newPassword) {
    return res.status(400).json({ message: "Todos os campos são obrigatórios" });
  }

  try {
    const { id } = req.user;
    const user = await knex("users").where("id", id).first();

    if (!user) {
      return res.status(400).json({ message: "Usuário inexistente" });
    }

    const isMatch = await bcrypt.compare(password, user.password);

    if (!isMatch) {
      return res.status(400).json({ message: "Senha atual não confere" });
    }

    const hashedNewPassword = await bcrypt.hash(newPassword, 10);

    await knex("users").where("id", id).update({
      password: hashedNewPassword,
    });

    console.log("Senha alterada com sucesso");

    return res.status(201).json({ message: "Senha alterada com sucesso!" });
  } catch (error) {
    console.log("Erro ao consultar o usuário", error.message);
    return res.status(400).json({ message: "Tente mais tarde", error: error.message });
  }
};
