const axios = require("axios");

exports.automatosAuth = async (req, res, next) => {
  if (req.session.token) {
    return next();
  }

  const authEndpoint = "https://lad1-smartcenter.almaden.app/api/distribution/api/auth";
  const authPayload = {
    automatosId: process.env.AUTOMATOS_ID,
    automatosKey: process.env.AUTOMATOS_KEY,
  };

  try {
    const authResponse = await axios.post(authEndpoint, authPayload, {
      httpsAgent: new (require("https").Agent)({ rejectUnauthorized: false }),
    });

    if (authResponse.status === 200) {
      const token = authResponse.data?.data?.token;
      if (token) {
        req.session.token = token;
        return next();
      } else {
        return res.status(400).json({ message: "Token não encontrado na resposta" });
      }
    } else {
      return res.status(authResponse.status).json({
        message: `Erro ao requisitar o token, status: ${authResponse.status}`,
        details: authResponse.data,
      });
    }
  } catch (error) {
    return res.status(500).json({ message: "Erro ao fazer a autenticação", error: error.message });
  }
};
