const express = require("express");
const router = express.Router();

const { authenticateToken } = require("../middlewares/authenticateToken");

const apiController = require("../controllers/apiController");
const authenticationController = require("../controllers/authenticationController");

router.get("/history", authenticateToken, apiController.getHistory);
router.patch("/manualcheck", authenticateToken, apiController.manualCheck);

router.post("/register", authenticationController.register);
router.post("/login", authenticationController.login);
router.post("/changepassword", authenticateToken, authenticationController.changePassword);

module.exports = router;
