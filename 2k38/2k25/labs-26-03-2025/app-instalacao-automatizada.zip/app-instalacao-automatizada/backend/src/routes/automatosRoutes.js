const express = require("express");
const router = express.Router();

const { automatosAuth } = require("../middlewares/automatosAuth");
const { authenticateToken } = require("../middlewares/authenticateToken");

const automatosController = require("../controllers/automatosController");

router.get("/distribution/machine", authenticateToken, automatosController.distributionMachine);
router.post("/distribution/auth", automatosController.distributionAuth);
router.post("/distribution/send", authenticateToken, automatosAuth, automatosController.distributionSend);
router.patch("/distribution/resend", authenticateToken, automatosAuth, automatosController.distributionResend);
router.post("/distribution/massive", authenticateToken, automatosAuth, automatosController.massiveDistribution);

router.get("/public/machine", authenticateToken, automatosController.findMachineData);

module.exports = router;
