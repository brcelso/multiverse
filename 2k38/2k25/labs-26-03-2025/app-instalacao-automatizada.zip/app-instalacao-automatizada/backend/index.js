const express = require("express");
const session = require("express-session");
const swaggerUi = require("swagger-ui-express");
const swaggerSpecs = require("./swaggerConfig");
const cors = require("cors");
require("dotenv").config();

const verifyInstallation = require("./src/services/verifyInstallation");

const automatosRoutes = require("./src/routes/automatosRoutes");
const apiRoutes = require("./src/routes/apiRoutes");

const app = express();
const port = 3001;

app.use(cors());

app.use("/api-docs", swaggerUi.serve, swaggerUi.setup(swaggerSpecs));

app.use(
  session({
    secret: process.env.SESSION_SECRET,
    resave: false,
    saveUninitialized: true,
    cookie: { secure: false },
  })
);

app.use(express.json());
app.use(express.urlencoded({ extended: true }));

app.use("/automatos", automatosRoutes);
app.use("/api", apiRoutes);

verifyInstallation.startService();

app.listen(port, () => {
  console.log(`Server is running on http://localhost:${port}`);
});
