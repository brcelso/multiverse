Set-Location $PSScriptRoot
Clear-Host

if (-not (Get-Module -Name PSReadLine -ListAvailable)) {
    Install-Module -Name PSReadLine -Force -SkipPublisherCheck
}

if (-not (Get-Module -Name ActiveDirectory -ListAvailable)) {
    Install-Module -Name ActiveDirectory -Force -SkipPublisherCheck
}

Import-Module PSReadLine
Import-Module ActiveDirectory

$usuario = ""

function exibir_menu($opcoes, $titulo) {
    
    $selecao = 0
    
    do {
        Clear-Host
        Write-Host `n$titulo`n -ForegroundColor Cyan
            
        for ($i = 0; $i -lt $opcoes.Count; $i++) {
            $opcao = $opcoes[$i]
            $seta = if ($i -eq $selecao) { ">" } else { " " }
            Write-Host "$seta $opcao"
        }
    
        # Aguarda a entrada do usuário
        $tecla = $null
        $tecla = $host.UI.RawUI.ReadKey("NoEcho,IncludeKeyDown")
    
        # Atualiza a seleção com base na tecla pressionada
        switch ($tecla.VirtualKeyCode) {
            38 { $selecao = [Math]::Max(0, $selecao - 1) }  # Seta para cima
            40 { $selecao = [Math]::Min($opcoes.Count - 1, $selecao + 1) }  # Seta para baixo
        }
    } while ($tecla.VirtualKeyCode -ne 13)  # Continue até que Enter seja pressionado
    
    return $opcoes[$selecao]
}

function get_permissao_SID($permissao) {
    $ssp = New-Object System.Security.Principal.NTAccount($permissao)
    $SID = $ssp.Translate([System.Security.Principal.SecurityIdentifier])
    return $SID
}

function solicita_confirmacao($usuario, $permissao_selecionada) {
    $resposta = ""

    while ($resposta -ne "s" -and $resposta -ne "n") {
        Write-Host `n"Deseja adicionar a permissao $permissao_selecionada para o usuario $usuario ? (s/n): " -NoNewline -ForegroundColor Yellow
        $resposta = Read-Host

        if ($resposta -ne "s" -and $resposta -ne "n") {
            $resposta = ""
            Write-Host `n"Resposta invalida, digite somente s ou n"`n -ForegroundColor Yellow
        }
    }

    if ($resposta -eq "n") {
        Write-Host `n`n"Processo cancelado" -ForegroundColor Yellow
        Break
    }
}

function insere_permissao($usuario, $permissao_selecionada) {
    try {
        $usuario_SID = get_permissao_SID $usuario
        $permissao_SID = get_permissao_SID $permissao_selecionada

        Add-ADGroupMember -Identity $permissao_SID -Members $usuario_SID -ErrorAction Stop
        Write-Host `n"Permissao adicionada com sucesso"`n
    }
    catch {
        Write-Host `n"Falha ao adicionar a permissao:" $Error[0] `n -ForegroundColor Yellow
    }
}

function inserir_permissao_pasta($usuario) {

    $path = ""
    $opcoes = @()
    $permissao_selecionada = ""
    $resposta = ""

    While (-not $path -or $path.Length -le 2 -or $path -eq "") {
        Write-Host ""
        $path = Read-Host "Digite o caminho da pasta"

        if (-not $path -or $path.Length -le 2 -or $path -eq "") {
            $path = ""
            Write-Host `n"Caminho da pasta e invalido ou nao foi preenchido"`n -ForegroundColor Yellow
            Start-Sleep -Seconds 2
            Clear-Host
        }
    }

    

    $acl = Get-Acl -Path $path

    foreach ($ace in $acl.Access) {
        if ($ace.IdentityReference -like "*GNTFS*" -or $ace.IdentityReference -like "*GNTFSSP*") {
            $opcoes += $ace.IdentityReference
        }
    }

    $permissao_selecionada = exibir_menu $opcoes "=== Seleciona a permissao a ser inserida ==="

    solicita_confirmacao $usuario $permissao_selecionada
    insere_permissao $usuario $permissao_selecionada

}

function inserir_permissao_servidor($usuario) {
    $opcoes = @(
        "Farmec 0",
        "Farmec 1",
        "Farmec 2",
        "Mastersaf (ml-ibm-msaf-01.magalu.io)",
        "Plan com 04",
        "S505VPNTS (antigo)",
        "VPNTS02 (novo)",
        "NLBEC (ml-ibm-nlbec01)",
        "MGC-S500MTG01 (10.184.12.182)",
        "S500HMLFP1 (10.31.0.128)"
        "acs-hml-fp-01 (10.6.11.75)"
    )
    $permissao_selecionada = ""

    $permissao_selecionada = exibir_menu $opcoes "=== Selecione o servidor que o usuario tera acesso ==="
    
    solicita_confirmacao $usuario $permissao_selecionada
    
    switch ($permissao_selecionada) {
        "Farmec 0" { insere_permissao $usuario "MAGAZINELUIZA\GTS_NLBEC02" }
        "Farmec 1" { insere_permissao $usuario "MAGAZINELUIZA\GTS_FARM_EC01" }
        "Farmec 2" { insere_permissao $usuario "MAGAZINELUIZA\GTS_SAC_FARM02" }
        "Mastersaf (ml-ibm-msaf-01.magalu.io)" { insere_permissao $usuario "MAGAZINELUIZA\GTS_MSAF" }
        "Plan com 04" { insere_permissao $usuario "MAGAZINELUIZA\GTS_S900PLANCOM" }
        "S505VPNTS (antigo)" { insere_permissao $usuario "MAGAZINELUIZA\GTS_VPNTS" }
        "VPNTS02 (novo)" { insere_permissao $usuario "MAGAZINELUIZA\GTS_S500VPNTS02" }
        "NLBEC (ml-ibm-nlbec01)" { insere_permissao $usuario "MAGAZINELUIZA\GTS_NLBEC_FARM02" }
        "MGC-S500MTG01 (10.184.12.182)" { insere_permissao $usuario "MAGAZINELUIZA\GTS_S500MTG01" }
        "S500HMLFP1 (10.31.0.128)" { insere_permissao $usuario "MAGAZINELUIZA\GTS_HMLFP1" }
        "acs-hml-fp-01 (10.6.11.75)" { insere_permissao $usuario "MAGAZINELUIZA\GTS_HMLFP1" }
        Default { Write-Host "Opcao invalida" }
    }
}

$opcoes = @("Servidor", "Pasta")
$tipo_permissao = exibir_menu $opcoes "=== Selecione o tipo de permissao ===="

if ($tipo_permissao -eq "Servidor") {
    
    While (-not $usuario -or $usuario -eq "" -or $usuario.Length -le 3) {
        Write-Host ""
        $usuario = Read-Host "Digite o usuario que recebera a permissao"
    
        if (-not $usuario -or $usuario -eq "" -or $usuario.Length -le 3) {
            $usuario = ""
            Write-Host `n"Campo usuario nao foi preenchido corretamente"`n -ForegroundColor Yellow
            Continue
        }
        
        $usuario_existe = Get-ADUser -Filter "SamAccountName -like '$usuario'" -ErrorAction SilentlyContinue

        if (-not $usuario_existe) {
            $usuario = ""
            Write-Host `n"Usuario nao localizado no Active Directory"`n -ForegroundColor Yellow
        }
    }

    inserir_permissao_servidor $usuario
}
elseif ($tipo_permissao -eq "Pasta") {
    While (-not $usuario -or $usuario -eq "" -or $usuario.Length -le 3) {
        Write-Host ""
        $usuario = Read-Host "Digite o usuario que recebera a permissao"
    
        if (-not $usuario -or $usuario -eq "" -or $usuario.Length -le 3) {
            $usuario = ""
            Write-Host `n"Campo usuario nao foi preenchido corretamente"`n -ForegroundColor Yellow
            Continue
        }
    
        $usuario_existe = Get-ADUser -Filter "SamAccountName -like '$usuario'"  -ErrorAction SilentlyContinue

        if (-not $usuario_existe) {
            $usuario = ""
            Write-Host `n"Usuario nao localizado no Active Directory"`n -ForegroundColor Yellow
        }
    }

    inserir_permissao_pasta $usuario
}