import pandas as pd
import os
from tqdm import tqdm
import time

# Definir o caminho da pasta onde os arquivos CSV estão armazenados
pasta_dados = "dados"  # Nome da pasta onde os arquivos CSV estão

file1 = os.path.join(pasta_dados, "AVXEndPoint-1668.csv")  # Substitua pelo nome do seu primeiro arquivo CSV
file2 = os.path.join(pasta_dados, "AVXEndPoint-1668.csv")  # Substitua pelo nome do seu segundo arquivo CSV

# Carregar os arquivos CSV com o separador correto (ponto e vírgula)
df1 = pd.read_csv(file1, sep=',')  # Usando 'sep=";"' para arquivos separados por ponto e vírgula
df2 = pd.read_csv(file2, sep=',')  # Usando 'sep=";"' para arquivos separados por ponto e vírgula

# Exibir as colunas de ambos os arquivos para verificar os nomes
print("Colunas do arquivo 1:", df1.columns)
print("Colunas do arquivo 2:", df2.columns)

# Definir a coluna que você quer usar para fazer o cruzamento
coluna_comum = "computer_name"  # Nome da coluna que será usada para o cruzamento

# Verificar se a coluna 'computer_name' existe em ambos os DataFrames
if coluna_comum in df1.columns and coluna_comum in df2.columns:
    # Realizar o "merge" entre os dois DataFrames com base na coluna 'computer_name'
    
    # Barra de progresso para o merge
    print("Iniciando o cruzamento dos dados...")
    for _ in tqdm(range(100), desc="Processando", ncols=100, ascii=True):
        time.sleep(0.01)  # Simulando um pequeno atraso, substitua isso por seu código real
    resultado = pd.merge(df1, df2, on=coluna_comum, how="inner")

    # Mostrar a quantidade de linhas antes de remover duplicatas
    print(f"Quantidade de linhas antes de remover duplicadas: {len(resultado)}")

    # Remover as linhas duplicadas
    resultado = resultado.drop_duplicates()

    # Mostrar a quantidade de linhas após remover duplicatas
    print(f"Quantidade de linhas após remover duplicadas: {len(resultado)}")

    # Salvar o resultado em um novo arquivo CSV na mesma pasta 'dados'
    resultado.to_csv(os.path.join(pasta_dados, "resultado_cruzado.csv"), index=False)

    # Exibir o resultado
    print("Arquivo cruzado gerado com sucesso! Veja o arquivo 'resultado_cruzado.csv' na pasta 'dados'.")
else:
    print(f"A coluna '{coluna_comum}' não foi encontrada em um dos arquivos.")
