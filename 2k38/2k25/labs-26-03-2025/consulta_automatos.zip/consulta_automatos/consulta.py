import os
import requests
import csv
import concurrent.futures
from urllib.parse import quote
import urllib3
from datetime import datetime
urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)


def get_page(url, headers):
    try:
        response = requests.get(url, headers=headers, verify=False)
        if response.status_code == 200:
            return response.json()
        else:
            print(f"Erro ao buscar página: {url} | Status: {response.status_code}")
            return None
    except requests.RequestException as e:
        print(f"Erro na requisição: {e}")
        return None


def fetch_pages(software, headers):
    
    url_template = f"https://lad1-smartcenter.almaden.app/api/public/v1/getAllSoftware/nextpage/desktops?AutomatosId={headers['automatosid']}&Securitykey={headers['securitykey']}&software_name={quote(software)}&page={{}}"

    page_num = 1
    all_data = []

    with concurrent.futures.ThreadPoolExecutor() as executor:
        futures = {}  

        while True:
            url = url_template.format(page_num)
            future = executor.submit(get_page, url, headers)
            futures[future] = page_num
            page_num += 1

            
            for future in concurrent.futures.as_completed(futures):
                result = future.result()
                if result and "data" in result:
                    data = result["data"]
                    if data:
                        for row in data:
                            row["software"] = software  
                        all_data.extend(data)

                
                next_page = result.get("nextPage") if result else None
                if not next_page:
                    return all_data


import os
import csv
from datetime import datetime

def load_software_list(txt_file):
    with open(txt_file, "r", encoding="utf-8") as file:
        return [line.strip() for line in file.readlines() if line.strip()]


def save_to_csv(data_all):
    output_dir = "dados"
    os.makedirs(output_dir, exist_ok=True)

    timestamp = datetime.now().strftime("%Y-%m-%d_%H-%M-%S")
    csv_file = f"dados/todos_softwares_{timestamp}_dados.csv"  # Arquivo único

    # Verificar se o arquivo já existe (para adicionar ao arquivo existente)
    file_exists = os.path.exists(csv_file)

    with open(csv_file, mode="a", newline="", encoding="utf-8") as file:
        if data_all:
            fieldnames = list(data_all[0].keys())  # Assumindo que todos os dados têm o mesmo formato
            writer = csv.DictWriter(file, fieldnames=fieldnames, delimiter=";")

            if not file_exists:  # Se o arquivo não existir, escreve o cabeçalho
                writer.writeheader()
            
            writer.writerows(data_all)

    print(f"Dados salvos no arquivo único: {csv_file}")


def main():
    headers = {
        "accept": "application/json",
        "automatosid": "338313379563",
        "securitykey": "RDMwRTk3MTFDMzNFRjJDRjdDNEE1N0JFRTdDMDVDRTQ="
    }

    software_list = load_software_list("lista_de_softwares.txt")

    all_data = []  # Lista para armazenar dados de todos os softwares

    for software in software_list:
        print(f"\nBuscando dados para o software {software} ...")
        data = fetch_pages(software, headers)
        if data:
            all_data.extend(data)  # Adiciona os dados do software ao conjunto geral
            print(f"{len(data)} registros adicionados para {software}")

    if all_data:
        save_to_csv(all_data)  # Salva todos os dados no arquivo único
    else:
        print("Nenhum dado foi encontrado.")

    print("\nProcesso concluído!")


if __name__ == "__main__":
    main()
